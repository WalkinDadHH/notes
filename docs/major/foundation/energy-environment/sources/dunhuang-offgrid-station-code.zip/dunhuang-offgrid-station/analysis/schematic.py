"""系统构成示意图（报告图 3.1）：母线中心、从左到右，线色区分能量载体。

python -m analysis.schematic   → results/figures/{journal,swiss}/S1_系统构成.{pdf,png}

这是解释性示意图，不承载结果数据；部件容量从 results/final_config.csv 读取。
连线全部为正交折线，只走部件之间的空白通道；渲染后自动检查
「线–框」「线–字」「字–字」「字–框」四类交叠，必须全部为 0 才保存。
"""
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
from model.params import H2_TECH, PV_TECH

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
MM = 1 / 25.4
W, H = 160, 100                       # 画布（mm），与报告正文宽度一致

STYLES = {
    "journal": NS(font=["Arial", "Heiti SC"], size=7.5, ink="#000000", sub="#555555", line="#8a8a8a",
                  car={"电": "#4D4D4D", "氢": "#0072B2", "热": "#D55E00", "水": "#009E73"},
                  tint={"电": "#ededed", "氢": "#e5f0f7", "热": "#fbece3", "水": "#e5f4ef"}),
    "swiss": NS(font=["Helvetica Neue", "Heiti SC"], size=7.5, ink="#0a0a0a", sub="#525252", line="#a3a3a3",
                car={"电": "#0a0a0a", "氢": "#002FA7", "热": "#5B7BFF", "水": "#737373"},
                tint={"电": "#f0f0ee", "氢": "#e6ebf8", "热": "#eef1ff", "水": "#f0f0ee"}),
}


def layout(f):
    """部件：名称 → (x, y, w, h, 标题, 副标题, 储能载体或 None)。坐标单位 mm，原点在左下。"""
    rsoc_ely = 2 * f.fc_kw if H2_TECH[f.tech].get("reversible") else f.ely_kw
    return {
        "pv":   (3, 50, 24, 21, "光伏", f"{f.pv_kwp:g} kWp\n双面 · 倾角 {PV_TECH[f.pv_tech]['tilt']:.0f}°\n静电除尘", None),
        "bat":  (48, 62, 27, 12, "电池", f"{f.bat_kwh:.0f} kWh 磷酸铁锂", "电"),
        "rsoc": (48, 40, 27, 16, "rSOC", f"电解 {rsoc_ely:.0f} kW\n发电 {f.fc_kw:.0f} kW", None),
        "heat": (48, 22, 27, 9, "电加热器", None, None),
        "hp":   (48, 5, 27, 9, "热泵", None, None),
        "h2":   (88, 41, 27, 14, "金属氢化物储氢", f"{f.tank_kg:.0f} kg", "氢"),
        "tes":  (88, 18, 27, 15, "砂石储热仓", f"{f.tes_kwh:.0f} kWh", "热"),
        "load": (124, 76, 33, 16, "站内用电", "监测设备 · 净水（关键）\n实验 · 生活", None),
        "water": (124, 41, 33, 14, "纯水系统", "制备 · 回收", "水"),
        "heatuse": (124, 5, 33, 26, "供暖 · 热水", "生存供暖 12 ℃（关键）", None),
    }


BUS = (33, 5, 3, 86)                  # 直流母线 (x, y, w, h)

# 连线：载体、正交折线顶点、箭头（"end" / "both"）、标注（文字, x, y, 对齐）
EDGES = [
    ("电", [(27, 60.5), (33, 60.5)], "end", None),
    ("电", [(36, 84), (124, 84)], "end", None),
    ("电", [(36, 68), (48, 68)], "both", None),
    ("电", [(36, 48), (48, 48)], "both", None),
    ("电", [(36, 26.5), (48, 26.5)], "end", None),
    ("电", [(36, 9.5), (48, 9.5)], "end", None),
    ("氢", [(75, 48), (88, 48)], "both", ("H$_2$", 81.5, 49.2, "center")),
    ("水", [(70, 56), (70, 59), (140.5, 59), (140.5, 55)], "both", ("电解耗水 / 发电产水回收", 105, 60.2, "center")),
    ("热", [(75, 26.5), (88, 26.5)], "end", None),
    ("热", [(115, 25.5), (124, 25.5)], "end", None),
    ("热", [(75, 9.5), (124, 9.5)], "end", None),
    ("热", [(66, 40), (66, 36), (101.5, 36), (101.5, 33)], "both", ("余热入仓 / 电解蒸汽 · 热备", 84, 37.0, "center")),
    ("热", [(101.5, 36), (119.5, 36), (119.5, 28.5), (124, 28.5)], "end", ("余热直供", 120.5, 32.5, "left")),
]
JUNCTIONS = [("热", (101.5, 36))]
COLUMNS = [(15, "发电"), (34.5, "直流母线"), (61.5, "转换"), (101.5, "储存"), (140.5, "用能")]


def draw(f, st):
    plt.rcdefaults()
    plt.rcParams.update({"font.family": st.font, "font.size": st.size, "pdf.fonttype": 42, "svg.fonttype": "none",
                         "axes.unicode_minus": False})
    fig = plt.figure(figsize=(W * MM, H * MM))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")
    texts, boxes = [], {}

    for x, lab in COLUMNS:
        texts.append(ax.text(x, 96.5, lab, ha="center", va="center", size=st.size, color=st.sub))
    ax.add_patch(Rectangle(BUS[:2], BUS[2], BUS[3], fc=st.car["电"], ec="none"))

    for key, (x, y, w, h, title, sub, store) in layout(f).items():
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.2",
                                    fc=st.tint[store] if store else "white", ec=st.line, lw=0.7))
        boxes[key] = (x, y, w, h)
        if sub:
            texts.append(ax.text(x + w / 2, y + h - 2.6, title, ha="center", va="top", size=st.size + 0.5,
                                 color=st.ink, weight="bold"))
            texts.append(ax.text(x + w / 2, y + h - 7.4, sub, ha="center", va="top", size=st.size - 1,
                                 color=st.sub, linespacing=1.25))
        else:
            texts.append(ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", size=st.size + 0.5,
                                 color=st.ink, weight="bold"))

    segs = []
    for car, pts, heads, label in EDGES:
        col, ls = st.car[car], (0, (3, 1.6)) if car == "水" else "-"
        xs, ys = zip(*pts)
        ax.plot(xs, ys, color=col, lw=1.3, ls=ls, solid_capstyle="butt", zorder=3)
        ends = [(pts[-2], pts[-1])] + ([(pts[1], pts[0])] if heads == "both" else [])
        for a, b in ends:
            ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=7, color=col, lw=0,
                                         shrinkA=0, shrinkB=0, zorder=4))
        segs += [(car, pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
        if label:
            t, lx, ly, ha = label
            texts.append(ax.text(lx, ly, t, ha=ha, va="bottom", size=st.size - 1, color=col, zorder=5))
    for car, (x, y) in JUNCTIONS:
        ax.plot([x], [y], "o", ms=2.6, color=st.car[car], zorder=5)

    for car, y in zip(("电", "氢", "热", "水"), (40, 35, 30, 25)):     # 图例放在左下角空白处
        ax.plot([4, 11], [y, y], color=st.car[car], lw=1.6, ls=(0, (3, 1.6)) if car == "水" else "-")
        texts.append(ax.text(13, y, car, va="center", size=st.size, color=st.ink))
    return fig, ax, texts, boxes, segs


def check(fig, ax, texts, boxes, segs):
    """返回交叠清单；空表示通过。全部在数据坐标（mm）里判断。"""
    fig.canvas.draw()
    inv = ax.transData.inverted()
    tb = []
    for t in texts:
        bb = t.get_window_extent().transformed(inv)
        tb.append((t.get_text().replace("\n", " "), bb.x0, bb.y0, bb.x1, bb.y1))
    rects = {k: (x, y, x + w, y + h) for k, (x, y, w, h) in boxes.items()}
    rects["bus"] = (BUS[0], BUS[1], BUS[0] + BUS[2], BUS[1] + BUS[3])
    issues = []

    def inside(px, py, r, pad):
        return r[0] + pad < px < r[2] - pad and r[1] + pad < py < r[3] - pad

    for car, a, b in segs:
        n = int(np.hypot(b[0] - a[0], b[1] - a[1]) / 0.2) + 2
        pts = np.linspace(a, b, n)[1:-1]
        for k, r in rects.items():
            if any(inside(px, py, r, 0.05) for px, py in pts):
                issues.append(f"线–框：{car} {a}→{b} 穿过 {k}")
        for name, x0, y0, x1, y1 in tb:
            if any(inside(px, py, (x0, y0, x1, y1), -0.4) for px, py in pts):
                issues.append(f"线–字：{car} {a}→{b} 压到「{name}」")
    for i, (n1, *r1) in enumerate(tb):
        for n2, *r2 in tb[i + 1:]:
            if r1[0] < r2[2] and r2[0] < r1[2] and r1[1] < r2[3] and r2[1] < r1[3]:
                issues.append(f"字–字：「{n1}」与「{n2}」")
        cx, cy = (r1[0] + r1[2]) / 2, (r1[1] + r1[3]) / 2
        for k, r in rects.items():
            overlap = r1[0] < r[2] and r[0] < r1[2] and r1[1] < r[3] and r[1] < r1[3]
            contained = r[0] <= r1[0] and r1[2] <= r[2] and r[1] <= r1[1] and r1[3] <= r[3]
            if overlap and not contained:
                issues.append(f"字–框：「{n1}」越出或压到 {k}")
    return issues


def main():
    f = pd.read_csv(RES / "final_config.csv").iloc[0]
    for key, st in STYLES.items():
        fig, ax, texts, boxes, segs = draw(f, st)
        issues = check(fig, ax, texts, boxes, segs)
        if issues:
            print(f"✗ {key}：{len(issues)} 处交叠"); print("  " + "\n  ".join(issues))
            raise SystemExit(1)
        out = RES / "figures" / key
        out.mkdir(parents=True, exist_ok=True)
        fig.savefig(out / "S1_系统构成.pdf", metadata={"CreationDate": None})
        fig.savefig(out / "S1_系统构成.png", dpi=220)
        plt.close(fig)
        print(f"✓ {key}：0 处交叠 → results/figures/{key}/S1_系统构成")


if __name__ == "__main__":
    main()
