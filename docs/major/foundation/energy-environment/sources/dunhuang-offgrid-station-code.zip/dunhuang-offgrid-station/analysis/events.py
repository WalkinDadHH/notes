"""真实低日照事件分析：用纯光储方案的逐时仿真找出 11 年里真正“撑不住”的时段。

产出：
  results/events.csv          每次亏电事件（电池触底）的起止、时长、缺口
  results/worst_windows.csv   连续 N 天光伏/负荷比最低的窗口（N=1..7）
"""
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate
from model.params import BASELINE as B
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "results"


def run():
    OUT.mkdir(exist_ok=True)
    w = load_weather(); L = build_load(w); pv1 = pv_power(w, 1.0)
    inp = make_inputs(w, L, pv1)

    # ① 纯光储基准下的缺电事件
    r = simulate(inp, B["pv_kwp"], B["bat_kwh"], record=True)
    s = r["series"]
    hit = s.unmet > 1e-6
    grp = (hit != hit.shift()).cumsum()
    ev = []
    for _, g in s[hit].groupby(grp[hit]):
        ev.append(dict(start=g.index[0], end=g.index[-1], hours=len(g),
                       unmet_kwh=g.unmet.sum()))
    ev = pd.DataFrame(ev)
    # 相隔 < 12 h 的事件合并为同一次天气过程
    if len(ev):
        merged, cur = [], ev.iloc[0].to_dict()
        for _, e in ev.iloc[1:].iterrows():
            if (e.start - cur["end"]).total_seconds() / 3600 < 12:
                cur["end"] = e.end; cur["hours"] += e.hours; cur["unmet_kwh"] += e.unmet_kwh
            else:
                merged.append(cur); cur = e.to_dict()
        merged.append(cur)
        ev = pd.DataFrame(merged).sort_values("unmet_kwh", ascending=False)
    ev.to_csv(OUT / "events.csv", index=False)

    # ② 连续 N 天最差窗口（光伏/负荷）
    d = pd.DataFrame({"pv": s.pv, "load": s.demand, "ghi": w.ghi}).resample("D").sum()
    rows = []
    for n in range(1, 8):
        roll = d.rolling(n).sum()
        ratio = roll.pv / roll.load
        end = ratio.idxmin()
        rows.append(dict(days=n, start=(end - pd.Timedelta(days=n - 1)).date(), end=end.date(),
                         pv_kwh=roll.pv[end], load_kwh=roll.load[end],
                         ratio=ratio[end], deficit_kwh=max(roll.load[end] - roll.pv[end], 0)))
    worst = pd.DataFrame(rows)
    worst.to_csv(OUT / "worst_windows.csv", index=False)

    # ③ 每次天气过程需要多少储能（不计效率的理想下限，sequent-peak）
    net = (s.demand - s.pv).values
    run_def, max_def, peak_t = 0.0, 0.0, None
    for i, x in enumerate(net):
        run_def = max(run_def + x, 0.0)
        if run_def > max_def:
            max_def, peak_t = run_def, s.index[i]
    return ev, worst, max_def, peak_t, d


if __name__ == "__main__":
    ev, worst, max_def, peak_t, d = run()
    print("═══ 纯光储 60 kWp + 300 kWh：11 年真实缺电事件（合并间隔 <12h）═══")
    print(f"共 {len(ev)} 次，合计 {ev.hours.sum():.0f} h / {ev.unmet_kwh.sum():.0f} kWh")
    for _, e in ev.head(10).iterrows():
        print(f"  {e.start:%Y-%m-%d %H}时 → {e.end:%m-%d %H}时  {e.hours:3.0f} h  缺 {e.unmet_kwh:6.1f} kWh")
    print("\n═══ 连续 N 天最差窗口（光伏寿命末期出力 / 负荷）═══")
    for _, x in worst.iterrows():
        print(f"  {x.days} 天  {x.start} ~ {x.end}  光伏 {x.pv_kwh:6.0f}  负荷 {x.load_kwh:6.0f}  比值 {x.ratio:.2f}  缺口 {x.deficit_kwh:5.0f} kWh")
    print(f"\n理想储能下限（不计效率，sequent-peak）：{max_def:.0f} kWh，出现在 {peak_t}")
    zero = (d.pv < 0.2 * d.load)
    runs = (zero != zero.shift()).cumsum()
    longest = zero.groupby(runs).sum().max()
    print(f"日光伏 < 20% 日负荷 的最长连续天数：{int(longest)} 天")
    print(f"日光伏 < 日负荷 的天数：{(d.pv < d.load).sum()} / {len(d)} 天")
