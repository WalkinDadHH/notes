"""把 results/ 与模型里的数字导出成 LaTeX 宏和表格，结题报告正文只引用宏、不手抄数字。

python -m analysis.report_numbers   → docs/结题报告/generated/numbers.tex, tab_*.tex
重跑顺序见附录：improve → refine（含 --compare）→ sensitivity / extremes / forecast → figures → schematic → report_numbers
"""
import json
import re
from pathlib import Path
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model import params as P
import analysis.schemes as SC

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
OUT = ROOT / "docs" / "结题报告" / "generated"


def f(x, nd=0):
    """千分位 + 固定小数位。"""
    return f"{x:,.{nd}f}"


def pct(x, nd=0):
    return f"{x * 100:.{nd}f}"


def N_get(N, name):
    """读回已写入的宏值（预测调度那段话要引用）。"""
    for line in N.lines:
        if line.startswith(f"\\newcommand{{\\{name}}}"):
            return line.split("}{", 1)[1][:-1]
    return ""


class Tex:
    def __init__(self):
        self.lines = ["% 由 python -m analysis.report_numbers 自动生成，不要手改", ""]

    def __setitem__(self, name, value):
        assert re.fullmatch(r"[A-Za-z]+", name), name
        self.lines.append(f"\\newcommand{{\\{name}}}{{{value}}}")

    def save(self, path):
        path.write_text("\n".join(self.lines) + "\n", encoding="utf-8")


def table(path, head, rows, align, note=None, units=None):
    """align 里含 X 时用 tabularx 撑满版心；units 为表头第二行（单位）。"""
    env = "tabularx" if "X" in align else "tabular"
    width = r"{\linewidth}" if env == "tabularx" else ""
    body = [rf"\begin{{{env}}}{width}{{{align}}}", r"\toprule", " & ".join(head) + r" \\"]
    if units:
        body.append(" & ".join(units) + r" \\")
    body.append(r"\midrule")
    body += [" & ".join(map(str, r)) + r" \\" for r in rows]
    body += [r"\bottomrule", rf"\end{{{env}}}"]
    if note:
        body.append(r"\par\vspace{2pt}{\footnotesize " + note + "}")
    path.write_text("% 由 python -m analysis.report_numbers 自动生成，不要手改\n" + "\n".join(body) + "\n",
                    encoding="utf-8")


def status_of(key):
    """从 params.py 源码里读某个参数那一行的状态标记。"""
    src = (ROOT / "model" / "params.py").read_text(encoding="utf-8")
    m = re.search(rf"^\s*{key}=.*$", src, re.M)
    line = m.group(0) if m else ""
    return "已核实" if "✅" in line else "课程设定" if "🔒" in line else "待核实" if "⚠️" in line else "—"


LADDER_KEYS = dict(M1="Mone", M2="Mtwo", S1="Sone", S2="Stwo", S3="Sthree", R1="Rone", R2="Rtwo")


def h2cell(r):
    if r.tank_kg == 0:
        return "—"
    return f"{r.ely_kw:g} / {r.fc_kw:g}"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    N = Tex()
    w = load_weather(); L = build_load(w)
    yrs = len(w) / 8766
    sc = SC.load()
    fin, econ, mat, pure, base = (sc[k] for k in ("final", "econ", "mature", "pure", "base"))
    ref = pd.read_csv(RES / "refine.csv")
    q_heat = (L.q_space + L.q_dhw).sum() / yrs
    tilt = P.PV_TECH[fin.pv_tech]["tilt"]

    # —— 年份与价格口径 ——
    N["BuildYear"] = P.PRICE_YEAR; N["EndYear"] = str(int(P.PRICE_YEAR) + P.ECON["years"] - 1)
    N["PriceYear"] = P.PRICE_YEAR; N["NowYear"] = "2026"
    N["Discount"] = pct(P.ECON["discount"]); N["EvalYears"] = f(P.ECON["years"])

    # —— 资源与负荷 ——
    N["Years"] = f(round(yrs)); N["Hours"] = f(len(w))
    N["Lat"] = f"{P.SITE['lat']:.2f}"; N["Lon"] = f"{P.SITE['lon']:.2f}"
    y23 = w.index.year == 2023
    pv_f = pv_power(w, 1.0, p=P.PV_TECH[fin.pv_tech])
    N["GHIyear"] = f(w.ghi[y23].sum() / 1000, 1)
    N["POAyear"] = f(pv_f.poa[y23].sum() / 1000)
    N["PR"] = f"{pv_f.pv_kw[y23].sum() / pv_f.poa[y23].sum() * 1000:.2f}"
    N["Tilt"] = f(tilt); N["TiltStd"] = f(P.PV["tilt"])
    day = L.e_total.resample("D").sum()
    N["DayMedian"] = f(day.median()); N["DayMax"] = f(day.max()); N["PeakKW"] = f(L.e_total.max(), 1)
    N["HeatDesign"] = f(L.q_space.quantile(0.996), 1)
    N["Qheat"] = f(q_heat / 1000, 1)
    win = w.index.month.isin([11, 12, 1, 2])
    hp_e = (L.q_space + L.q_dhw) / L.cop_h + L.q_cool / L.cop_c
    wb, wh = L.e_base[win].sum() / yrs, hp_e[win].sum() / yrs
    N["WinterBase"] = f(wb / 1000, 1); N["WinterHP"] = f(wh / 1000, 1); N["WinterBaseShare"] = pct(wb / (wb + wh))
    N["CritKW"] = f(P.CRITICAL["crit_kw"], 1); N["TSurvival"] = f(P.CRITICAL["t_survival"])
    N["People"] = f(P.SITE["people"]); N["Floor"] = f(P.SITE["floor_m2"])
    N["StressH"] = f(P.CRITERIA["stress_hours"])
    tp = RES / "improve_tilt.csv"
    if tp.exists():
        td = pd.read_csv(tp).set_index("tilt")
        N["TiltWinterGain"] = pct(td.winter_kwh_per_kwp[tilt] / td.winter_kwh_per_kwp[P.PV["tilt"]] - 1)
        N["TiltYearLoss"] = pct(1 - td.kwh_per_kwp[tilt] / td.kwh_per_kwp[P.PV["tilt"]])
    hp_ = RES / "dust_humidity.csv"
    if hp_.exists():
        hd = pd.read_csv(hp_)
        N["DustDaysWinter"] = pct(hd[hd.month.isin([11, 12, 1, 2])].days_usable.mean())
        N["RHdawnJan"] = f(hd.set_index("month").rh_dawn_median[1])
    N["RHmedian"] = f(w.rh.median())

    # —— 效率参数 ——
    H = P.H2; R = P.H2_TECH[fin.tech]
    pem_kpk = H["lhv"] / H["ely_eff"] + H["comp_kwh_per_kg"]
    soc_kpk = H["lhv"] / R["ely_eff"] + R["comp_kwh_per_kg"]
    N["RtePEM"] = pct(H["lhv"] * H["fc_eff"] / pem_kpk)
    N["RteSOC"] = pct(H["lhv"] * R["fc_eff"] / soc_kpk)
    N["RteSOCheat"] = pct(H["lhv"] * R["fc_eff"] / (soc_kpk + R["ely_heat_kwh_per_kg"]))
    N["SoecElec"] = f(soc_kpk, 0); N["SoecHeat"] = f(R["ely_heat_kwh_per_kg"], 0); N["PemElec"] = f(pem_kpk, 1)
    N["DCsave"] = pct(P.DC_BUS["load_saving"])

    # —— 定型配置（C 热集成版） ——
    N["FinalPV"] = f"{fin.pv_kwp:g}"; N["FinalBat"] = f(fin.bat_kwh); N["FinalFC"] = f(fin.fc_kw)
    N["FinalEly"] = f(fin.ely_kw); N["FinalTank"] = f(fin.tank_kg); N["FinalTES"] = f(fin.tes_kwh)
    N["FinalNPC"] = f(fin.npc / 1e4, 1); N["FinalNPCnow"] = f(fin.npc_2026 / 1e4, 1)
    N["FinalCapex"] = f(fin.capex / 1e4, 1); N["FinalCapexNow"] = f(fin.capex_2026 / 1e4, 1)
    N["FinalLCOE"] = f(fin.lcoe, 2)
    N["FinalEndur"] = f(fin.endurance_h)
    N["FinalEndurA"] = f(fin["h_2017-12"]); N["FinalEndurB"] = f(fin["h_2023-01"]); N["FinalEndurC"] = f(fin["h_2024-02"])
    N["FinalHeatShare"] = pct(fin.heat_share)
    N["FinalWater"] = f(fin.water_net_l); N["FinalWaterDay"] = f(fin.water_net_l / 365.25, 1)
    N["WaterGross"] = f(fin.water_gross_l)
    N["PVyield"] = f(fin.pv / 1000, 1); N["Demand"] = f(fin.demand / 1000, 1)
    N["Curtail"] = f(fin.curtail / 1000, 1); N["CurtailShare"] = pct(fin.curtail / fin.pv)
    N["BatCycles"] = f(fin.bat_cycles); N["BatLife"] = f(fin.bat_life)
    N["HtwoYear"] = f(fin.h2_used); N["HtwoMin"] = f(fin.h2_min_kg, 1)
    N["FcHours"] = f(fin.fc_hours); N["ElyHours"] = f(fin.ely_hours); N["RsocHours"] = f(fin.fc_hours + fin.ely_hours)
    N["RsocLife"] = f(P.prices(tech=fin.tech)["rsoc_stack_h"] / (fin.fc_hours + fin.ely_hours), 1)
    N["TESheat"] = f(fin.tes_out / 1000, 1); N["RecHeat"] = f(fin.heat_rec / 1000, 2)
    N["StandbyE"] = f(fin.standby_e); N["SteamE"] = f(fin.steam_e)
    N["FinalCapexPV"] = f(fin.capex_pv / 1e4, 1); N["FinalCapexBat"] = f(fin.capex_bat / 1e4, 1)
    N["FinalCapexHtwo"] = f(fin.capex_h2 / 1e4, 1); N["FinalCapexTES"] = f(fin.capex_tes / 1e4, 1)
    N["FinalOM"] = f(fin.om / 1e4, 1); N["FinalRep"] = f((fin.rep_bat + fin.rep_h2) / 1e4, 1)

    from model.system import simulate
    inp = SC.inputs_for(w, L, fin)
    s = simulate(inp, fin.pv_kwp, fin.bat_kwh, fin.ely_kw, fin.fc_kw, fin.tank_kg, tes_kwh=fin.tes_kwh,
                 tech=fin.tech, record=True)["series"]
    swin = s.index.month.isin([11, 12, 1, 2])
    N["HtwoWinter"] = pct(s.ely_p[swin].sum() / s.ely_p.sum())
    N["WeekHtwoMin"] = pct((s.h2_kg.loc["2023-01-08":"2023-01-14"] / fin.tank_kg).min())   # 与 figures.WEEK 一致

    # —— C 经济版 / 成熟方案 / 纯光储 / 开题 ——
    for tag, r in (("Econ", econ), ("Mat", mat), ("Pure", pure), ("Base", base)):
        N[f"{tag}PV"] = f"{r.pv_kwp:g}"; N[f"{tag}Bat"] = f(r.bat_kwh)
        N[f"{tag}Ely"] = f"{r.ely_kw:g}"; N[f"{tag}FC"] = f"{r.fc_kw:g}"; N[f"{tag}Tank"] = f(r.tank_kg)
        N[f"{tag}NPC"] = f(r.npc / 1e4, 1); N[f"{tag}NPCnow"] = f(r.npc_2026 / 1e4, 1)
        N[f"{tag}Endur"] = f(r.endurance_h); N[f"{tag}HeatShare"] = pct((r.tes_out + r.heat_rec) / q_heat)
        N[f"{tag}Curtail"] = pct(r.curtail / r.pv); N[f"{tag}Demand"] = f(r.demand / 1000, 1)
    N["FinalVsPure"] = pct(fin.npc / pure.npc); N["EconVsPure"] = pct(econ.npc / pure.npc)
    N["BatCut"] = pct(1 - fin.bat_kwh / pure.bat_kwh)
    N["Premium"] = f((fin.npc - econ.npc) / 1e4, 1); N["PremiumPct"] = pct(fin.npc / econ.npc - 1)
    N["PremiumNow"] = f((fin.npc_2026 - econ.npc_2026) / 1e4, 1); N["PremiumNowPct"] = pct(fin.npc_2026 / econ.npc_2026 - 1)
    N["EconVsMat"] = pct(1 - econ.npc / mat.npc); N["FinalVsMat"] = pct(fin.npc / mat.npc - 1)
    N["PVcut"] = pct(1 - econ.pv_kwp / mat.pv_kwp)

    rows = []
    for k in ("base", "pure", "mature", "econ", "final"):
        r = sc[k]
        cells = [f"{r.pv_kwp:g}", f(r.bat_kwh), h2cell(r), "—" if r.tank_kg == 0 else f(r.tank_kg),
                 "—" if r.tes_kwh == 0 else f(r.tes_kwh), pct(r.curtail / r.pv),
                 pct((r.tes_out + r.heat_rec) / q_heat), f(r.endurance_h), f(r.npc / 1e4, 1), f(r.npc_2026 / 1e4, 1)]
        lab = r.label.replace("定型 · ", "")
        rows.append([r"\textbf{定型：" + lab + "}", *[r"\textbf{" + x + "}" for x in cells]] if k == "final"
                    else [lab, *cells])
    table(OUT / "tab_schemes.tex",
          ["方案", "光伏", "电池", "电解 / 发电", "储氢", "储热仓", "弃光", "免热泵", "续航",
           f"{P.PRICE_YEAR} 价", "2026 价"], rows, "Xrrrrrrrrrr",
          "注：成熟光储氢为 PEM 电解 + 35~MPa 高压罐 + PEM 燃料电池、单面组件、倾角等于纬度、交流配电；"
          "C 经济版与定型方案均为双面组件 + 静电除尘、倾角 60°、直流母线。热集成版的“电解 / 发电”为同一台 rSOC 的两种模式。"
          "续航为三个最不利窗口中最短者；成本为 25 年全寿命成本。",
          units=["", "kWp", "kWh", "kW", "kg", "kWh", "\\%", "\\%", "h", "万元", "万元"])

    # —— 改进阶梯 ——
    lp = RES / "improve_ladder.csv"
    if lp.exists():
        ld = pd.read_csv(lp)
        ld = ld[ld.price_year.astype(str) == P.PRICE_YEAR].set_index("key")
        for k, t in LADDER_KEYS.items():
            if k in ld.index:
                r = ld.loc[k]
                N[f"Lad{t}PV"] = f"{r.pv_kwp:g}"; N[f"Lad{t}Curt"] = pct(r.curtail_share)
                N[f"Lad{t}Elec"] = f(r.elec_mwh, 1); N[f"Lad{t}Hloss"] = f(r.h2_loss_mwh, 1)
                N[f"Lad{t}Heat"] = pct(r.heat_share); N[f"Lad{t}NPC"] = f(r.npc_2035 / 1e4, 1)
                N[f"Lad{t}NPCnow"] = f(r.npc_2026 / 1e4, 1); N[f"Lad{t}Area"] = f(r.pv_area_m2)
        N["LadPVcut"] = pct(1 - ld.pv_kwp["S2"] / ld.pv_kwp["M2"])
        N["LadDCsave"] = pct(1 - ld.elec_mwh["S3"] / ld.elec_mwh["S2"])
        N["LadHlossCut"] = pct(1 - ld.h2_loss_mwh["R2"] / ld.h2_loss_mwh["S3"])
        N["LadHlossShare"] = pct((ld.h2_loss_mwh["S3"] - ld.h2_loss_mwh["R2"]) / ld.elec_mwh["S3"], 0)
        names = dict(M1="成熟：纯光储", M2="成熟：PEM + 35~MPa", S1="+ 双面 + 静电除尘", S2="+ 冬季倾角 60°",
                     S3="+ 直流母线（= C 经济版）", R1="对照：rSOC + 高压罐 + 储热", R2="对照：rSOC + 氢化物 + 储热")
        rows = []
        for k, lab in names.items():
            if k not in ld.index:
                continue
            r = ld.loc[k]
            rows.append([lab, f"{r.pv_kwp:g}", f(r.bat_kwh), "—" if r.tank_kg == 0 else f(r.tank_kg),
                         "—" if r.tes_kwh == 0 else f(r.tes_kwh), pct(r.curtail_share), f(r.elec_mwh, 1),
                         "—" if r.tank_kg == 0 else f(r.h2_loss_mwh, 1), pct(r.heat_share), f(r.npc_2035 / 1e4, 1),
                         f(r.npc_2026 / 1e4, 1)])
        table(OUT / "tab_ladder.tex",
              ["级", "光伏", "电池", "储氢", "储热", "弃光", "年用电", "氢路损失", "免热泵", f"{P.PRICE_YEAR} 价", "2026 价"],
              rows, "Xrrrrrrrrrr",
              f"注：每一级都在同一规则下重新优化容量（{P.PRICE_YEAR} 年价格最低）。“储热仓”一级的最优解不设储热仓，与上一级相同，未列出。",
              units=["", "kWp", "kWh", "kg", "kWh", "\\%", "MWh", "MWh/年", "\\%", "万元", "万元"])

    # —— 两档价格 ——
    p26, p35 = P.prices("2026", fin.tech, fin.pv_tech), P.prices("2035", fin.tech, fin.pv_tech)
    pe26, pe35 = P.prices("2026", "PEM+高压罐"), P.prices("2035", "PEM+高压罐")
    rows = [
        ["光伏系统", "元/kWp", f(p26["pv_cny_per_kwp"]), f(p35["pv_cny_per_kwp"]), "成熟", "NREL ATB 中性情景年均 −3.5\\%"],
        ["双面 + 静电除尘增量", "元/kWp", f(p26["pv_extra_cny_per_kwp"]), f(p35["pv_extra_cny_per_kwp"]), "试验", "量级估计"],
        ["电池系统", "元/kWh", f(p26["bat_cny_per_kwh"]), f(p35["bat_cny_per_kwh"]), "成熟", "NREL ATB 中性情景年均 −2.9\\%"],
        ["PEM 电解槽", "元/kW", f(pe26["ely_cny_per_kw"]), f(pe35["ely_cny_per_kw"]), "成熟", "DOE 2026 目标 250 \\$/kW"],
        ["PEM 燃料电池", "元/kW", f(pe26["fc_cny_per_kw"]), f(pe35["fc_cny_per_kw"]), "成熟", "车用系统已约 3,000 元/kW"],
        ["35~MPa 储氢罐", "元/kg", f(pe26["tank_cny_per_kg"]), f(pe35["tank_cny_per_kg"]), "成熟", "−20\\%（估计）"],
        [r"\textbf{rSOC 系统}", "元/kW", f(p26["rsoc_cny_per_kw"]), f(p35["rsoc_cny_per_kw"]), "试验",
         "DOE：现状 3,100 → 终极目标 1,300 \\$/kW"],
        ["rSOC 电堆寿命", "h", f(p26["rsoc_stack_h"]), f(p35["rsoc_stack_h"]), "试验", "DOE 2030 目标 40,000 h"],
        [r"\textbf{金属氢化物储氢}", "元/kg", f(p26["tank_cny_per_kg"]), f(p35["tank_cny_per_kg"]), "试验",
         "LBNL：合金 20 → 10 \\$/kg"],
        ["砂石储热仓", "元/kWh$_\\text{th}$", f(p26["tes_cny_per_kwh"]), f(p35["tes_cny_per_kwh"]), "示范",
         "Polar Night Energy 10—40 €/kWh"],
    ]
    table(OUT / "tab_prices.tex", ["设备", "单位", "2026估算", f"{P.PRICE_YEAR}情景", "成熟度", "原币种依据"],
          rows, "llrrlX", "注：两列单价均为人民币；依据栏保留来源原币种。固定换算1 USD = 7.2元、1 EUR = 8.0元，不是实时汇率。"
          "储氢单价按每kg氢容量计，合金出处按每kg材料计；rSOC按发电侧kW计。"
          "未来档是外推与目标情景，不是设备报价；物理性能不随价格档变化。")
    N["RsocNow"] = f(p26["rsoc_cny_per_kw"]); N["RsocFut"] = f(p35["rsoc_cny_per_kw"])
    N["MhNow"] = f(p26["tank_cny_per_kg"]); N["MhFut"] = f(p35["tank_cny_per_kg"])

    # —— 定型候选 ——
    floor, tol = P.CRITERIA["select_endurance_h"], P.CRITERIA["select_cost_tol"]
    import analysis.refine as RF
    n_grid = int(np.prod([len(RF.GRID[k]) for k in ("pv", "bat", "ely", "fc", "tank", "tes")]))
    ok = ref[ref.endurance_h >= floor].sort_values("npc")
    cheap = ok.iloc[0]
    outs = ref[ref.endurance_h < floor].sort_values("npc")
    N["NGrid"] = f(n_grid); N["NFeasible"] = f(len(ref)); N["NEndurOK"] = f(len(ok))
    N["EndurFloor"] = f(floor); N["CostTol"] = f(tol * 100); N["HeatTol"] = f(P.CRITERIA["select_heat_tol"] * 100)
    N["CheapNPC"] = f(cheap.npc / 1e4, 1); N["CheapTES"] = f(cheap.tes_kwh); N["CheapHeat"] = pct(cheap.heat_share)
    N["CheapPV"] = f"{cheap.pv_kwp:g}"; N["CheapEndur"] = f(cheap.endurance_h); N["CheapCurt"] = pct(cheap.curtail / cheap.pv)
    cells = lambda r: [f"{r.pv_kwp:g}", f(r.bat_kwh), f(r.tank_kg), f(r.tes_kwh), f(r.npc / 1e4, 2), f(r.endurance_h),
                       pct(r.heat_share), pct(r.curtail / r.pv)]
    bold = lambda xs: [r"\textbf{" + x + "}" for x in xs]
    rows = []
    if abs(cheap.npc - fin.npc) > 1:
        rows.append([*cells(cheap), "同价带内成本最低"])
    rows.append([*bold(cells(fin)), r"\textbf{定型}：热闭环同档，光伏最少"])
    if len(outs):
        out = outs.iloc[0]
        N["OutPV"] = f"{out.pv_kwp:g}"; N["OutNPC"] = f(out.npc / 1e4, 1); N["OutEndur"] = f(out.endurance_h)
        N["OutHeat"] = pct(out.heat_share)
        rows.append([*cells(out), f"续航不足 {floor} h，淘汰"])
    table(OUT / "tab_candidates.tex", ["光伏", "电池", "储氢", "储热仓", "成本", "续航", "免热泵", "弃光", "结论"], rows,
          "rrrrrrrrX", units=["kWp", "kWh", "kg", "kWh", "万元", "h", "\\%", "\\%", ""])

    # —— 关键参数 ——
    E = P.prices(tech=fin.tech, pv_tech=fin.pv_tech)
    rows = [
        ["SOEC 电耗 / 蒸汽热（kWh/kg）", f"{soc_kpk:.0f} / {R['ely_heat_kwh_per_kg']:.0f}", status_of("ely_heat_kwh_per_kg")],
        ["SOFC 电效率 / 可回收热（LHV）", f"{R['fc_eff']:.2f} / {R['fc_heat_eff']:.2f}", status_of("fc_heat_eff")],
        ["PEM 电解 / 燃料电池效率（LHV）", f"{H['ely_eff']:.2f} / {H['fc_eff']:.2f}", status_of("ely_eff")],
        ["电池往返效率", f"{P.BATTERY['eta_ch'] * P.BATTERY['eta_dis']:.2f}", status_of("eta_ch")],
        ["直流母线节电", f"{P.DC_BUS['load_saving']:.0%}".replace("%", "\\%"), status_of("load_saving")],
        ["光伏倾角（定型）/ 地表反照率", f"{tilt:.0f}° / {P.PV['albedo']:g}", "设计设定"],
        ["双面增益 / 静电除尘后积尘损失", f"{P.PV_TECH['双面+静电除尘']['bifacial_gain']:.0%} / "
         f"{P.PV_TECH['双面+静电除尘']['soiling']:.0%}".replace("%", "\\%"), status_of("bifacial_gain")],
        ["折现率 / 评价期", f"{E['discount']:.0%} / {E['years']} 年".replace("%", "\\%"), status_of("discount")],
        ["建筑综合传热系数", f"{P.BUILDING['H_W_per_K']:.0f} W/K", status_of("H_W_per_K")],
    ]
    table(OUT / "tab_params.tex", ["参数", "取值", "状态"], rows, "llc",
          "注：全部参数及来源见 \\texttt{model/params.py} 与 \\texttt{docs/参数核实.md}；设备单价见表 \\ref{tab:prices}。")

    # —— 灵敏度 ——
    sp = RES / "sensitivity.csv"
    if sp.exists():
        sd = pd.read_csv(sp)
        b0 = sd[sd.param == "base"].iloc[0]
        g = sd[sd.param != "base"]
        lo, hi = g[g.factor < 1].set_index("param"), g[g.factor > 1].set_index("param")
        span = (hi.final_npc - lo.final_npc).abs().sort_values(ascending=False)
        names = ["光伏", "电池", "电解", "发电", "储氢", "储热"]
        base_cfg = b0.reselect.split(" / ")

        def change(cfg):
            diff = [f"{n} {a0}→{a1}" for n, a0, a1 in zip(names, base_cfg, cfg.split(" / ")) if a0 != a1]
            return "，".join(diff) if diff else "—"

        rows = []
        for k in span.index:
            ra, rb = sorted((lo.ratio_pure_over_final[k], hi.ratio_pure_over_final[k]))
            pa, pb = sorted((lo.premium_over_econ[k] / 1e4, hi.premium_over_econ[k] / 1e4))
            rows.append([lo.label[k], f(lo.final_npc[k] / 1e4, 1), f(hi.final_npc[k] / 1e4, 1), f"{ra:.1f}--{rb:.1f}",
                         f"{pa:.0f}--{pb:.0f}", f"{change(lo.reselect[k])} / {change(hi.reselect[k])}"])
        table(OUT / "tab_sensitivity.tex",
              ["参数", "定型成本", "", "纯光储 /", "比经济版", "重新定型时的变化"],
              rows, "lrrccX",
              units=["（±30\\%）", "−30\\%", "+30\\%", "定型", "贵（万元）", "−30\\% / +30\\%"],
              note=f"注：成本单位万元，{P.PRICE_YEAR} 年价格。「纯光储 / 定型」为两条路线满足两条准则的最低成本之比（不含续航余量要求）；"
              "「比经济版贵」为定型路线重新定型后与 C 经济版最低成本之差。")
        N["SensBase"] = f(b0.final_npc / 1e4, 1)
        N["SensTop"] = lo.label[span.index[0]]; N["SensTopSpan"] = f(span.iloc[0] / 1e4, 1)
        N["SensRatioMin"] = f"{g.ratio_pure_over_final.min():.1f}"
        N["SensRatioMax"] = f"{g.ratio_pure_over_final.max():.1f}"
        N["SensPremMin"] = f(g.premium_over_econ.min() / 1e4); N["SensPremMax"] = f(g.premium_over_econ.max() / 1e4)
        N["SensReselect"] = f((g.reselect != b0.reselect).sum())
        N["SensN"] = f(len(g))

    # —— 极端情景 ——
    order = ["纯光储", "成熟光储氢", "C 经济版", "定型"]
    xp = RES / "extremes.csv"
    if xp.exists():
        xd = pd.read_csv(xp)
        rows = []
        for scn in xd.scenario.unique():
            d = xd[xd.scenario == scn].set_index("scheme")
            need = int(d.required_h.iloc[0])
            cells = [f"{int(d.endurance_h[k])}" + ("" if d.passed[k] else r"$^{\times}$") for k in order]
            rows.append([scn, f(need), *cells])
        table(OUT / "tab_extremes.tex", ["情景", "需撑 h", "纯光储 h", "成熟光储氢 h", "C 经济版 h", "定型 h"], rows,
              "lrrrrr", "注：情景持续到关键负荷首次中断；$^{\\times}$ 表示未撑满情景时长。三个最不利窗口取最短。")
        dd = xd.set_index(["scenario", "scheme"]).endurance_h
        for scn, tag in (("沙尘暴", "Dust"), ("寒潮叠加阴雪", "Cold")):
            N[f"{tag}Final"] = f(dd[(scn, "定型")]); N[f"{tag}Pure"] = f(dd[(scn, "纯光储")])
            N[f"{tag}Econ"] = f(dd[(scn, "C 经济版")])
        N["ColdGap"] = f(dd[("寒潮叠加阴雪", "定型")] - dd[("寒潮叠加阴雪", "纯光储")])
    N["DustH"] = f(P.EXTREME["dust_hours"]); N["DustPV"] = pct(P.EXTREME["dust_pv_factor"])
    N["ColdH"] = f(P.EXTREME["cold_hours"]); N["ColdPV"] = pct(P.EXTREME["cold_pv_factor"])
    N["ColdT"] = f(P.EXTREME["cold_t_air"])
    cp = RES / "endurance_curve.csv"
    if cp.exists():
        g = pd.read_csv(cp).pivot(index="pv_factor", columns="scheme", values="endurance_h")
        gap = g["定型"] - g["纯光储"]
        N["CurveGapMin"] = f(gap.min()); N["CurveGapMax"] = f(gap.max())
    up = RES / "extremes_upgrade.csv"
    parts = []
    if up.exists():
        for _, r in pd.read_csv(up).iterrows():
            tag = {"沙尘暴": "Dust", "寒潮叠加阴雪": "Cold"}.get(r.scenario)
            if tag and r.found:
                N[f"{tag}UpTank"] = f(r.tank_kg); N[f"{tag}UpCost"] = f(r.extra_npc / 1e4, 1)
                N[f"{tag}UpEndur"] = f(r.endurance_h); N[f"{tag}UpFC"] = f(r.fc_kw); N[f"{tag}UpBat"] = f(r.bat_kwh)
                f0 = pd.read_csv(RES / "final_config.csv").iloc[0]
                same = all(abs(r[k] - f0[k]) < 1e-6 for k in ("tank_kg", "fc_kw", "bat_kwh"))
                parts.append(f"{r.scenario}定型配置本身就能撑满（{r.endurance_h:.0f}~h）" if same else
                             f"撑满{r.scenario}需要把储氢调为 {r.tank_kg:.0f}~kg"
                             + (f"、rSOC 调为 {r.fc_kw:.0f}~kW" if r.fc_kw != f0.fc_kw else "")
                             + (f"、电池调为 {r.bat_kwh:.0f}~kWh" if r.bat_kwh != f0.bat_kwh else "")
                             + f"（续航 {r.endurance_h:.0f}~h），全寿命成本多 {r.extra_npc/1e4:.1f} 万元")
            elif tag:
                parts.append(f"{r.scenario}在升级网格内撑不满")
    N["ExtremeUpText"] = ("在定型配置上测算撑满这两类情景的代价：" + "；".join(parts) + "。"
                          "光伏和储热仓都不用动——多撑几天主要靠多存点氢。") if parts else ""

    # —— 预测调度 ——
    fp = RES / "forecast.csv"
    if fp.exists():
        fd = pd.read_csv(fp).set_index("forecast_h")
        r0, r1 = fd.loc[0], fd.loc[fd.index.max()]
        N["FcHorizon"] = f(fd.index.max())
        fb = lambda x: f(x) if pd.notna(x) else "超过 130"   # forecast.BAT_SWEEP 上限内都不满足
        N["FcBatTwoRule"] = fb(r0.min_bat_two_criteria); N["FcBatTwoFc"] = fb(r1.min_bat_two_criteria)
        N["FcBatMarRule"] = fb(r0.min_bat_with_margin); N["FcBatMarFc"] = fb(r1.min_bat_with_margin)
        N["FcPickNPC"] = f(r1.npc / 1e4, 1); N["FcPickEndur"] = f(r1.endurance_h)
        N["FcCostUp"] = f((r1.npc - r0.npc) / 1e4, 1)
        N["FcSame"] = "相同" if all(r0[k] == r1[k] for k in ("pv_kwp", "bat_kwh", "fc_kw", "tank_kg", "tes_kwh")) else "不同"
        N["FcHoursRule"] = f(r0.h2_hours); N["FcHoursFc"] = f(r1.h2_hours)
        N["FcHtwoRule"] = f(r0.h2_used); N["FcHtwoFc"] = f(r1.h2_used)
        more = pd.isna(r1.min_bat_two_criteria) or r1.min_bat_two_criteria >= r0.min_bat_two_criteria
        cost_dir = "高" if r1.npc >= r0.npc else "低"
        rel = (r1.npc - r0.npc) / r0.npc
        cost_txt = (f"两种调度的定型成本相差不到 {tol * 100:.0f}\\%（{abs(r1.npc - r0.npc)/1e4:.1f} 万元），落在同价带内，"
                    "预测调度没有省下钱" if abs(rel) < tol else
                    f"预测调度的全寿命成本{cost_dir} {abs(r1.npc - r0.npc)/1e4:.1f} 万元")
        txt = (f"{'结果与直觉相反。' if more else ''}定型配置其余容量不变时，规则调度最少需要 {r0.min_bat_two_criteria:.0f}~kWh 电池，"
               f"预测调度反而需要 {fb(r1.min_bat_two_criteria)}~kWh；按同一选型规则重新定型，{cost_txt}。")
        if not more:
            txt = txt.replace("预测调度反而需要", "预测调度需要")
        if r1.h2_used > r0.h2_used:
            txt += (f"原因在于两种储能的效率差：电池往返效率约 90\\%，氢路即便用 rSOC 也只有一半左右。让 rSOC 先发电，"
                    f"等于把本可由电池高效完成的昼夜调节交给了氢：年用氢从 {r0.h2_used:.0f}~kg 增加到 {r1.h2_used:.0f}~kg，"
                    f"rSOC 年运行小时从 {r0.h2_hours:.0f} 增加到 {r1.h2_hours:.0f}，电堆更换随之提前。"
                    "而在长时间黑暗里，决定续航的是储氢量而不是电池，提前动用氢只会让它更早用完。"
                    "因此对本系统而言，“电池先放、氢兜底”的规则调度已经接近最优。")
        N["ForecastText"] = txt

    # —— 热备策略对比（analysis.standby） ——
    p = RES / "standby_compare.csv"
    if p.exists():
        sb = pd.read_csv(p)
        base, fin_sb = sb.iloc[0], sb.iloc[1]          # 第 0 行：保温箱在室外；第 1 行：在站房内（定型）
        N["SbOutPV"] = f(base.pv_kwp, 1); N["SbOutBat"] = f(base.bat_kwh); N["SbOutNPC"] = f(base.npc_2035 / 1e4, 1)
        N["SbOutHtwo"] = f(base.h2_used_kg, 1); N["SbInPV"] = f(fin_sb.pv_kwp, 1); N["SbInNPC"] = f(fin_sb.npc_2035 / 1e4, 1)
        N["SbInHtwo"] = f(fin_sb.h2_used_kg, 1); N["SbSave"] = f((base.npc_2035 - fin_sb.npc_2035) / 1e4, 1)
        od = sb[sb.standby_soc.notna()]
        N["SbDemandNPCmin"] = f(od.npc_2035.min() / 1e4, 1); N["SbDemandNPCmax"] = f(od.npc_2035.max() / 1e4, 1)
        rows = [[r.case.replace("%", r"\%").replace("<", "$<$"), f(r.pv_kwp, 1), f(r.bat_kwh), f(r.tank_kg), f(r.tes_kwh), f(r.npc_2035 / 1e4, 1),
                 f(r.endurance_h), f(r.h2_used_kg, 1), pct(r.heat_share)] for r in sb.itertuples()]
        table(OUT / "tab_standby.tex", ["热备做法", "光伏", "电池", "储氢", "储热", "2035 价", "续航", "年用氢", "免热泵"],
              rows, "Xrrrrrrrr", units=["", "kWp", "kWh", "kg", "kWh", "万元", "h", "kg", "\\%"],
              note="注：每种做法都按同一选型规则重新优化容量。按需热备指冬季仅在电池电量低于阈值或 rSOC 刚运行时保温，"
                   "冷态启动需升温 8~h、期间耗热为热备功率的 2 倍。")

    # —— 风电与季节性储氢（analysis.alternatives） ——
    p = RES / "alternatives.json"
    if p.exists():
        al = json.loads(p.read_text(encoding="utf-8"))
        N["WindMean"] = f(al["wind_mean_10m"], 1); N["WindWinterNight"] = f(al["wind_winter_night_10m"], 1)
        for tag, k in (("Hawt", "hawt"), ("Vortex", "bladeless")):
            d = al[k]
            N[f"{tag}Year"] = f(d["annual_kwh"]); N[f"{tag}CF"] = f(d["cf_pct"], 1); N[f"{tag}Night"] = f(d["winter_night_w"])
            N[f"{tag}Winter"] = f(d["winter_kwh"]); N[f"{tag}Cost"] = f(d["cost_cny"] / 1e4, 1)
            N[f"{tag}PVkwp"] = f(d["pv_kwp_same_cost"], 1); N[f"{tag}PVyear"] = f(d["pv_annual_kwh_same_cost"])
            N[f"{tag}PVwinter"] = f(d["pv_winter_kwh_same_cost"])
        sh = al["seasonal_h2"]
        N["SeasWinterKwh"] = f(sh["winter_kwh_per_kwp"]); N["SeasKg"] = f(sh["kg_per_kwp"], 1)
        N["SeasCost"] = f(sh["storage_cny_per_kwp"] / 1e4, 1); N["SeasRatio"] = f(sh["ratio"])

    N.save(OUT / "numbers.tex")
    from analysis.project_budget import main as export_project_budget
    export_project_budget()
    print("→", *sorted(p.name for p in OUT.glob("*.tex")))


if __name__ == "__main__":
    main()
