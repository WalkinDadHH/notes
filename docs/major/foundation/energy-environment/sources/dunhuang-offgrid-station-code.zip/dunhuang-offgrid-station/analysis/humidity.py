"""静电除尘可用性：敦煌每天有没有相对湿度 > 30% 的时段（Panat & Varanasi 2022 的工作条件）。

除尘不必全天可用，只要每天有一段湿度够的时间（通常是黎明）择时运行即可。
python -m analysis.humidity   → results/dust_humidity.csv
"""
from pathlib import Path
import pandas as pd
from model.weather import load_weather

ROOT = Path(__file__).resolve().parent.parent
RH_MIN = 30.0          # 静电除尘有效的相对湿度下限 %
DAWN = [4, 5, 6, 7]    # 黎明时段（LST）

if __name__ == "__main__":
    w = load_weather()
    day_max = w.rh.resample("D").max()
    dry = (day_max <= RH_MIN).astype(int)
    rows = []
    for m in range(1, 13):
        sel = w.index.month == m
        rows.append(dict(month=m, rh_median=w.rh[sel].median(),
                         rh_dawn_median=w.rh[sel & w.index.hour.isin(DAWN)].median(),
                         days_usable=(day_max[day_max.index.month == m] > RH_MIN).mean()))
    df = pd.DataFrame(rows)
    df.to_csv(ROOT / "results" / "dust_humidity.csv", index=False)
    longest = dry.groupby((dry != dry.shift()).cumsum()).sum().max()
    win = df[df.month.isin([11, 12, 1, 2])]
    print(df.round(2).to_string(index=False))
    print(f"\n全年中位湿度 {w.rh.median():.0f}%；有 > {RH_MIN:.0f}% 时段的天数 {(day_max > RH_MIN).mean():.0%}；"
          f"冬季（11–2 月）{win.days_usable.mean():.0%}；最长连续无可用时段 {longest} 天")
