"""两条没有纳入定型的路线：小型风电（含无叶式风机）与季节性储氢。用 11 年逐时气象和定型配置给出量化理由。

python -m analysis.alternatives   → results/alternatives.json

风电：NASA POWER 10 m 风速，按幂律 α = 0.14（开阔戈壁）折算到轮毂高度；空气密度取 1.2 kg/m³（敦煌海拔约 1,100 m，偏乐观）。
- 5 kW 水平轴：叶轮直径 5 m、Cp 0.35、切入 3 m/s、切出 25 m/s、轮毂 12 m，单机 4–7 万元（取 5.5 万）。
- 5 kW 无叶式（涡激振动）：杆高 10 m、平均杆径 0.6 m（迎风 6 m²）、Cp 0.33、机械 0.98 × 发电机 0.93、
  切入 1.5 m/s、切出 35 m/s，单机 4 万元。参数取自吴健东《基于无叶片风力发电机的“零碳园区”风光电储微电网新方案》
  （浙江大学第 19 届节能减排竞赛作品说明书，2026）。
季节性储氢：夏季弃光电解存氢、冬季发电，用来替代为冬季多装的光伏。
"""
import json
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.solar import pv_power
from model.params import PV_TECH, MAIN_ROUTE, PRICES, PRICE_YEAR, H2_TECH, H2, ECON
from model.params import prices
from analysis.refine import ROOT

RHO = 1.2
WINTER = (11, 12, 1, 2)


def hawt(v):
    a = np.pi * 2.5 ** 2
    p = 0.5 * RHO * a * 0.35 * v ** 3 / 1000
    return np.where((v >= 3) & (v <= 25), np.minimum(p, 5.0), 0.0)


def bladeless(v):
    p = 0.5 * RHO * 6.0 * 0.33 * 0.98 * 0.93 * v ** 3 / 1000
    return np.where((v >= 1.5) & (v <= 35), np.minimum(p, 5.0), 0.0)


def main():
    w = load_weather()
    yrs = len(w) / 8766
    idx = w.index
    winter = idx.month.isin(WINTER)
    night = winter & ((w.hour_bj < 8) | (w.hour_bj >= 18))
    pv1 = pv_power(w, 1.0, p=PV_TECH[MAIN_ROUTE["pv_tech"]])["pv_kw"].values
    e = prices(PRICE_YEAR, tech=MAIN_ROUTE["tech"], pv_tech=MAIN_ROUTE["pv_tech"])
    pv_cost = e["pv_cny_per_kwp"] + e["pv_extra_cny_per_kwp"]
    out = dict(wind_mean_10m=round(float(w.wind.mean()), 2),
               wind_winter_night_10m=round(float(w.wind[night].mean()), 2))
    for name, f, hub, cost in (("hawt", hawt, 12.0, 55000.0), ("bladeless", bladeless, 10.0, 40000.0)):
        p = f(w.wind.values * (hub / 10) ** 0.14)
        out[name] = dict(annual_kwh=round(float(p.sum() / yrs)), cf_pct=round(float(p.mean() / 5 * 100), 1),
                         winter_night_w=round(float(p[night].mean() * 1000)),
                         cost_cny=cost, pv_kwp_same_cost=round(cost / pv_cost, 1),
                         pv_annual_kwh_same_cost=round(float(pv1.sum() / yrs * cost / pv_cost)),
                         pv_winter_kwh_same_cost=round(float(pv1[winter].sum() / yrs * cost / pv_cost)),
                         winter_kwh=round(float(p[winter].sum() / yrs)))
    # 季节性储氢：替代 1 kWp 冬季发电所需的氢及储氢投资
    t = H2_TECH[MAIN_ROUTE["tech"]]
    winter_kwh_per_kwp = float(pv1[winter].sum() / yrs)
    kg = winter_kwh_per_kwp / (H2["lhv"] * t["fc_eff"])
    out["seasonal_h2"] = dict(winter_kwh_per_kwp=round(winter_kwh_per_kwp), kg_per_kwp=round(kg, 1),
                              storage_cny_per_kwp=round(kg * e["tank_cny_per_kg"]), pv_cny_per_kwp=round(pv_cost),
                              ratio=round(kg * e["tank_cny_per_kg"] / pv_cost, 1))
    (ROOT / "results" / "alternatives.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
