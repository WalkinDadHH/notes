"""预测调度（试验性）：看天气预报能省多少储能。

完美预报给出上界——预报未来 24 小时光伏不够用电时，亏缺先由燃料电池 / rSOC 发电、电池留作调峰
（model.system.simulate 的 forecast_h）。与现在的规则调度（电池先放、氢兜底）比较：
  ① 定型配置其余容量不变、只扫电池：两种调度下满足两条准则（及续航余量）的最小电池
  ② 定型路线细网格按同一选型规则重新定型

python -m analysis.forecast   → results/forecast.csv（约 4 分钟）
"""
import itertools, time
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.economics import npc
from model.params import PV_TECH, CRITERIA
from analysis.design import STRESS_STARTS
from analysis.endurance import MAX_H
from analysis.refine import GRID, TECH, PVT, TOP_K, SIZE, select, route_inputs

ROOT = Path(__file__).resolve().parent.parent
HORIZON = 24
BAT_SWEEP = np.arange(20, 131, 5)
STRATEGIES = (("规则调度", 0), ("完美预报调度", HORIZON))


def run(inp, c, fh, **kw):
    return simulate(inp, c[:, 0], c[:, 1], c[:, 2], c[:, 3], c[:, 4], tes_kwh=c[:, 5], tech=TECH, forecast_h=fh, **kw)


def assess(inp, c, fh, q_heat, top_k=None):
    """逐时零缺电 → （按成本取前 top_k）→ 三次 72 h 压力测试 → 续航，返回满足两条准则的配置表。"""
    sim = run(inp, c, fh)
    df = pd.DataFrame({k: v for k, v in sim.items() if isinstance(v, np.ndarray)})
    for k, v in npc(sim, tech=TECH, pv_tech=PVT).items():
        df[k] = v
    df = df[df.unmet_total < 1e-6].sort_values("npc")
    if top_k:
        df = df.head(top_k)
    if df.empty:  # 扫描范围内没有逐时零缺电的配置
        return df.assign(endurance_h=[], heat_share=[])
    cc = df[SIZE].values
    ok = np.ones(len(df), bool)
    for st in STRESS_STARTS:
        ok &= run(with_blackout(inp, st, CRITERIA["stress_hours"]), cc, fh)["crit_unmet_total"] < 1e-6
    df, cc = df[ok].copy(), cc[ok]
    hold = np.full(len(df), MAX_H)
    for st in STRESS_STARTS:
        h = run(with_blackout(inp, st, MAX_H), cc, fh, track_from=st)["first_crit_h"]
        hold = np.minimum(hold, np.where((h < 0) | (h > MAX_H), MAX_H, h))
    df["endurance_h"] = hold
    df["heat_share"] = (df.tes_out + df.heat_rec) / q_heat
    return df


if __name__ == "__main__":
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    q_heat = (L.q_space + L.q_dhw).sum() / (len(w) / 8766)
    inp = route_inputs(w, L)
    fin = pd.read_csv(ROOT / "results" / "final_config.csv").iloc[0]
    floor = CRITERIA["select_endurance_h"]
    sweep = np.array([(fin.pv_kwp, b, fin.ely_kw, fin.fc_kw, fin.tank_kg, fin.tes_kwh) for b in BAT_SWEEP], float)
    grid = np.array(list(itertools.product(*[GRID[k] for k in ("pv", "bat", "ely", "fc", "tank", "tes")])), float)
    rows = []
    for name, fh in STRATEGIES:
        s = assess(inp, sweep, fh, q_heat)
        two = s.bat_kwh.min() if len(s) else np.nan
        margin = s[s.endurance_h >= floor].bat_kwh.min() if (s.endurance_h >= floor).any() else np.nan
        g = assess(inp, grid, fh, q_heat, top_k=TOP_K)
        pick, _ = select(g)
        rows.append(dict(strategy=name, forecast_h=fh, min_bat_two_criteria=two, min_bat_with_margin=margin,
                         pv_kwp=pick.pv_kwp, bat_kwh=pick.bat_kwh, ely_kw=pick.ely_kw, fc_kw=pick.fc_kw, tank_kg=pick.tank_kg,
                         tes_kwh=pick.tes_kwh, npc=pick.npc, endurance_h=pick.endurance_h, heat_share=pick.heat_share,
                         bat_cycles=pick.bat_cycles, h2_hours=pick.fc_hours + pick.ely_hours, h2_used=pick.h2_used))
        print(f"{name}：其余不变时最小电池 {two:.0f} kWh（两条准则）/ {margin:.0f} kWh（含续航余量）；"
              f"重新定型 {pick.pv_kwp:g}/{pick.bat_kwh:.0f}/{pick.ely_kw:g}/{pick.fc_kw:g}/{pick.tank_kg:.0f}/{pick.tes_kwh:.0f}，"
              f"{pick.npc/1e4:.2f} 万，续航 {pick.endurance_h:.0f} h，免热泵 {pick.heat_share:.0%}  ({time.time()-t0:.0f}s)",
              flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "forecast.csv", index=False)
    print("→ results/forecast.csv")
