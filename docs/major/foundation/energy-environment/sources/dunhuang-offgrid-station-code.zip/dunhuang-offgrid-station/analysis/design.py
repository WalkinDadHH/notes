"""方案设计（旧入口）：在两条设计准则下比较纯光储与光储氢各技术路线。

设计准则（params.CRITERIA）：
  ① 11 年（2014–2024）逐时真实天气下零缺电
  ② 72 小时零光照压力测试中，关键负荷（监测设备 + 生存供暖）零中断
     压力测试放在历史上最差的三段连续低日照窗口起点，三次都要通过

2026-10-14 起方案比较改由 analysis.improve 的改进阶梯完成（同时写 design_summary.csv 与 endurance.csv），
本模块保留压力测试窗口 STRESS_STARTS 等公共定义；python -m analysis.design 直接转去运行 analysis.improve。
"""
import itertools, time, sys
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.economics import npc
from model.params import PV_TECH, BASELINE

OUT = Path(__file__).resolve().parent.parent / "results"
STRESS_STARTS = ["2017-12-12 00:00", "2023-01-12 00:00", "2024-02-17 00:00"]
TOP_K = 300

GRID = dict(pv=np.arange(40, 101, 10), bat=np.arange(50, 401, 25),
            ely=[5, 10, 20], fc=[5, 10, 15], tank=[10, 15, 20, 25, 30, 40])

KEEP = ["scheme", "tech", "pv_tech", "pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg", "tes_kwh",
        "npc", "capex", "capex_pv", "capex_bat", "capex_h2", "capex_tes", "lcoe", "unmet_total",
        "curtail", "h2_made", "h2_used", "h2_min_kg", "fc_hours", "ely_hours", "heat_rec",
        "tes_in", "tes_out", "standby_e", "water_net_l", "bat_cycles", "bat_life"]


def frame(sim, cost, **tags):
    df = pd.DataFrame({k: sim[k] for k in sim if isinstance(sim[k], np.ndarray)})
    for k, v in cost.items():
        df[k] = v
    for k, v in tags.items():
        df[k] = v
    return df


def grid(scheme, tech):
    if scheme == "A":
        return np.array([(p, b, 0, 0, 0) for p, b in itertools.product(
            np.arange(40, 141, 10), np.arange(150, 1001, 25))], float)
    elys = [0] if (tech and "rSOC" in tech) else GRID["ely"]
    return np.array(list(itertools.product(GRID["pv"], GRID["bat"], elys, GRID["fc"], GRID["tank"])), float)


def search(inp_by_pv, scheme, tech, pv_tech, tes):
    inp = inp_by_pv[pv_tech]
    c = grid(scheme, tech)
    sim = simulate(inp, c[:, 0], c[:, 1], c[:, 2], c[:, 3], c[:, 4], tes_kwh=tes, tech=tech)
    df = frame(sim, npc(sim, tech=tech, pv_tech=pv_tech), scheme=scheme, tech=tech or "-",
               pv_tech=pv_tech)
    ok = df[df.unmet_total < 1e-6].sort_values("npc").head(TOP_K)
    if ok.empty:
        return df, None
    cc = ok[["pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg"]].values
    passed = np.ones(len(ok), bool)
    for st in STRESS_STARTS:
        s = simulate(with_blackout(inp, st, 72), cc[:, 0], cc[:, 1], cc[:, 2], cc[:, 3], cc[:, 4],
                     tes_kwh=tes, tech=tech)
        passed &= s["crit_unmet_total"] < 1e-6
    ok = ok[passed]
    return df, (ok.iloc[0] if len(ok) else None)


def main():
    OUT.mkdir(exist_ok=True)
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    inp_by_pv = {k: make_inputs(w, L, pv_power(w, 1.0, p=v)) for k, v in PV_TECH.items()}
    cases = [("A", None, "常规单面+人工清洗", 0)]
    cases += [("B", "PEM+高压罐", "常规单面+人工清洗", 0)]
    for tech in ("PEM+金属氢化物", "rSOC+金属氢化物"):
        for tes in (0, 200, 500):
            cases.append(("B", tech, "双面+静电除尘", tes))
    cases.append(("B", "PEM+高压罐", "双面+静电除尘", 200))
    best = []
    for scheme, tech, pvt, tes in cases:
        df, b = search(inp_by_pv, scheme, tech, pvt, tes)
        tag = f"{scheme} {tech or ''} {pvt} 储热{tes}"
        if b is None:
            print(f"✗ {tag}: 无可行解  ({time.time()-t0:.0f}s)"); continue
        b = b.copy(); b["case"] = tag
        best.append(b)
        print(f"✓ {tag}: 光伏 {b.pv_kwp:.0f} 电池 {b.bat_kwh:.0f} 电解 {b.ely_kw:.0f} 燃电 {b.fc_kw:.0f} "
              f"罐 {b.tank_kg:.0f}  NPC {b.npc/1e4:.1f} 万  ({time.time()-t0:.0f}s)", flush=True)

    # 开题配置在同一准则下的表现
    inp = inp_by_pv["常规单面+人工清洗"]
    k = BASELINE
    s = simulate(inp, k["pv_kwp"], k["bat_kwh"], k["ely_kw"], k["fc_kw"], k["tank_kg"])
    st = [simulate(with_blackout(inp, x, 72), k["pv_kwp"], k["bat_kwh"], k["ely_kw"], k["fc_kw"],
                   k["tank_kg"])["crit_unmet_total"][0] for x in STRESS_STARTS]
    b0 = frame(s, npc(s), scheme="B", tech="PEM+高压罐", pv_tech="常规单面+人工清洗").iloc[0].copy()
    b0["case"] = "开题配置"; b0["stress_crit_unmet_max"] = max(st)
    best.insert(0, b0)
    summ = pd.DataFrame(best)
    cols = ["case"] + [c for c in KEEP if c in summ.columns and c not in ("scheme",)]
    summ[cols].to_csv(OUT / "design_summary.csv", index=False)
    print(f"\n完成 {time.time()-t0:.0f}s → results/design_summary.csv")


if __name__ == "__main__":
    import runpy
    runpy.run_module("analysis.improve", run_name="__main__")
