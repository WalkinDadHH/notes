"""给交互网页导出数据：results/web/*.json。网页是离线单文件，构建时把这些 JSON 内联进 HTML（见 web/build.py）。

python -m analysis.export_web   → results/web/{schemes,replay,week,month,lookup,monthly}.json（约 1 分钟）

schemes  方案对比：容量、成本构成、续航、免热泵供热占比
replay   零光照回放：定型与纯光储在最不利窗口断光直到失守的逐时序列
week     定型方案冬季一周逐时运行（能量流图）
month    定型方案 1 月整月逐时运行（三维模型）
lookup   滑块查表：定型路线上电池 × 储氢网格的 11 年缺电、续航与成本
monthly  定型方案三条闭环的月度值
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout, tech_params
from model.economics import npc
from model.params import CRITERIA, CRITICAL, BATTERY, PRICE_YEAR
from analysis.design import STRESS_STARTS
from analysis.endurance import MAX_H
import analysis.schemes as SC

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
OUT = RES / "web"
WINDOW = "2023-01-12 00:00"
REPLAY_H = 120
WEEK = ("2023-01-08", "2023-01-14")
MONTH = ("2023-01-01", "2023-01-31")
LOOKUP = dict(bat=[0, 25, 50, 75, 100, 125, 150, 200, 300, 400, 600, 1075],
              tank=[0, 5, 10, 15, 20, 25, 30, 35, 40, 50])


def r1(a, nd=2):
    return [round(float(x), nd) for x in a]


def args_of(r):
    tech = None if pd.isna(r.tech) or r.tech in ("-", "") else r.tech
    return dict(pv_kwp=r.pv_kwp, bat_kwh=r.bat_kwh, ely_kw=r.ely_kw, fc_kw=r.fc_kw, tank_kg=r.tank_kg,
                tes_kwh=r.tes_kwh, tech=tech)


def series(s, r, cols):
    out = {}
    for c in cols:
        if c == "soc":
            out[c] = r1((s.soc - BATTERY["soc_min"]) / (BATTERY["soc_max"] - BATTERY["soc_min"]) * 100, 1)
        elif c == "h2_pct":
            out[c] = r1(s.h2_kg / r.tank_kg * 100, 1) if r.tank_kg > 0 else []
        elif c == "tes_pct":
            out[c] = r1(s.tes_kwh / r.tes_kwh * 100, 1) if r.tes_kwh > 0 else []
        else:
            out[c] = r1(s[c])
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    w = load_weather(); L = build_load(w)
    yrs = len(w) / 8766
    q_heat = (L.q_space + L.q_dhw).sum() / yrs
    sc = SC.load()
    fin, pure = sc["final"], sc["pure"]
    inp_f, inp_a = SC.inputs_for(w, L, fin), SC.inputs_for(w, L, pure)

    # —— 方案对比（成本为 2035 价，另给 2026 价总额） ——
    rows = []
    for key in ("base", "pure", "mature", "econ", "final"):
        r = sc[key]
        rows.append(dict(name=r.label, final=key == "final",
                         pv_kwp=r.pv_kwp, bat_kwh=r.bat_kwh, ely_kw=r.ely_kw, fc_kw=r.fc_kw, tank_kg=r.tank_kg,
                         tes_kwh=r.tes_kwh, npc_wan=round(r.npc / 1e4, 1), npc_2026_wan=round(r.npc_2026 / 1e4, 1),
                         capex_wan={k: round(r[f"capex_{k}"] / 1e4, 2) for k in ("pv", "bat", "h2", "tes")},
                         rest_wan=round((r.npc - r.capex) / 1e4, 2),
                         endurance_h=int(r.endurance_h), dc_bus=SC.dc_of(r),
                         curtail_share=round(float(r.curtail / r.pv), 3),
                         heat_share=round(float((r.tes_out + r.heat_rec) / q_heat), 3)))
    dump("schemes", dict(stress_hours=CRITERIA["stress_hours"], crit_kw=CRITICAL["crit_kw"], price_year=PRICE_YEAR,
                         schemes=rows))

    # —— 零光照回放 ——
    rep = {}
    for key, r, inp in (("final", fin, inp_f), ("pure", pure, inp_a)):
        s = simulate(with_blackout(inp, WINDOW, REPLAY_H), record=True, **args_of(r))["series"]
        i0 = s.index.get_indexer([pd.Timestamp(WINDOW)], method="nearest")[0]
        seg = s.iloc[i0 - 24:i0 + REPLAY_H + 12]
        hit = np.nonzero(s.crit_unmet.values[i0:] > 1e-6)[0]
        rep[key] = dict(bat_kwh=r.bat_kwh, tank_kg=r.tank_kg, tes_kwh=r.tes_kwh, fail_h=int(hit[0]) if len(hit) else None,
                        **series(seg, r, ["pv", "demand", "bat_p", "fc_p", "crit_unmet", "soc", "h2_pct", "tes_pct"]))
    dump("replay", dict(window=WINDOW, offset_h=-24, blackout_h=REPLAY_H, stress_hours=CRITERIA["stress_hours"], **rep))

    # —— 冬季一周 ——
    s = simulate(inp_f, record=True, **args_of(fin))["series"]
    wk = s.loc[WEEK[0]:WEEK[1]]
    dump("week", dict(start=str(wk.index[0]), **series(wk, fin, ["pv", "demand", "bat_p", "fc_p", "ely_p", "curtail",
                                                                 "tes_heater", "heat_rec", "tes_out", "soc", "h2_pct",
                                                                 "tes_pct"])))

    # —— 1 月整月（三维模型）：监测设备在这个月里必须一直有电 ——
    mo = s.loc[MONTH[0]:MONTH[1]]
    assert mo.crit_unmet.max() < 1e-6, "1 月里关键负荷有缺电，三维模型的“运行中”不成立"
    dump("month", dict(start=str(mo.index[0]), **series(mo, fin, ["pv", "demand", "bat_p", "fc_p", "ely_p",
                                                                  "tes_heater", "heat_rec", "tes_out", "soc", "h2_pct",
                                                                  "tes_pct"])))

    # —— 月度 ——
    h = tech_params(fin.tech)
    q = pd.Series(inp_f.q_heat, index=s.index)
    m = pd.DataFrame({"pv": s.pv, "demand": s.demand, "curtail": s.curtail,
                      "h2_in": s.ely_p / (h["lhv"] / h["ely_eff"] + h["comp_kwh_per_kg"]),
                      "h2_out": s.fc_p / (h["lhv"] * h["fc_eff"]), "tes": s.tes_out, "rec": s.heat_rec,
                      "hp": (q - s.tes_out - s.heat_rec).clip(lower=0)}).groupby(s.index.month).sum() / yrs
    dump("monthly", {k: r1(m[k], 1) for k in m.columns})

    # —— 滑块查表：定型路线，其余容量固定，只变电池与储氢 ——
    c = np.array([(fin.pv_kwp, b, fin.fc_kw, t, fin.tes_kwh) for b in LOOKUP["bat"] for t in LOOKUP["tank"]], float)
    run = lambda inp, **kw: simulate(inp, c[:, 0], c[:, 1], fin.ely_kw, c[:, 2], c[:, 3], tes_kwh=c[:, 4], tech=fin.tech, **kw)
    sim = run(inp_f)
    cost = npc(sim, tech=fin.tech, pv_tech=fin.pv_tech)["npc"]
    hold = np.full(len(c), MAX_H)
    for st in STRESS_STARTS:
        x = run(with_blackout(inp_f, st, MAX_H), track_from=st)["first_crit_h"]
        hold = np.minimum(hold, np.where((x < 0) | (x > MAX_H), MAX_H, x))
    dump("lookup", dict(pv_kwp=fin.pv_kwp, fc_kw=fin.fc_kw, tes_kwh=fin.tes_kwh, bat=LOOKUP["bat"], tank=LOOKUP["tank"],
                        unmet_h=[int(v) for v in sim["unmet_hours_total"]], endurance_h=[int(v) for v in hold],
                        npc_wan=r1(cost / 1e4, 1)))
    print("→", *sorted(p.name for p in OUT.glob("*.json")))


def dump(name, obj):
    (OUT / f"{name}.json").write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


if __name__ == "__main__":
    main()
