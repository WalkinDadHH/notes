"""方案比较的统一口径：图、报告、网页、极端情景都从这里取同一组方案。

  开题配置           开题时的 60 kWp / 300 kWh / PEM 20/15 kW / 25 kg，同一准则下复核
  纯光储             改进阶梯 M1（成熟①）
  成熟光储氢         改进阶梯 M2（成熟②：PEM + 35 MPa，单面、倾角 = 纬度、交流配电）
  C 经济版           params.COMPARE_ROUTE 细网格定型（results/final_compare.csv）
  定型 · C 热集成版  params.MAIN_ROUTE 细网格定型（results/final_config.csv）
"""
from pathlib import Path
import pandas as pd
from model.solar import pv_power
from model.system import make_inputs
from model.params import PV_TECH

RES = Path(__file__).resolve().parent.parent / "results"
LABELS = dict(base="开题配置", pure="纯光储", mature="成熟光储氢", econ="C 经济版", final="定型 · C 热集成版")


def tech_of(r):
    return None if pd.isna(r.tech) or r.tech in ("-", "") else r.tech


def dc_of(r):
    v = r.get("dc_bus", False)
    return False if pd.isna(v) else str(v).lower() in ("true", "1", "1.0")


def inputs_for(w, L, r):
    """按方案的光伏选项与是否直流母线建仿真输入。"""
    return make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH[r.pv_tech]), dc_bus=dc_of(r))


def load():
    """返回 {键: 方案行}，键见 LABELS。行内含 endurance_h。"""
    summ = pd.read_csv(RES / "design_summary.csv")
    pick = lambda key: summ[summ.case.str.startswith(key)].iloc[0]
    out = dict(base=pick("开题配置"), pure=pick("M1"), mature=pick("M2"),
               econ=pd.read_csv(RES / "final_compare.csv").iloc[0],
               final=pd.read_csv(RES / "final_config.csv").iloc[0])
    for k, r in out.items():
        r["label"] = LABELS[k]
    return out
