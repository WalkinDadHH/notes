"""结题报告用图。数字全部来自 results/*.csv 与逐时仿真，不手填。

python -m analysis.figures                → results/figures/swiss/ 与 results/figures/journal/
python -m analysis.figures --style swiss  只出一种风格
每张图同时输出 PDF（矢量，LaTeX 用）和 PNG（预览、网页、PPT 用）。

数据来源：
  定型配置   results/final_config.csv   ← python -m analysis.refine
  可行解     results/refine.csv         ← 同上
  方案比较   analysis.schemes（design_summary.csv ← analysis.improve；final_compare.csv ← refine --compare）
  改进阶梯   results/improve_ladder.csv ← python -m analysis.improve
  逐时序列   model.system.simulate(record=True)，气象 data/raw/
"""
import argparse
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout, tech_params
from model.params import PV_TECH, CRITERIA, BATTERY, CRITICAL, EXTREME, PRICE_YEAR
import analysis.schemes as SC

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "results"
MM = 1 / 25.4
W = 160 * MM                        # 报告正文宽度
WINDOW = "2023-01-12 00:00"         # 定型配置续航最紧的窗口（见 final_config.csv 的 h_2023-01）
WEEK = ("2023-01-08", "2023-01-14")
BLACKOUT_H = 120                    # 压力测试图里断光持续到两方案都失守

STYLES = {
    # 沿用开题汇报的瑞士风：克莱因蓝为唯一强调色，黑白灰承载其余信息，图内大标题直接给结论
    "swiss": NS(font=["Helvetica Neue", "Heiti SC"], size=8.5, headline=True, letters=False,
                pv="#c9c9c5", bat="#0a0a0a", h2="#002FA7", tes="#7d93ff", hp="#e4e4e1", om="#e4e4e1",
                hero="#002FA7", alt="#0a0a0a", mute="#a3a3a3", shade="#f0f0ee", ink="#0a0a0a",
                sub="#525252", grid="#e0e0e0", fail="#0a0a0a",
                cmap=LinearSegmentedColormap.from_list("swiss", ["#d6dcf5", "#002FA7"])),
    # 期刊风：Okabe–Ito 色盲友好配色，小字号，面板字母 a/b/c，结论交给图注
    "journal": NS(font=["Arial", "Heiti SC"], size=7.5, headline=False, letters=True,
                  pv="#E69F00", bat="#4D4D4D", h2="#0072B2", tes="#D55E00", hp="#CFCFCF", om="#CFCFCF",
                  hero="#0072B2", alt="#4D4D4D", mute="#999999", shade="#F0F0F0", ink="#000000",
                  sub="#444444", grid="#E6E6E6", fail="#D55E00",
                  cmap=plt.get_cmap("viridis")),
}


# ───────────────────────── 样式 ─────────────────────────

def use(st):
    plt.rcdefaults()
    plt.rcParams.update({
        "font.family": st.font, "font.size": st.size, "axes.unicode_minus": False,
        "axes.titlesize": st.size + 0.5, "axes.labelsize": st.size, "legend.fontsize": st.size - 0.5,
        "xtick.labelsize": st.size - 0.5, "ytick.labelsize": st.size - 0.5,
        "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6,
        "axes.edgecolor": st.ink, "axes.labelcolor": st.ink, "xtick.color": st.sub, "ytick.color": st.sub,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 3, "ytick.major.size": 3,
        "legend.frameon": False, "legend.handlelength": 1.4, "lines.linewidth": 1.3,
        "pdf.fonttype": 42, "svg.fonttype": "none", "savefig.dpi": 220, "figure.dpi": 110,
    })


def deco(ax, st, grid="y"):
    if st.headline:                                  # 瑞士风：去掉左轴线，只留浅色横向网格
        ax.spines["left"].set_visible(False)
        ax.tick_params(axis="y", length=0)
    if grid:
        ax.grid(axis=grid, color=st.grid, lw=0.5)
        ax.set_axisbelow(True)


def panel(ax, st, i, label):
    if st.letters:
        ax.text(-0.075, 1.04, "abcdef"[i], transform=ax.transAxes, weight="bold", size=st.size + 2,
                va="bottom", ha="left")
        ax.set_title(label, loc="left", size=st.size, color=st.ink, pad=4, x=0.0)
    else:
        ax.set_title(label, loc="left", size=st.size + 0.5, weight="bold", color=st.ink, pad=6)


def headline(fig, st, text):
    if st.headline:
        fig.suptitle(text, x=0.0, ha="left", size=st.size + 4, weight="bold", color=st.ink)


def save(fig, st, name):
    out = RES / "figures" / st.key
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / f"{name}.pdf", metadata={"CreationDate": None})   # 不写时间戳，重跑不产生无意义的 git 改动
    fig.savefig(out / f"{name}.png")
    plt.close(fig)


# ───────────────────────── 数据 ─────────────────────────

def args_of(r):
    tech = None if pd.isna(r.tech) or r.tech in ("-", "") else r.tech
    return dict(pv_kwp=r.pv_kwp, bat_kwh=r.bat_kwh, ely_kw=r.ely_kw, fc_kw=r.fc_kw, tank_kg=r.tank_kg,
                tes_kwh=r.tes_kwh, tech=tech)


def load_data():
    w = load_weather(); L = build_load(w)
    sc = SC.load()
    final, pure = sc["final"], sc["pure"]
    refine = pd.read_csv(RES / "refine.csv")
    sim = lambda r, inp, **kw: simulate(inp, record=True, **args_of(r), **kw)["series"]
    d = NS(w=w, L=L, sc=sc, final=final, refine=refine, pure=pure,
           inp_f=SC.inputs_for(w, L, final), inp_a=SC.inputs_for(w, L, pure))
    d.s_final = sim(final, d.inp_f)
    d.s_bo_f = sim(final, with_blackout(d.inp_f, WINDOW, BLACKOUT_H))
    d.s_bo_a = sim(pure, with_blackout(d.inp_a, WINDOW, BLACKOUT_H))
    d.years = len(w) / 8766
    return d


def soc_pct(s, r):
    """电池可用区间内的荷电百分比（0 = 放到下限，100 = 充到上限）。"""
    return (s.soc - BATTERY["soc_min"]) / (BATTERY["soc_max"] - BATTERY["soc_min"]) * 100


# ───────────────────────── 图 1 三条闭环的季节节律 ─────────────────────────

def fig_seasons(d, st):
    s, f = d.s_final, d.final
    q_heat = pd.Series(d.inp_f.q_heat, index=s.index)
    hp_heat = (q_heat - s.tes_out - s.heat_rec).clip(lower=0)
    m = pd.DataFrame({
        "pv": s.pv, "demand": s.demand, "curtail": s.curtail,
        "h2_in": s.ely_p, "h2_out": s.fc_p,
        "tes": s.tes_out, "rec": s.heat_rec, "hp": hp_heat,
    }).groupby(s.index.month).sum() / d.years
    h = tech_params(f.tech)
    m["h2_in"] = m.h2_in / (h["lhv"] / h["ely_eff"] + h["comp_kwh_per_kg"])
    m["h2_out"] = m.h2_out / (h["lhv"] * h["fc_eff"])
    x = np.arange(1, 13)

    fig, axes = plt.subplots(3, 1, figsize=(W, 128 * MM), sharex=True, layout="constrained")
    a, b, c = axes
    a.bar(x - 0.2, m.pv / 1000, 0.4, color=st.pv, label="光伏可发电量")
    a.bar(x + 0.2, m.demand / 1000, 0.4, color=st.bat, label="站内用电")
    a.set_ylabel("MWh / 月")
    a.set_ylim(0, m.pv.max() / 1000 * 1.3)
    a.legend(loc="upper right", ncol=2)
    panel(a, st, 0, "电：光伏全年富余，缺口在冬季的夜里和连阴天")

    b.bar(x, m.h2_in, 0.6, color=st.h2, label="制氢（盈余电电解）")
    b.bar(x, -m.h2_out, 0.6, color=st.h2, alpha=0.4, label="用氢（rSOC 发电）")
    b.axhline(0, color=st.ink, lw=0.6)
    b.set_ylabel("kg / 月")
    b.legend(loc="upper center", ncol=2)
    win = m.loc[[11, 12, 1, 2], "h2_in"].sum() / m.h2_in.sum()
    panel(b, st, 1, f"氢：{win:.0%} 的制氢和用氢在 11–2 月，晴天制、夜里和连阴天用")

    c.bar(x, m.tes / 1000, 0.6, color=st.tes, label="砂石储热仓")
    c.bar(x, m.rec / 1000, 0.6, bottom=m.tes / 1000, color=st.h2, label="rSOC 余热")
    c.bar(x, m.hp / 1000, 0.6, bottom=(m.tes + m.rec) / 1000, color=st.hp, label="热泵")
    c.set_ylabel("MWh（热）/ 月")
    c.legend(loc="upper center", ncol=3)
    share = (m.tes.sum() + m.rec.sum()) / (m.tes.sum() + m.rec.sum() + m.hp.sum())
    panel(c, st, 2, f"热：{share:.0%} 的供暖与热水不靠热泵")
    c.set_xticks(x); c.set_xticklabels([f"{i}月" for i in x])
    for ax in axes:
        deco(ax, st)
    headline(fig, st, "定型方案全年运行：电、氢、热三条闭环")
    save(fig, st, "01_三条闭环季节节律")


# ───────────────────────── 图 2 方案成本 ─────────────────────────

def fig_cost(d, st):
    q_heat = d.inp_f.q_heat.sum() / d.years
    rows = [(d.sc[k].label, d.sc[k], d.sc[k].endurance_h) for k in ("base", "pure", "mature", "econ", "final")]

    fig, ax = plt.subplots(figsize=(W, 72 * MM), layout="constrained")
    y = np.arange(len(rows))[::-1]
    parts = (("capex_pv", st.pv, "光伏"), ("capex_bat", st.bat, "电池"),
             ("capex_h2", st.h2, "氢路"), ("capex_tes", st.tes, "储热仓"))
    xmax = max(max(r.npc, r.npc_2026) for _, r, _ in rows) / 1e4
    for yi, (lab, r, eh) in zip(y, rows):
        left = 0.0
        for k, col, name in parts:
            v = r[k] / 1e4
            ax.barh(yi, v, left=left, color=col, height=0.62, label=name if yi == y[0] else None)
            left += v
        ax.barh(yi, r.npc / 1e4 - left, left=left, color=st.om, height=0.62,
                label="运维 + 更换" if yi == y[0] else None)
        bold = lab.startswith("定型")
        hs = (r.tes_out + r.heat_rec) / q_heat
        ax.plot([r.npc_2026 / 1e4] * 2, [yi - 0.36, yi + 0.36], color=st.ink, lw=1.1,
                label="2026 现价" if yi == y[0] else None)
        ax.text(max(r.npc, r.npc_2026) / 1e4 + xmax * 0.012, yi,
                f"{r.npc/1e4:.1f} 万（2026 价 {r.npc_2026/1e4:.0f}）· 续航 {eh:.0f} h · 免热泵 {hs:.0%}",
                va="center",
                size=st.size - 0.5, color=st.ink, weight="bold" if bold else "normal")
    ax.set_yticks(y)
    ax.set_yticklabels([l for l, _, _ in rows])
    for t in ax.get_yticklabels():
        if t.get_text().startswith("定型"):
            t.set_weight("bold"); t.set_color(st.hero)
    ax.set_xlim(0, xmax * 1.62)
    ax.set_xlabel(f"25 年全寿命成本（万元，{PRICE_YEAR} 年建站、{PRICE_YEAR} 年价格；竖线为 2026 现价）")
    ax.legend(ncol=6, loc="lower left", bbox_to_anchor=(0, 1.0), handlelength=1.0, columnspacing=1.2)
    deco(ax, st, grid="x")
    if st.headline:
        ax.spines["left"].set_visible(True)
        ax.tick_params(axis="y", length=0)
    f, e, p = d.sc["final"], d.sc["econ"], d.sc["pure"]
    headline(fig, st, f"光储氢约为纯光储的 {f.npc / p.npc:.0%}；热集成版多花 {(f.npc - e.npc)/1e4:.0f} 万，换 {f.heat_share:.0%} 热闭环")
    save(fig, st, "02_方案成本对比")


# ───────────────────────── 图 3 断光压力测试 ─────────────────────────

def fail_hour(s, i0):
    hit = np.nonzero(s.crit_unmet.values[i0:] > 1e-6)[0]
    return int(hit[0]) if len(hit) else None


def fig_stress(d, st):
    f, a = d.final, d.pure
    i0 = d.s_bo_f.index.get_indexer([pd.Timestamp(WINDOW)], method="nearest")[0]
    sl = slice(i0 - 24, i0 + BLACKOUT_H + 12)
    hrs = np.arange(sl.start, sl.stop) - i0
    sf, sa = d.s_bo_f.iloc[sl], d.s_bo_a.iloc[sl]
    hf, ha = fail_hour(d.s_bo_f, i0), fail_hour(d.s_bo_a, i0)
    crit_h = CRITERIA["stress_hours"]

    fig, axes = plt.subplots(3, 1, figsize=(W, 120 * MM), sharex=True, layout="constrained",
                             gridspec_kw=dict(height_ratios=[1, 1, 0.75]))
    p, q, r = axes
    p.plot(hrs, soc_pct(sa, a), color=st.alt, label=f"纯光储（电池 {a.bat_kwh:.0f} kWh）")
    p.plot(hrs, soc_pct(sf, f), color=st.hero, label=f"定型光储氢（电池 {f.bat_kwh:.0f} kWh）")
    p.set_ylabel("电池电量 %")
    p.legend(loc="upper right")
    panel(p, st, 0, f"电池：纯光储靠 {a.bat_kwh:,.0f} kWh 硬撑，光储氢的小电池几小时就交棒")

    q.plot(hrs, sf.h2_kg / f.tank_kg * 100, color=st.h2, label=f"储氢（{f.tank_kg:.0f} kg）")
    q.plot(hrs, sf.tes_kwh / f.tes_kwh * 100, color=st.tes, ls="--", label=f"储热仓（{f.tes_kwh:.0f} kWh 热）")
    q.set_ylabel("剩余 %")
    q.legend(loc="upper right")
    h2_empty = int(np.argmax(sf.h2_kg.values[24:] < 0.01 * f.tank_kg))
    panel(q, st, 1, f"定型方案：电池放空后 rSOC 接力，{f.tank_kg:.0f} kg 氢在第 {h2_empty} h 前后用尽")

    r.plot(hrs, sa.crit_unmet, color=st.alt, label="纯光储")
    r.plot(hrs, sf.crit_unmet, color=st.hero, label="定型光储氢")
    top = max(sa.crit_unmet.max(), sf.crit_unmet.max(), 1.0)
    for h_, col, name, side in ((ha, st.alt, "纯光储", -1), (hf, st.hero, "光储氢", 1)):
        if h_ is not None:
            r.plot([h_, h_], [0, top * 1.18], color=col, lw=0.6, ls=(0, (1, 1.5)))
            r.text(h_ + side * 1.2, top * 1.22, f"{name}第 {h_} h 失守", ha="right" if side < 0 else "left",
                   va="center", size=st.size - 0.5, color=col, weight="bold",
                   bbox=dict(fc="white", ec="none", pad=0.6))   # 盖住 72 h 设计线，避免压字
    r.set_ylim(-top * 0.05, top * 1.42)
    r.set_ylabel("关键负荷缺电 kW")
    r.set_xlabel("断光后小时数（2023 年 1 月最不利窗口起算）")
    panel(r, st, 2, "关键负荷（监测设备 + 生存供暖）")

    for ax in axes:
        ax.axvspan(0, BLACKOUT_H, color=st.shade, lw=0)
        ax.axvline(crit_h, color=st.ink, lw=0.7, ls=(0, (2, 2)))
        deco(ax, st)
    p.text(crit_h + 1, 103, f"设计准则 {crit_h} h", size=st.size - 1, color=st.ink, va="bottom")
    p.set_ylim(-3, 112); q.set_ylim(-3, 112)
    r.set_xlim(hrs[0], hrs[-1])
    r.set_xticks(np.arange(0, hrs[-1] + 1, 24))
    headline(fig, st, f"完全断光：两方案都过 {crit_h} h 准则，光储氢多撑 {hf - ha} 小时、成本约为 {f.npc / a.npc:.0%}"
             if hf and ha else f"完全断光 {BLACKOUT_H} h 压力测试")
    save(fig, st, "03_断光压力测试")


# ───────────────────────── 图 4 冬季一周 ─────────────────────────

def fig_week(d, st):
    f = d.final
    s = d.s_final.loc[WEEK[0]:WEEK[1]]
    direct = np.minimum(s.pv, s.demand)
    dis = s.bat_p.clip(lower=0)
    fig, axes = plt.subplots(2, 1, figsize=(W, 100 * MM), sharex=True, layout="constrained",
                             gridspec_kw=dict(height_ratios=[1.25, 1]))
    a, b = axes
    a.stackplot(s.index, direct, dis, s.fc_p, colors=[st.pv, st.bat, st.h2], lw=0,
                labels=["光伏直供", "电池放电", "rSOC 发电"])
    a.plot(s.index, s.pv, color=st.sub, lw=0.6, ls=(0, (1, 1)), label="光伏出力")
    a.plot(s.index, s.demand, color=st.ink, lw=0.9, label="用电")
    a.set_ylabel("kW")
    a.legend(loc="upper left", ncol=5, bbox_to_anchor=(0, 1.0))
    a.set_ylim(0, max(s.pv.max(), s.demand.max()) * 1.25)
    panel(a, st, 0, "电力平衡：白天光伏直供并给电池充电，夜里电池先放、rSOC 补上")

    b.plot(s.index, soc_pct(s, f), color=st.bat, label="电池")
    b.plot(s.index, s.h2_kg / f.tank_kg * 100, color=st.h2, label="储氢")
    b.plot(s.index, s.tes_kwh / f.tes_kwh * 100, color=st.tes, ls="--", label="储热仓")
    b.set_ylabel("荷电 / 剩余 %")
    b.set_ylim(-3, 108)
    b.legend(loc="lower right", ncol=3, bbox_to_anchor=(1, 1.0))
    low = (s.h2_kg / f.tank_kg).min()
    panel(b, st, 1, f"储能状态：电池每天充放一轮，连阴天靠储氢兜底（最低 {low:.0%}）")
    b.xaxis.set_major_locator(mdates.DayLocator())
    b.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    for ax in axes:
        deco(ax, st)
    headline(fig, st, "冬季一周逐时运行（2023 年 1 月，定型方案）")
    save(fig, st, "04_冬季一周运行")


# ───────────────────────── 图 5 定型选择 ─────────────────────────

def fig_select(d, st):
    r, f = d.refine, d.final
    floor, tol = CRITERIA["select_endurance_h"], CRITERIA["select_cost_tol"]
    x0, x1 = r.endurance_h.min() - 2, r.endurance_h.max() + 2
    c0 = r[r.endurance_h >= floor].npc.min() / 1e4
    fig, ax = plt.subplots(figsize=(W, 82 * MM), layout="constrained")
    jit = (np.random.default_rng(0).random(len(r)) - 0.5) * 0.5        # 续航为整数小时，轻微横向错开避免重叠
    ax.axvspan(x0, floor, color=st.shade, lw=0, zorder=0)
    ax.fill_between([floor, x1], c0, c0 * (1 + tol), color=st.hero, alpha=0.08, lw=0, zorder=0)
    ax.axvline(floor, color=st.ink, lw=0.7, ls=(0, (2, 2)))
    sc = ax.scatter(r.endurance_h + jit, r.npc / 1e4, c=r.heat_share * 100, cmap=st.cmap, s=16,
                    edgecolor="white", lw=0.3, zorder=3)
    ylo, yhi = r.npc.min() / 1e4 - 1.8, r.npc.max() / 1e4 + 1.9
    ax.text(floor - 0.5, yhi - 0.12, f"续航不足 {floor} h（72 h × 1.25），淘汰", ha="right", va="top",
            size=st.size - 1, color=st.sub)
    ax.text(r.endurance_h.max() + 0.5, c0 * (1 + tol), f"同价带：与最低成本相差 ≤ {tol:.0%}", ha="right", va="bottom",
            size=st.size - 1, color=st.hero)
    ax.scatter([f.endurance_h], [f.npc / 1e4], s=110, facecolor="none", edgecolor=st.ink, lw=1.1, zorder=4)
    ax.annotate(f"定型：{f.pv_kwp:g} kWp · {f.bat_kwh:.0f} kWh · {f.tank_kg:.0f} kg · 储热 {f.tes_kwh:.0f} kWh\n"
                f"{f.npc/1e4:.1f} 万 · 续航 {f.endurance_h:.0f} h · 不靠热泵供热 {f.heat_share:.0%}",
                xy=(f.endurance_h, f.npc / 1e4), xytext=(x1 - 0.5, yhi - 0.25), ha="right", va="top",
                size=st.size - 0.5, color=st.ink, weight="bold",
                arrowprops=dict(arrowstyle="-", color=st.ink, lw=0.6))
    ok = r[r.endurance_h >= floor].sort_values("npc")
    cheap = ok.iloc[0]
    if abs(cheap.npc - f.npc) > 1:
        ax.annotate(f"同价带内成本最低：{cheap.pv_kwp:g} kWp · 储热 {cheap.tes_kwh:.0f} kWh，{cheap.npc/1e4:.1f} 万，"
                    f"不靠热泵 {cheap.heat_share:.0%}",
                    xy=(cheap.endurance_h, cheap.npc / 1e4), xytext=(x1 - 0.5, cheap.npc / 1e4 - 0.9), ha="right",
                    size=st.size - 1, color=st.sub, arrowprops=dict(arrowstyle="-", color=st.sub, lw=0.5))
    out = r[r.endurance_h < floor].sort_values("npc").iloc[0]
    ax.annotate(f"{out.pv_kwp:g} kWp 方案：{out.npc/1e4:.1f} 万，热闭环 {out.heat_share:.0%}，\n"
                f"但续航只有 {out.endurance_h:.0f} h",
                xy=(out.endurance_h, out.npc / 1e4), xytext=(x0 + 0.4, ylo + 0.15), va="bottom",
                ha="left", size=st.size - 1, color=st.sub, arrowprops=dict(arrowstyle="-", color=st.sub, lw=0.5))
    ax.set_xlim(x0, x1)
    ax.set_ylim(ylo, yhi)
    ax.set_xlabel("关键负荷续航（h，三个最不利窗口取最短）")
    ax.set_ylabel("全寿命成本（万元）")
    cb = fig.colorbar(sc, ax=ax, pad=0.01, aspect=30)
    cb.set_label("不靠热泵的供热占比 %")
    cb.outline.set_visible(False)
    deco(ax, st, grid="both")
    headline(fig, st, f"在 {len(r)} 组可行配置中选定型：先保续航，再比成本，同价比热闭环，再比光伏")
    save(fig, st, "05_定型配置选择")


# ───────────────────────── 图 0 资源与负荷 ─────────────────────────

def fig_resource(d, st):
    pv = pv_power(d.w, 1.0, p=PV_TECH[d.final.pv_tech])
    m = pd.DataFrame({"ghi": d.w.ghi, "poa": pv.poa}).groupby(d.w.index.month).sum() / d.years / 1000
    hb = d.w.hour_bj.values
    prof = lambda mon, col: pd.Series(d.L[col].values[d.w.index.month == mon]).groupby(hb[d.w.index.month == mon]).mean()
    fig, (a, b) = plt.subplots(1, 2, figsize=(W, 62 * MM), layout="constrained", gridspec_kw=dict(width_ratios=[1.15, 1]))
    x = np.arange(1, 13)
    a.bar(x - 0.2, m.ghi, 0.4, color=st.mute, label="水平面")
    a.bar(x + 0.2, m.poa, 0.4, color=st.hero, label=f"{PV_TECH[d.final.pv_tech]['tilt']:.0f}° 倾斜面")
    a.set_xticks(x); a.set_xticklabels([str(i) for i in x]); a.set_xlabel("月")
    a.set_ylabel("kWh/m² · 月"); a.legend(loc="upper right", ncol=2)
    a.set_ylim(0, max(m.poa.max(), m.ghi.max()) * 1.3)
    panel(a, st, 0, "辐照：按冬季设计的大倾角把冬天的太阳“扶起来”")
    h = np.arange(24)
    for mon, col, name in ((1, st.ink, "1 月"), (7, st.hero, "7 月")):
        b.plot(h, prof(mon, "e_total"), color=col, label=f"{name}总用电")
    b.plot(h, prof(1, "e_base"), color=st.sub, lw=0.9, ls=(0, (3, 2)), label="非暖通基荷")
    b.axhline(CRITICAL["crit_kw"], color=st.fail, lw=0.7, ls=(0, (1, 1.5)))
    b.text(23, CRITICAL["crit_kw"] + 0.2, f"监测 + 净水 {CRITICAL['crit_kw']:.1f} kW", ha="right", va="bottom",
           size=st.size - 1, color=st.fail)
    b.set_xticks([0, 6, 12, 18, 23]); b.set_xlabel("北京时间（时）"); b.set_ylabel("kW")
    b.set_ylim(0, None); b.legend(loc="lower center", ncol=3, handlelength=1.2, columnspacing=0.8)
    panel(b, st, 1, "负荷：冬季夜里靠热泵采暖，夏季午后靠热泵制冷")
    for ax in (a, b):
        deco(ax, st)
    headline(fig, st, f"敦煌代表点 {d.years:.0f} 年逐时资源与站内负荷")
    save(fig, st, "00_资源与负荷")


# ───────────────────────── 图 6 灵敏度 ─────────────────────────

def fig_sensitivity(d, st):
    p = RES / "sensitivity.csv"
    if not p.exists():
        return
    s = pd.read_csv(p)
    b0 = s[s.param == "base"].iloc[0]
    g = s[s.param != "base"]
    lo, hi = g[g.factor < 1].set_index("param"), g[g.factor > 1].set_index("param")
    span = (hi.final_npc - lo.final_npc).abs().sort_values()
    span = span[span > 1.0]          # 定型路线不用的设备（如 PEM 电堆）单价无影响，不画空行
    base = b0.final_npc / 1e4
    fig, ax = plt.subplots(figsize=(W, 78 * MM), layout="constrained")
    y = np.arange(len(span))
    for yi, k in zip(y, span.index):
        for v, col, lab in ((lo.final_npc[k] / 1e4, st.hero, "单价 −30%"), (hi.final_npc[k] / 1e4, st.alt, "单价 +30%")):
            ax.barh(yi, v - base, left=base, color=col, height=0.6, label=lab if yi == y[-1] else None)
        same = lo.reselect[k] == hi.reselect[k] == b0.reselect
        pa, pb = sorted((lo.premium_over_econ[k] / 1e4, hi.premium_over_econ[k] / 1e4))
        rng = f"{pa:.0f}" if round(pa) == round(pb) else f"{pa:.0f}–{pb:.0f}"
        tag = f"比经济版贵 {rng} 万" + ("，定型不变" if same else "，定型微调")
        ax.text(base + span.max() / 1e4 * 0.62, yi, tag, va="center", size=st.size - 1, color=st.sub)
    ax.axvline(base, color=st.ink, lw=0.8)
    ax.set_yticks(y); ax.set_yticklabels([lo.label[k] for k in span.index])
    ax.set_xlabel(f"定型配置全寿命成本（万元，基准 {base:.1f}）")
    ax.set_xlim(base - span.max() / 1e4 * 0.7, base + span.max() / 1e4 * 1.35)
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1.0), ncol=2)
    deco(ax, st, grid="x")
    if st.headline:
        ax.tick_params(axis="y", length=0)
    r0, r1 = g.ratio_pure_over_final.min(), g.ratio_pure_over_final.max()
    headline(fig, st, f"单价与折现率各 ±30%：纯光储始终是光储氢的 {r0:.1f}–{r1:.1f} 倍")
    save(fig, st, "06_灵敏度")


# ───────────────────────── 图 7 极端情景 ─────────────────────────

def fig_extremes(d, st):
    pc, px = RES / "endurance_curve.csv", RES / "extremes.csv"
    if not (pc.exists() and px.exists()):
        return
    c, x = pd.read_csv(pc), pd.read_csv(px)
    cols = {"纯光储": st.alt, "成熟光储氢": st.mute, "C 经济版": st.sub, "定型": st.hero}
    fig, ax = plt.subplots(figsize=(W, 74 * MM), layout="constrained")
    for name, col in cols.items():
        s = c[c.scheme == name]
        ax.plot(s.pv_factor * 100, s.endurance_h, color=col, marker="o", ms=3, lw=1.6 if name == "定型" else 1.1,
                label=name)
    xr = c.pv_factor.max() * 100
    for need, lab in ((CRITERIA["stress_hours"], f"设计准则 {CRITERIA['stress_hours']} h"),
                      (EXTREME["dust_hours"], f"加测情景 {EXTREME['dust_hours']} h")):
        ax.axhline(need, color=st.ink, lw=0.6, ls=(0, (2, 2)))
        ax.text(xr, need - 3, lab, size=st.size - 1, color=st.sub, va="top", ha="right")
    cold = x[(x.scenario == "寒潮叠加阴雪")].set_index("scheme").endurance_h
    for name, col in cols.items():
        if name in cold:
            ax.scatter([EXTREME["cold_pv_factor"] * 100], [cold[name]], marker="x", s=30, color=col, zorder=4)
    if "定型" in cold:
        ax.annotate(f"× 寒潮 {EXTREME['cold_t_air']:.0f} ℃ 叠加阴雪", xy=(EXTREME["cold_pv_factor"] * 100, cold["定型"]),
                    xytext=(EXTREME["cold_pv_factor"] * 100 + 2, CRITERIA["stress_hours"] - 22), size=st.size - 1, color=st.sub,
                    arrowprops=dict(arrowstyle="-", color=st.sub, lw=0.5))
    ax.axvline(EXTREME["dust_pv_factor"] * 100, color=st.mute, lw=0.6, ls=(0, (1, 1.5)))
    ax.text(EXTREME["dust_pv_factor"] * 100 + 0.5, c.endurance_h.max() * 0.98,
            f"沙尘暴（光伏剩 {EXTREME['dust_pv_factor']:.0%}）", size=st.size - 1, color=st.sub, va="top")
    ax.set_xlabel("情景期间光伏剩余出力（%）")
    ax.set_ylabel("关键负荷续航（h）")
    ax.set_xlim(-1, c.pv_factor.max() * 100 + 1)
    ax.set_ylim(0, None)
    ax.legend(loc="upper left", bbox_to_anchor=(0, 0.93))
    deco(ax, st, grid="both")
    g = c.pivot(index="pv_factor", columns="scheme", values="endurance_h")
    gap = g["定型"] - g["纯光储"]
    headline(fig, st, f"无论剩多少光照，定型方案都比纯光储多撑 {gap.min():.0f}–{gap.max():.0f} 小时")
    save(fig, st, "07_极端情景")


# ───────────────────────── 图 8 改进阶梯 ─────────────────────────

def fig_ladder(d, st):
    p = RES / "improve_ladder.csv"
    if not p.exists():
        return
    g = pd.read_csv(p)
    g = g[(g.price_year.astype(str) == PRICE_YEAR) & (g.key != "S4")].reset_index(drop=True)
    names = {"M1": "成熟①\n纯光储", "M2": "成熟②\nPEM 高压罐", "S1": "+ 双面\n+ 静电除尘", "S2": "+ 冬季\n倾角 60°",
             "S3": "+ 直流母线\n= C 经济版", "R1": "rSOC\n+ 高压罐", "R2": "rSOC + 氢化物\n+ 储热仓"}
    g = g[g.key.isin(names)].reset_index(drop=True)
    x = np.arange(len(g))
    col = [st.hero if k in ("S3", "R2") else (st.alt if k.startswith("M") else st.mute) for k in g.key]
    fig, axes = plt.subplots(3, 1, figsize=(W, 128 * MM), sharex=True, layout="constrained")
    a, b, c = axes
    a.bar(x, g.pv_kwp, 0.6, color=col)
    for xi, r in zip(x, g.itertuples()):
        a.text(xi, r.pv_kwp + 1, f"{r.pv_kwp:.0f}\n弃光 {r.curtail_share:.0%}", ha="center", va="bottom", size=st.size - 1)
    a.set_ylabel("光伏 kWp"); a.set_ylim(0, g.pv_kwp.max() * 1.45)
    m2, s3 = g.set_index("key").pv_kwp[["M2", "S3"]]
    panel(a, st, 0, f"光伏装机：双面、静电除尘、冬季倾角把光伏从 {m2:.0f} kWp 压到 {s3:.0f} kWp")
    b.bar(x, g.elec_mwh, 0.6, color=col)
    for xi, r in zip(x, g.itertuples()):
        b.text(xi, r.elec_mwh + 0.4, f"{r.elec_mwh:.1f}\n免热泵 {r.heat_share:.0%}", ha="center", va="bottom",
               size=st.size - 1)
    b.set_ylabel("站内年用电 MWh"); b.set_ylim(0, g.elec_mwh.max() * 1.3)   # 柱状图从 0 起，不截断
    panel(b, st, 1, "站内用电：直流母线省 8%，储热仓与余热再替掉一部分热泵")
    c.bar(x, g.npc_2035 / 1e4, 0.6, color=col, label=f"{PRICE_YEAR} 价")
    c.scatter(x, g.npc_2026 / 1e4, marker="_", s=260, color=st.ink, lw=1.4, zorder=3, label="2026 现价")
    c.set_ylabel("全寿命成本 万元"); c.legend(loc="upper center", ncol=2)
    c.set_ylim(0, g.npc_2026.max() / 1e4 * 1.25)   # 线性纵轴、从 0 起：柱高与成本成正比
    panel(c, st, 2, "成本：试验性路线今天贵，规模化后差距收窄")
    c.set_xticks(x); c.set_xticklabels([names[k] for k in g.key], size=st.size - 1)
    for ax in axes:
        deco(ax, st)
    headline(fig, st, "改进阶梯：每加一项改进都重新优化容量，看能效与成本怎么变")
    save(fig, st, "08_改进阶梯")


FIGS = [fig_resource, fig_seasons, fig_cost, fig_stress, fig_week, fig_select, fig_sensitivity, fig_extremes, fig_ladder]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--style", choices=[*STYLES, "all"], default="all")
    keys = list(STYLES) if ap.parse_args().style == "all" else [ap.parse_args().style]
    d = load_data()
    for k in keys:
        st = STYLES[k]; st.key = k
        use(st)
        for fn in FIGS:
            fn(d, st)
        print("→", k, *sorted(p.name for p in (RES / "figures" / k).glob("*.png")))
