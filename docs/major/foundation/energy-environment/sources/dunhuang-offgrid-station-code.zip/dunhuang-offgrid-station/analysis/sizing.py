"""容量扫描：在“11 年真实天气下零缺电”约束下，找纯光储 A 与光储氢 B 的最低成本配置。

python -m analysis.sizing          → results/sizing_A.csv, sizing_B.csv, 终端汇总
"""
import itertools, time
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate
from model.economics import npc

OUT = Path(__file__).resolve().parent.parent / "results"

GRID_A = dict(pv=np.arange(30, 121, 10), bat=np.arange(150, 801, 25))
GRID_B = dict(pv=np.arange(30, 101, 10), bat=np.arange(50, 401, 25),
              ely=[5, 10, 20], fc=[5, 10, 15], tank=[5, 10, 15, 25, 40])
TILTS = [40, 50, 60]


def _frame(sim, cost, tilt):
    keys = ["pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg", "lpsp", "unmet_total",
            "unmet_hours_total", "curtail", "pv", "bat_cycles", "h2_made", "h2_used",
            "h2_min_kg", "fc_hours", "ely_hours", "heat_rec", "water_net_l"]
    df = pd.DataFrame({k: sim[k] for k in keys})
    for k in ("npc", "capex", "capex_pv", "capex_bat", "capex_h2", "lcoe", "bat_life"):
        df[k] = cost[k]
    df["tilt"] = tilt
    return df


def sweep(inputs_by_tilt, scheme):
    rows = []
    for tilt, inp in inputs_by_tilt.items():
        if scheme == "A":
            c = np.array(list(itertools.product(GRID_A["pv"], GRID_A["bat"])), float)
            sim = simulate(inp, c[:, 0], c[:, 1])
        else:
            c = np.array(list(itertools.product(GRID_B["pv"], GRID_B["bat"], GRID_B["ely"],
                                                GRID_B["fc"], GRID_B["tank"])), float)
            sim = simulate(inp, c[:, 0], c[:, 1], c[:, 2], c[:, 3], c[:, 4])
        rows.append(_frame(sim, npc(sim), tilt))
    return pd.concat(rows, ignore_index=True)


def build_inputs():
    w = load_weather(); L = build_load(w)
    return {t: make_inputs(w, L, pv_power(w, 1.0, tilt_deg=t)) for t in TILTS}


def best(df, max_unmet_kwh=0.0):
    ok = df[df.unmet_total <= max_unmet_kwh + 1e-6]
    return ok.sort_values("npc").head(1) if len(ok) else None


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    t0 = time.time()
    inputs = build_inputs()
    A = sweep(inputs, "A"); A.to_csv(OUT / "sizing_A.csv", index=False)
    print(f"A 扫描 {len(A)} 组  {time.time()-t0:.0f}s")
    B = sweep(inputs, "B"); B.to_csv(OUT / "sizing_B.csv", index=False)
    print(f"B 扫描 {len(B)} 组  {time.time()-t0:.0f}s\n")
    cols = ["tilt", "pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg", "npc", "capex",
            "lcoe", "curtail", "h2_used", "unmet_total"]
    for tol in (0.0,):
        a, b = best(A, tol), best(B, tol)
        print(f"═══ 11 年零缺电下的最低成本配置 ═══")
        print("A 纯光储:"); print(a[cols].to_string(index=False))
        print("B 光储氢:"); print(b[cols].to_string(index=False))
        print(f"\nB / A 全寿命成本比 = {float(b.npc.iloc[0]/a.npc.iloc[0]):.2f}")
