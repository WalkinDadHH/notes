"""复算展示中的五种配置，输出两档人民币成本和逐年现金流。

python -m analysis.cost_audit

只复用已有仿真结果并调用当前经济模型；不重新选型、不修改价格。
"""
import json
from pathlib import Path

import numpy as np

from analysis.schemes import load, tech_of
from model.economics import npc
from model.params import H2_TECH, prices

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "成本核算"
ORDER = ("base", "pure", "mature", "econ", "final")


def scalar(value):
    return float(np.asarray(value).reshape(-1)[0])


def audit(row, year):
    tech = tech_of(row) or "PEM+高压罐"
    e = prices(year, tech, row.pv_tech)
    sim = {k: np.atleast_1d(float(v)) for k, v in row.items()
           if isinstance(v, (int, float, np.integer, np.floating))
           and not isinstance(v, (bool, np.bool_))}
    cost = {k: scalar(v) for k, v in
            npc(sim, tech=tech, pv_tech=row.pv_tech, year=year).items()}
    rev = H2_TECH[tech].get("reversible", False)
    has_h2 = row.tank_kg > 0
    lines = [
        ("光伏基础系统", row.pv_kwp, e["pv_cny_per_kwp"], "kWp"),
        ("双面与静电除尘增量", row.pv_kwp, e["pv_extra_cny_per_kwp"], "kWp"),
        ("电池系统", row.bat_kwh, e["bat_cny_per_kwh"], "kWh"),
        ("电池变流器（容量×0.1）", row.bat_kwh * 0.1, e["bat_pcs_cny_per_kw"], "kW"),
        ("PEM 电解系统", 0 if rev else row.ely_kw, e["ely_cny_per_kw"], "kW"),
        ("PEM 燃料电池", 0 if rev else row.fc_kw, e["fc_cny_per_kw"], "kW"),
        ("rSOC 双向机组（按发电功率）", row.fc_kw if rev else 0,
         e.get("rsoc_cny_per_kw", 0), "kW"),
        ("储氢系统（按可存氢质量）", row.tank_kg, e["tank_cny_per_kg"], "kg-H₂"),
        ("氢路固定费用", int(has_h2), e["h2_fixed_cny"], "套"),
        ("储热容量费用", row.tes_kwh, e["tes_cny_per_kwh"], "kWh_th"),
        ("储热电加热器", row.tes_heater_kw if row.tes_kwh else 0,
         e["tes_heater_cny_per_kw"], "kW"),
        ("储热固定费用", int(row.tes_kwh > 0), e["tes_fixed_cny"], "套"),
    ]
    items = [dict(item=n, quantity=float(q), unit=u,
                  unit_price_cny=float(p), amount_cny=float(q * p))
             for n, q, p, u in lines if q and p]
    if abs(sum(x["amount_cny"] for x in items) - cost["capex"]) > 0.01:
        raise ValueError(f"{row.label}/{year}: 初始投入分项不闭合")

    annual_om = sum(cost[f"capex_{k}"] * e[rate] for k, rate in
                    (("pv", "pv_om"), ("bat", "bat_om"),
                     ("h2", "h2_om"), ("tes", "tes_om")))
    horizon, discount = e["years"], e["discount"]
    events, salvage = [], 0.0

    def replace(component, amount, life):
        nonlocal salvage
        life = min(max(life, 0.5), 1e6)
        for k in range(1, int(horizon / life) + 2):
            t = k * life
            if t < horizon:
                events.append(dict(component=component, year=t, amount_cny=amount))
        last = np.floor((horizon - 1e-9) / life) * life
        if life < 1e5:
            salvage += amount * (1 - (horizon - last) / life)

    replace("电池及其变流器", cost["capex_bat"], cost["bat_life"])
    stack_lives = {}
    if has_h2:
        if rev:
            hours = row.ely_hours + row.fc_hours
            life = e["rsoc_stack_h"] / hours if hours else 1e9
            stack_lives["rSOC"] = float(life)
            if life < horizon:
                replace("rSOC 电堆", row.fc_kw * e["rsoc_cny_per_kw"]
                        * e["rsoc_stack_frac"], life)
        else:
            for mode, power, hours, price, limit, fraction in (
                ("PEM 电解电堆", row.ely_kw, row.ely_hours,
                 e["ely_cny_per_kw"], e["ely_stack_h"], e["ely_stack_frac"]),
                ("PEM 发电电堆", row.fc_kw, row.fc_hours,
                 e["fc_cny_per_kw"], e["fc_stack_h"], e["fc_stack_frac"]),
            ):
                life = limit / hours if hours else 1e9
                stack_lives[mode] = float(life)
                if life < horizon:
                    replace(mode, power * price * fraction, life)

    cashflows = [dict(year=0, kind="初始投入", amount_cny=cost["capex"])]
    cashflows += [dict(year=t, kind="年度运维", amount_cny=annual_om)
                  for t in range(1, horizon + 1)]
    cashflows += [dict(year=x["year"], kind=x["component"] + "更换",
                      amount_cny=x["amount_cny"]) for x in events]
    cashflows.append(dict(year=horizon, kind="期末残值抵扣", amount_cny=-salvage))
    for x in cashflows:
        x["present_value_cny"] = x["amount_cny"] / (1 + discount) ** x["year"]
    recalculated = sum(x["present_value_cny"] for x in cashflows)
    saved_difference = cost["npc"] - float(row[f"npc_{year}"])
    if abs(recalculated - cost["npc"]) > 0.01 or abs(saved_difference) > 0.01:
        raise ValueError(f"{row.label}/{year}: 复算与模型/存量结果不一致")
    return dict(name=row.label, price_scenario=year, currency="CNY",
                years=horizon, discount_rate=discount, cost=cost, items=items,
                annual_om_cny=annual_om, replacements=events,
                end_salvage_cny=salvage, stack_life_years_from_hours=stack_lives,
                undiscounted_net_cost_cny=sum(x["amount_cny"] for x in cashflows),
                cashflows=cashflows, saved_difference_cny=saved_difference,
                cashflow_difference_cny=recalculated - cost["npc"])


def main():
    rows = load()
    results = {key: {year: audit(rows[key], year) for year in ("2026", "2035")}
               for key in ORDER}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "成本复算数据.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    text = ["# 五种方案的人民币成本明细", "",
            "> 由 `python -m analysis.cost_audit` 生成，不手改。全部金额为人民币；"
            "表中万元均指人民币万元。复用现有五种配置，不重新运行物理仿真或选型。",
            "", "## 一、两档价格下的总览", "",
            "2026/2035 是设备价格情景，不是两次支出。两列使用相同配置；"
            "2026 档不是按当前价格重新优化后的最低成本。", "",
            "| 方案 | 2026 档初始投入 | 2026 档25年现值 | 2035 档初始投入 | 2035 档25年现值 |",
            "|---|---:|---:|---:|---:|"]
    for key in ORDER:
        a, b = results[key]["2026"]["cost"], results[key]["2035"]["cost"]
        text.append(f"| {rows[key].label} | {a['capex']/1e4:.2f} | {a['npc']/1e4:.2f}"
                    f" | {b['capex']/1e4:.2f} | {b['npc']/1e4:.2f} |")
    text += ["", "## 二、总价怎样相加", "",
             "25 年现值 = 初始投入 + 运维现值 + 更换费用现值 − 期末残值现值。"
             "当前代码的 `rep_bat` 已合并电池更换与残值，不应再扣一次。"]
    for year in ("2035", "2026"):
        text += ["", f"### {year} 价格情景（万元）", "",
                 "| 方案 | 光伏 | 电池含变流器 | 氢路 | 储热 | 初始合计 | 运维现值 | 更换净现值 | 25年现值 |",
                 "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for key in ORDER:
            c = results[key][year]["cost"]
            values = [c[x] / 1e4 for x in ("capex_pv", "capex_bat", "capex_h2",
                      "capex_tes", "capex", "om")]
            values += [(c["rep_bat"] + c["rep_h2"]) / 1e4, c["npc"] / 1e4]
            text.append("| " + rows[key].label + " | " + " | ".join(f"{v:.2f}" for v in values) + " |")
    text += ["", "## 三、容量乘单价：逐项设备账单", "",
             "以下金额均为未折现的初始投入。氢路固定费用是模型中的打包估计，"
             "不代表已经逐项询价。"]
    for key in ORDER:
        a, b = results[key]["2026"], results[key]["2035"]
        text += ["", f"### {rows[key].label}", "",
                 "| 项目 | 数量 | 单位 | 2026 单价（元/单位） | 2026 小计（万元） | 2035 单价（元/单位） | 2035 小计（万元） |",
                 "|---|---:|---|---:|---:|---:|---:|"]
        for x, y in zip(a["items"], b["items"]):
            if x["item"] != y["item"]:
                raise ValueError("两档价格的分项无法对应")
            text.append(f"| {x['item']} | {x['quantity']:g} | {x['unit']}"
                        f" | {x['unit_price_cny']:,.0f} | {x['amount_cny']/1e4:.3f}"
                        f" | {y['unit_price_cny']:,.0f} | {y['amount_cny']/1e4:.3f} |")
    text += ["", "## 四、折现和更换为什么让总价看起来不高", "",
             "折现率 8%，评价期 25 年：每年固定 1 元支出，25 年累计现值为 "
             f"{(1-1.08**-25)/0.08:.4f} 元，而不是 25 元。现值折算到各情景假定建站年的第 0 年，"
             "不再从 2035 年折回 2026 年。", "",
             "| 方案 | 价格档 | 年运维（元/年） | 电池更换年 | 电堆更换费 | 25年未折现净支出（万元） | 25年折现净支出（万元） |",
             "|---|---|---:|---|---|---:|---:|"]
    for key in ORDER:
        for year in ("2026", "2035"):
            r = results[key][year]
            battery_years = "/".join(f"{x['year']:g}" for x in r["replacements"]
                                     if x["component"] == "电池及其变流器") or "无"
            text.append(f"| {r['name']} | {year} | {r['annual_om_cny']:,.2f}"
                        f" | {battery_years} | {r['cost']['rep_h2']/1e4:.2f} 万元"
                        f" | {r['undiscounted_net_cost_cny']/1e4:.2f} | {r['cost']['npc']/1e4:.2f} |")
    text += ["", "当前五种配置、两档价格下，电堆更换费均为零，原因是代码仅按年运行小时推算寿命，"
             "没有单独设置电堆或辅机的日历寿命。不能将这个建模结果解释成实际设备 25 年免维护、免更换。",
             "", "## 五、金额边界与单位", "",
             "- 当前成本模型明确排除了热泵、建筑和共同配电，不能称为整站交钥匙总造价。",
             "- 水费用设为零，不代表独立供水系统已经建成或免费。",
             "- 氢路已计入固定费用，但安装、运输、调试、安防等是否包含，尚需按设备边界核对；不能一律重复加价或认定全部漏计。",
             "- 金属氢化物按元/kg-H₂ 储氢容量计价；出处的美元/kg 合金不是同一单位。",
             "- 外币按项目设定 1 USD=7.2 CNY、1 EUR=8.0 CNY 转换，不是当前实时汇率。",
             "- 每个分项均已与初始合计核对；十组成本、逐年现金流均与当前经济模型及存量 NPC 闭合至 0.01 元。",
             "", "复算命令：`python -m analysis.cost_audit`（使用已安装 NumPy、pandas 的项目 Python）。"
             "逐年明细见同目录 `成本复算数据.json`。", ""]
    (OUT / "五方案成本明细_自动生成.md").write_text("\n".join(text), encoding="utf-8")
    print("五种配置 × 两档价格：设备分项、现金流、存量 NPC 共十组复算通过。")
    print(OUT / "五方案成本明细_自动生成.md")


if __name__ == "__main__":
    main()
