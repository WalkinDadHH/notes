"""灵敏度分析：设备单价与折现率各 ±30%，推荐结论会不会翻转。

物理结果（是否满足两条准则、年循环、运行小时、续航）与价格无关，所以每条路线只仿真一次、
求出全部可行解；每个价格扰动只重算成本、重取最低：
  ① 定型配置本身的全寿命成本怎么变（龙卷风图）
  ② 三条路线的最低成本排序会不会变：纯光储 / C 经济版（PEM 高压罐）/ 定型路线（C 热集成版）
  ③ 定型路线按同一选型规则重新选，配置会不会变

python -m analysis.sensitivity   → results/sensitivity.csv（约 5 分钟）
"""
import itertools, time
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.economics import npc
from model.params import PV_TECH, prices
from analysis.design import STRESS_STARTS
from analysis.refine import GRID as RGRID, SIZE, endurance_all, select
from analysis.improve import GRIDS
from model.params import MAIN_ROUTE, COMPARE_ROUTE

ROOT = Path(__file__).resolve().parent.parent
SPAN = 0.30
PARAMS = [("bat_cny_per_kwh", "电池单价"), ("pv_cny_per_kwp", "光伏单价"), ("rsoc_cny_per_kw", "rSOC 单价"),
          ("tank_cny_per_kg", "储氢单价（罐 / 合金）"), ("h2_fixed_cny", "氢路固定成本"), ("tes_cny_per_kwh", "储热仓单价"),
          ("ely_cny_per_kw", "PEM 电解槽单价"), ("fc_cny_per_kw", "PEM 燃料电池单价"), ("discount", "折现率")]
ROUTES = [("纯光储", None, "常规单面+人工清洗", False),
          ("C 经济版", COMPARE_ROUTE["tech"], COMPARE_ROUTE["pv_tech"], COMPARE_ROUTE["dc_bus"]),
          ("定型路线", MAIN_ROUTE["tech"], MAIN_ROUTE["pv_tech"], MAIN_ROUTE["dc_bus"])]


def grid(route):
    if route == "纯光储":
        return np.array(GRIDS["pv_only"]([0]), float)
    if route == "C 经济版":
        return np.array(GRIDS["PEM+高压罐"](list(COMPARE_ROUTE["tes_grid"])), float)
    return np.array(list(itertools.product(*[RGRID[k] for k in ("pv", "bat", "ely", "fc", "tank", "tes")])), float)


def run(inp, c, tech, **kw):
    return simulate(inp, c[:, 0], c[:, 1], c[:, 2], c[:, 3], c[:, 4], tes_kwh=c[:, 5], tech=tech, **kw)


def feasible(inp, route, tech):
    """该路线网格内满足两条设计准则的全部配置及其物理结果。"""
    c = grid(route)
    sim = run(inp, c, tech)
    keep = sim["unmet_total"] < 1e-6
    ok = np.ones(keep.sum(), bool)
    for st in STRESS_STARTS:
        ok &= run(with_blackout(inp, st, 72), c[keep], tech)["crit_unmet_total"] < 1e-6
    return pd.DataFrame({k: v[keep][ok] for k, v in sim.items() if isinstance(v, np.ndarray)})


def cost(df, tech, pvt, key=None, f=1.0):
    t = tech or "PEM+高压罐"
    e = {}
    if key:
        base = prices(tech=t, pv_tech=pvt).get(key)
        if base is not None:
            e[key] = base * f
    return npc({k: df[k].values for k in df.columns}, tech=t, pv_tech=pvt, e=e)["npc"]


if __name__ == "__main__":
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    q_heat = (L.q_space + L.q_dhw).sum() / (len(w) / 8766)
    final = pd.read_csv(ROOT / "results" / "final_config.csv").iloc[0]
    sets = {}
    for route, tech, pvt, dc in ROUTES:
        inp = make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH[pvt]), dc_bus=dc)
        df = feasible(inp, route, tech)
        if route == "定型路线":
            cc = df[SIZE].values
            df["endurance_h"] = np.min([endurance_all(inp, cc, st) for st in STRESS_STARTS], axis=0)
            df["heat_share"] = (df.tes_out + df.heat_rec) / q_heat
        sets[route] = df
        print(f"{route}: {len(df)} 组可行解  ({time.time()-t0:.0f}s)", flush=True)

    fr = sets["定型路线"]
    is_final = np.all([np.isclose(fr[k], final[k]) for k in SIZE], axis=0)
    assert is_final.sum() == 1, "定型配置不在可行集中，先重跑 analysis.refine"
    rows = []
    for key, label in [(None, "基准")] + PARAMS:
        for f in ((1.0,) if key is None else (1 - SPAN, 1 + SPAN)):
            row = dict(param=key or "base", label=label, factor=f)
            for route, tech, pvt, dc in ROUTES:
                c = cost(sets[route], tech, pvt, key, f)
                row[f"min_{route}"] = c.min()
                if route == "定型路线":
                    row["final_npc"] = c[is_final][0]
                    pick, _ = select(sets[route].assign(npc=c))
                    row["reselect"] = " / ".join(f"{pick[k]:g}" for k in SIZE)
                    row["reselect_npc"] = pick.npc
            mins = {r: row[f"min_{r}"] for r, *_ in ROUTES}
            row["cheapest"] = min(mins, key=mins.get)
            row["ratio_pure_over_final"] = row["min_纯光储"] / row["reselect_npc"]
            row["premium_over_econ"] = row["reselect_npc"] - row["min_C 经济版"]
            rows.append(row)
            print(f"{label:12s} ×{f:.1f}  定型 {row['final_npc']/1e4:6.1f} 万  "
                  f"纯光储 {row['min_纯光储']/1e4:6.1f}  经济版 {row['min_C 经济版']/1e4:6.1f}  "
                  f"定型路线 {row['min_定型路线']/1e4:6.1f}  最便宜：{row['cheapest']}  重选：{row['reselect']}",
                  flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "sensitivity.csv", index=False)
    print(f"\n完成 {time.time()-t0:.0f}s → results/sensitivity.csv")
