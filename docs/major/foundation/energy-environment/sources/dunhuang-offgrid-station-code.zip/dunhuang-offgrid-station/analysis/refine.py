"""定型配置：在主推路线（params.MAIN_ROUTE）下细网格优化。

选型规则（params.CRITERIA）：
  ① 两条设计准则：11 年零缺电 + 三次 72 小时零光照压力测试关键负荷零中断
  ② 续航余量：在三个最差窗口起点注入长时零光照，关键负荷续航 ≥ 90 h（72 h × 1.25）
  ③ 满足 ①② 的配置中成本最低（按 PRICE_YEAR 价格）；与最低成本相差 1% 以内视为同价，取不靠热泵供热占比最高者；
     热闭环相差 1 个百分点以内视为相同，取光伏装机最少（能效优先）

python -m analysis.refine             → results/refine.csv（全部可行解及续航）, results/final_config.csv（定型配置）
python -m analysis.refine --compare   对照路线（params.COMPARE_ROUTE，C 经济版）→ results/refine_compare.csv, final_compare.csv
"""
import itertools, sys, time
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.economics import npc
from model.params import PV_TECH, CRITERIA, MAIN_ROUTE, COMPARE_ROUTE, PRICES, PRICE_YEAR
from analysis.design import STRESS_STARTS
from analysis.endurance import MAX_H

ROOT = Path(__file__).resolve().parent.parent
COMPARE = __name__ == "__main__" and "--compare" in sys.argv
ROUTE = COMPARE_ROUTE if COMPARE else MAIN_ROUTE
TAG = "_compare" if COMPARE else ""
TECH, PVT, DC = ROUTE["tech"], ROUTE["pv_tech"], ROUTE["dc_bus"]
REV = "rSOC" in TECH
GRID = dict(pv=np.arange(35, 62.6, 2.5), bat=np.arange(75, 226, 25),
            ely=[0] if REV else [5, 7.5, 10, 12.5, 15], fc=[6, 7, 8, 9, 10] if not REV else [6, 8, 10, 12],
            tank=np.arange(15, 46, 5), tes=ROUTE["tes_grid"])
TOP_K = 400
SIZE = ["pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg", "tes_kwh"]


def route_inputs(w, L):
    return make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH[PVT]), dc_bus=DC)


def run(inp, cc, **kw):
    return simulate(inp, cc[:, 0], cc[:, 1], cc[:, 2], cc[:, 3], cc[:, 4], tes_kwh=cc[:, 5], tech=TECH, **kw)


def endurance_all(inp, cc, start):
    """在 start 注入 MAX_H 小时零光照，返回每组配置关键负荷首次中断前坚持的小时数。"""
    h = run(with_blackout(inp, start, MAX_H), cc, track_from=start)["first_crit_h"]
    return np.where((h < 0) | (h > MAX_H), MAX_H, h)


def select(ok, col="npc"):
    """按选型规则挑出定型配置，返回 (定型行, 候选表)。"""
    cand = ok[ok.endurance_h >= CRITERIA["select_endurance_h"]]
    if cand.empty:
        raise SystemExit(f"没有续航 ≥ {CRITERIA['select_endurance_h']} h 的可行解，需扩大网格")
    tie = cand[cand[col] <= cand[col].min() * (1 + CRITERIA["select_cost_tol"])]
    best = tie[tie.heat_share >= tie.heat_share.max() - CRITERIA["select_heat_tol"]]
    return best.sort_values(["pv_kwp", col]).iloc[0], tie


if __name__ == "__main__":
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    yrs = len(w) / 8766
    q_heat = (L.q_space + L.q_dhw).sum() / yrs
    inp = route_inputs(w, L)
    c = np.array(list(itertools.product(*[GRID[k] for k in ("pv", "bat", "ely", "fc", "tank", "tes")])), float)
    print(f"{TECH} · {PVT} · 直流母线 {DC}：{len(c)} 组配置")
    sim = run(inp, c)
    df = pd.DataFrame({k: sim[k] for k in sim if isinstance(sim[k], np.ndarray)})
    for k, v in npc(sim, tech=TECH, pv_tech=PVT).items():
        df[k] = v
    for y in PRICES:
        df[f"npc_{y}"] = npc(sim, tech=TECH, pv_tech=PVT, year=y)["npc"]
        df[f"capex_{y}"] = npc(sim, tech=TECH, pv_tech=PVT, year=y)["capex"]
    ok = df[df.unmet_total < 1e-6].sort_values("npc").head(TOP_K).copy()
    print(f"11 年零缺电：{(df.unmet_total < 1e-6).sum()} 组  ({time.time()-t0:.0f}s)")
    cc = ok[SIZE].values
    passed = np.ones(len(ok), bool)
    for st in STRESS_STARTS:
        passed &= run(with_blackout(inp, st, 72), cc)["crit_unmet_total"] < 1e-6
    ok = ok[passed].copy()
    print(f"两条准则都满足：{len(ok)} 组（在成本最低的 {TOP_K} 组中）  ({time.time()-t0:.0f}s)")

    cc = ok[SIZE].values
    for st in STRESS_STARTS:
        ok[f"h_{st[:7]}"] = endurance_all(inp, cc, st)
    ok["endurance_h"] = ok[[f"h_{st[:7]}" for st in STRESS_STARTS]].min(axis=1)
    ok["heat_share"] = (ok.tes_out + ok.heat_rec) / q_heat
    ok["tech"], ok["pv_tech"], ok["dc_bus"] = TECH, PVT, DC
    ok.to_csv(ROOT / "results" / f"refine{TAG}.csv", index=False)
    print(f"续航计算完成  ({time.time()-t0:.0f}s)\n")

    best, tie = select(ok)
    cols = SIZE + ["npc_2026", "npc_2035", "endurance_h", "heat_share", "water_net_l", "curtail", "bat_cycles"]
    fmt = lambda x: f"{x:,.2f}"
    print("成本最低的 10 组：")
    print(ok[cols].head(10).to_string(index=False, float_format=fmt))
    print(f"\n续航 ≥ {CRITERIA['select_endurance_h']} h 且与最低成本相差 ≤ "
          f"{CRITERIA['select_cost_tol']:.0%} 的同价候选：")
    print(tie[cols].to_string(index=False, float_format=fmt))
    final = best.copy()
    final["case"] = "C 经济版（对照）" if COMPARE else "定型配置"
    final.to_frame().T.to_csv(ROOT / "results" / ("final_compare.csv" if COMPARE else "final_config.csv"), index=False)
    h2 = f"rSOC {best.fc_kw:.0f} kW（电解 {best.ely_kw:.0f} kW）" if REV else \
        f"电解 {best.ely_kw:g} kW · 燃料电池 {best.fc_kw:g} kW"
    print(f"\n定型：光伏 {best.pv_kwp:g} kWp · 电池 {best.bat_kwh:.0f} kWh · {h2} · 储氢 {best.tank_kg:.0f} kg"
          f" · 储热仓 {best.tes_kwh:.0f} kWh\n"
          f"      全寿命成本 {best.npc_2035/1e4:.2f} 万（2035 价）/ {best.npc_2026/1e4:.2f} 万（2026 价）· "
          f"续航 {best.endurance_h:.0f} h · 不靠热泵供热 {best.heat_share:.1%}  ({time.time()-t0:.0f}s)")
