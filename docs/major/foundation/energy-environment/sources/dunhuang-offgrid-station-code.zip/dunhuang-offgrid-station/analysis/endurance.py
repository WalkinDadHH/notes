"""续航测试：每个推荐方案在完全无光照时能保住关键负荷多少小时。

在历史最差窗口起点注入 N 小时零光照，二分查找关键负荷首次中断的 N。
python -m analysis.endurance   → results/endurance.csv（analysis.improve 已顺带算好，本命令用于单独复核）
"""
from pathlib import Path
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.params import PV_TECH

ROOT = Path(__file__).resolve().parent.parent
STARTS = ["2017-12-12 00:00", "2023-01-12 00:00", "2024-02-17 00:00"]


MAX_H = 480


def endurance(inp, r, start, tech):
    """注入 MAX_H 小时零光照，返回关键负荷首次中断前坚持的小时数。"""
    s = simulate(with_blackout(inp, start, MAX_H), r.pv_kwp, r.bat_kwh, r.ely_kw, r.fc_kw,
                 r.tank_kg, tes_kwh=r.tes_kwh, tech=tech, record=True)["series"]
    t0 = s.index.get_indexer([pd.Timestamp(start)], method="nearest")[0]
    seg = s.crit_unmet.values[t0:t0 + MAX_H]
    hit = (seg > 1e-6).nonzero()[0]
    return int(hit[0]) if len(hit) else MAX_H


if __name__ == "__main__":
    summ = pd.read_csv(ROOT / "results" / "design_summary.csv")
    w = load_weather(); L = build_load(w)
    rows = []
    for _, r in summ.iterrows():
        tech = None if r.tech in ("-", "") or pd.isna(r.tech) else r.tech
        dc = bool(r.get("dc_bus", False))
        inp = make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH[r.pv_tech]), dc_bus=dc)
        hrs = [endurance(inp, r, st, tech) for st in STARTS]
        rows.append(dict(case=r.case, npc_wan=round(r.npc / 1e4, 1), endurance_h=min(hrs),
                         **{f"h_{st[:7]}": h for st, h in zip(STARTS, hrs)}))
        print(f"{r.case:44s} NPC {r.npc/1e4:6.1f} 万  关键负荷续航 {min(hrs):3d} h  {hrs}", flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "endurance.csv", index=False)
