"""方案改进阶梯：从成熟方案出发，每次加一项改进、重新优化容量，看能效和成本怎么变。

阶梯（每级都在同一选型规则下重新找最优配置）：
  M1 成熟①  纯光储（单面、倾角 = 纬度、人工清洗）
  M2 成熟②  光储氢：PEM 电解 + 35 MPa 高压罐 + PEM 燃料电池
  S1 + 双面组件 + 静电无水除尘（黎明择时）
  S2 + 冬季倾角（离网按最差季节设计）
  S3 + 直流母线（站内直流配电）
  S4 + 砂石储热仓
  对照 R1：S3 的氢路换成 rSOC 热集成（+ 高压罐 + 储热仓）
  对照 R2：rSOC + 金属氢化物 + 储热仓（低压储氢版，旧定型路线在新参数下的样子）
选型规则（params.CRITERIA）：11 年零缺电 + 三次 72 h 零光照关键负荷零中断 + 续航 ≥ 90 h
  → 按 PRICE_YEAR 价格成本最低 → 1% 内同价取热闭环最好。物理结果与价格无关，两档价格各选一次。

python -m analysis.improve        → results/improve_tilt.csv, results/improve_ladder.csv（两档价格各选一次、含能效指标）
                                    results/design_summary.csv, results/endurance.csv（按 2035 价选的各级 + 开题配置，
                                    供图、报告、网页做方案比较；约 35 分钟）
python -m analysis.improve --no-tilt   跳过倾角扫描，直接用 params 里的冬季倾角
"""
import itertools, time
import numpy as np
import pandas as pd
from pathlib import Path
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.economics import npc
from model.params import PV_TECH, CRITERIA, PRICES, PRICE_YEAR, BASELINE
from analysis.design import STRESS_STARTS
from analysis.endurance import MAX_H

ROOT = Path(__file__).resolve().parent.parent
YEARS = tuple(PRICES)
SIZE = ["pv_kwp", "bat_kwh", "ely_kw", "fc_kw", "tank_kg", "tes_kwh"]
TOP_K = 300
M2_PER_KWP = 1 / 0.225          # 组件面积 m²/kWp（TOPCon 组件效率约 22.5%）
WINTER = (11, 12, 1, 2)

PV_ = np.arange(40, 81, 5)
BAT = np.arange(50, 251, 25)
TANK = np.arange(15, 61, 5)
GRIDS = {
    "pv_only": lambda tes: [(p, b, 0, 0, 0, 0) for p, b in itertools.product(
        np.arange(40, 151, 10), np.arange(150, 1201, 25))],
    "PEM+高压罐": lambda tes: list(itertools.product(PV_, BAT, [5, 10, 15], [6, 8, 10, 12], TANK, tes)),
    "rSOC": lambda tes: [(p, b, 0, f, t, s) for p, b, f, t, s in itertools.product(
        PV_, BAT, [6, 8, 10, 12], TANK, tes)],
}
TES = [0, 100, 200, 300, 400]
WT = "双面+静电除尘·冬季倾角"
# (键, 名称, 氢路, 光伏, 直流母线, 储热仓网格)
LADDER = [
    ("M1", "成熟①：纯光储", None, "常规单面+人工清洗", False, [0]),
    ("M2", "成熟②：PEM + 35 MPa 高压罐", "PEM+高压罐", "常规单面+人工清洗", False, [0]),
    ("S1", "+ 双面组件 + 静电除尘", "PEM+高压罐", "双面+静电除尘", False, [0]),
    ("S2", "+ 冬季倾角", "PEM+高压罐", WT, False, [0]),
    ("S3", "+ 直流母线", "PEM+高压罐", WT, True, [0]),
    ("S4", "+ 砂石储热仓", "PEM+高压罐", WT, True, TES),
    ("R1", "对照：氢路换 rSOC 热集成 + 高压罐 + 储热仓", "rSOC+高压罐", WT, True, TES),
    ("R2", "对照：rSOC + 金属氢化物 + 储热仓（低压储氢）", "rSOC+金属氢化物", WT, True, TES),
]


def run(inp, c, tech, **kw):
    return simulate(inp, c[:, 0], c[:, 1], c[:, 2], c[:, 3], c[:, 4], tes_kwh=c[:, 5], tech=tech, **kw)


def endurance(inp, c, tech, start):
    h = run(with_blackout(inp, start, MAX_H), c, tech, track_from=start)["first_crit_h"]
    return np.where((h < 0) | (h > MAX_H), MAX_H, h)


def evaluate(inp, cfg, tech, pvt, q_heat, years=YEARS):
    """全部配置仿真 → 两条准则 → 续航；返回可行解表（含两档价格成本）。"""
    c = np.array(cfg, float)
    sim = run(inp, c, tech)
    df = pd.DataFrame({k: v for k, v in sim.items() if isinstance(v, np.ndarray)})
    for y in years:
        cost = npc(sim, tech=tech, pv_tech=pvt, year=y)
        df[f"npc_{y}"], df[f"capex_{y}"] = cost["npc"], cost["capex"]
    ok = df[df.unmet_total < 1e-6]
    keep = set()
    for y in years:                                     # 两档价格各自最便宜的前 TOP_K 组都要算续航
        keep |= set(ok.sort_values(f"npc_{y}").head(TOP_K).index)
    ok = ok.loc[sorted(keep)].copy()
    cc = ok[SIZE].values
    passed = np.ones(len(ok), bool)
    for st in STRESS_STARTS:
        passed &= run(with_blackout(inp, st, 72), cc, tech)["crit_unmet_total"] < 1e-6
    ok = ok[passed].copy()
    cc = ok[SIZE].values
    for st in STRESS_STARTS:
        ok[f"h_{st[:7]}"] = endurance(inp, cc, tech, st)
    ok["endurance_h"] = ok[[f"h_{st[:7]}" for st in STRESS_STARTS]].min(axis=1)
    ok["heat_share"] = (ok.tes_out + ok.heat_rec) / q_heat
    ok["tech"], ok["pv_tech"] = tech or "-", pvt
    return ok


def select(ok, year=PRICE_YEAR):
    cand = ok[ok.endurance_h >= CRITERIA["select_endurance_h"]]
    if cand.empty:
        return None
    col = f"npc_{year}"
    tie = cand[cand[col] <= cand[col].min() * (1 + CRITERIA["select_cost_tol"])]
    tie = tie[tie.heat_share >= tie.heat_share.max() - CRITERIA["select_heat_tol"]]
    return tie.sort_values(["pv_kwp", col], ascending=[True, True]).iloc[0]


def full_row(r, tech, pvt, dc, case):
    """方案比较用的一行：仿真量 + 2035 价成本明细 + 2026 价总成本。"""
    one = {k: np.atleast_1d(r[k]).astype(float) for k in r.index
           if isinstance(r[k], (int, float, np.integer, np.floating))}
    out = r.copy()
    for k, v in npc(one, tech=tech, pv_tech=pvt).items():
        out[k] = float(np.atleast_1d(v)[0])
    for y in YEARS:
        out[f"npc_{y}"] = float(npc(one, tech=tech, pv_tech=pvt, year=y)["npc"][0])
    out["case"], out["tech"], out["pv_tech"], out["dc_bus"] = case, tech or "-", pvt, dc
    return out


def kpis(r, inp, L, tech, yrs):
    """能效指标（11 年平均）。终端服务 = 非暖通用电 + 供暖热水 + 制冷，各方案相同。"""
    s = simulate(inp, r.pv_kwp, r.bat_kwh, r.ely_kw, r.fc_kw, r.tank_kg, tes_kwh=r.tes_kwh,
                 tech=tech, record=True)["series"]
    win = s.index.month.isin(WINTER)
    service = (L.e_base + L.q_space + L.q_dhw + L.q_cool).sum() / yrs
    h2_in = r.ely_in + r.steam_e
    return dict(
        pv_area_m2=r.pv_kwp * M2_PER_KWP,
        pv_mwh=r.pv / 1e3,
        pv_winter_mwh=s.pv[win].sum() / yrs / 1e3,
        curtail_share=r.curtail / r.pv,
        elec_mwh=r.demand / 1e3,                                  # 站内总用电（含热泵，已扣余热顶替）
        service_per_pv=service / r.pv,                            # 每 kWh 光伏换来的终端服务
        bat_loss_mwh=(r.bat_in - r.bat_out) / 1e3,
        h2_loss_mwh=(h2_in - r.fc_out) / 1e3,
        h2_rte=r.fc_out / h2_in if h2_in > 0 else np.nan,         # 氢路实际电→电效率（含 SOEC 电加热）
        standby_mwh=r.standby_e / 1e3,                            # rSOC 冬季热备补电
    )


if __name__ == "__main__":
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    yrs = len(w) / 8766
    q_heat = (L.q_space + L.q_dhw).sum() / yrs

    import sys
    # ① 倾角扫描：rSOC + 氢化物路线，光伏步长 2.5 kWp（倾角只改变光伏出力，需要细的光伏步长才分得出）
    tilt_rows = []
    do_tilt = "--no-tilt" not in sys.argv
    scan = [(p, b, 0, f, t, s) for p, b, f, t, s in itertools.product(
        np.arange(40, 70.1, 2.5), [75, 100, 125], [8, 10, 12], [25, 30, 35, 40], [200, 300, 400])]
    for tilt in ((40, 45, 50, 55, 60, 65, 70) if do_tilt else ()):
        p = {**PV_TECH[WT], "tilt": tilt}
        pvw = pv_power(w, 1.0, p=p).pv_kw
        inp = make_inputs(w, L, pvw.to_frame())
        b = select(evaluate(inp, scan, "rSOC+金属氢化物", WT, q_heat))
        tilt_rows.append(dict(tilt=tilt, kwh_per_kwp=pvw.sum() / yrs,
                              winter_kwh_per_kwp=pvw[w.index.month.isin(WINTER)].sum() / yrs,
                              npc=b[f"npc_{PRICE_YEAR}"] if b is not None else np.nan,
                              **({k: b[k] for k in SIZE} if b is not None else {})))
        r = tilt_rows[-1]
        print(f"倾角 {tilt}°：全年 {r['kwh_per_kwp']:.0f} · 冬季 {r['winter_kwh_per_kwp']:.0f} kWh/kWp  "
              f"最优 {r['npc']/1e4:.2f} 万（光伏 {r.get('pv_kwp', np.nan):.1f} kWp）  ({time.time()-t0:.0f}s)", flush=True)
    tilt_df = pd.DataFrame(tilt_rows) if do_tilt else pd.read_csv(ROOT / "results" / "improve_tilt.csv")
    if do_tilt:
        tilt_df.to_csv(ROOT / "results" / "improve_tilt.csv", index=False)
    best_tilt = tilt_df.sort_values(["npc", "winter_kwh_per_kwp"], ascending=[True, False]).iloc[0].tilt
    if best_tilt != PV_TECH[WT]["tilt"]:
        print(f"⚠ params 里冬季倾角取 {PV_TECH[WT]['tilt']:.0f}°，扫描最优 {best_tilt:.0f}°：本次阶梯按扫描值算，"
              f"请同步改 params")
    PV_TECH[WT]["tilt"] = float(best_tilt)
    print()

    # ② 改进阶梯
    inps = {}
    rows, summ = [], []
    # 开题配置在同一准则下的表现（PEM 高压罐、常规光伏、交流配电）
    inp0 = make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH["常规单面+人工清洗"]))
    k0 = BASELINE
    b0 = evaluate(inp0, [(k0["pv_kwp"], k0["bat_kwh"], k0["ely_kw"], k0["fc_kw"], k0["tank_kg"], 0)],
                  "PEM+高压罐", "常规单面+人工清洗", q_heat)
    if len(b0):
        summ.append(full_row(b0.iloc[0], "PEM+高压罐", "常规单面+人工清洗", False, "开题配置"))
    else:
        print("⚠ 开题配置在新参数下不满足两条准则")
    for key, label, tech, pvt, dc, tes in LADDER:
        if (pvt, dc) not in inps:
            inps[pvt, dc] = make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH[pvt]), dc_bus=dc)
        inp = inps[pvt, dc]
        g = "pv_only" if tech is None else ("rSOC" if "rSOC" in tech else tech)
        ok = evaluate(inp, GRIDS[g](tes), tech, pvt, q_heat)
        for y in YEARS:
            b = select(ok, y)
            if b is None:
                print(f"✗ {key} {y} 价：无续航 ≥ 90 h 的可行解"); continue
            row = dict(key=key, label=label, price_year=y, dc_bus=dc, **{k: b[k] for k in SIZE},
                       npc_2026=b.npc_2026, npc_2035=b.npc_2035, capex_2026=b.capex_2026,
                       capex_2035=b.capex_2035, endurance_h=b.endurance_h, heat_share=b.heat_share,
                       water_net_l=b.water_net_l, tech=b.tech, pv_tech=pvt,
                       **kpis(b, inp, L, tech, yrs))
            rows.append(row)
            if y == PRICE_YEAR:
                summ.append(full_row(b, tech, pvt, dc, f"{key} {label}"))
            print(f"✓ {key} 按{y}价选：光伏 {b.pv_kwp:.0f} 电池 {b.bat_kwh:.0f} 电解 {b.ely_kw:.0f} "
                  f"发电 {b.fc_kw:.0f} 氢 {b.tank_kg:.0f} 储热 {b.tes_kwh:.0f}  "
                  f"2026 价 {b.npc_2026/1e4:.1f} 万 · 2035 价 {b.npc_2035/1e4:.1f} 万 · "
                  f"续航 {b.endurance_h:.0f} h · 免热泵 {b.heat_share:.0%} · 弃光 {row['curtail_share']:.0%} · "
                  f"用电 {row['elec_mwh']:.1f} MWh  ({time.time()-t0:.0f}s)", flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "improve_ladder.csv", index=False)
    sm = pd.DataFrame(summ)
    sm.to_csv(ROOT / "results" / "design_summary.csv", index=False)
    hcols = [f"h_{st[:7]}" for st in STRESS_STARTS]
    sm.assign(npc_wan=(sm.npc / 1e4).round(1))[["case", "npc_wan", "endurance_h", *hcols]].to_csv(
        ROOT / "results" / "endurance.csv", index=False)
    print(f"\n完成 {time.time()-t0:.0f}s → results/improve_ladder.csv, design_summary.csv, endurance.csv")
