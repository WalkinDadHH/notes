"""生成固定五种配置的三档补充预算与报告表格：python -m analysis.project_budget。"""
import json
from pathlib import Path

from analysis.cost_audit import audit, ORDER
from analysis.schemes import load
from model.params import PROJECT_BUDGET as B
from model.project_costs import extended_cost

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "结题报告" / "generated"


def table(name, heads, rows, align, note=""):
    lines = ["% 由 python -m analysis.project_budget 自动生成，不手改",
             rf"\begin{{tabularx}}{{\linewidth}}{{{align}}}", r"\toprule",
             " & ".join(heads) + r" \\", r"\midrule"]
    lines += [" & ".join(str(x) for x in row) + r" \\" for row in rows]
    lines += [r"\bottomrule", r"\end{tabularx}"]
    if note:
        lines += [r"\par\vspace{3pt}{\footnotesize " + note + "}"]
    (OUT / name).write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    schemes = load()
    data = {}
    for key in ORDER:
        row = schemes[key]
        data[key] = {}
        for year in ("2026", "2035"):
            old = audit(row, year)
            data[key][year] = {s: extended_cost(row, old, year, s) for s in B["scenarios"]}
    (ROOT / "results" / "project_budget.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    money = lambda x: f"{x / 1e4:.1f}"
    names = {k: schemes[k].label.replace("定型 · ", "") for k in ORDER}
    for year in ("2035", "2026"):
        rows = []
        for key in ORDER:
            r = data[key][year]["中"]
            g, t = r["generation"], r["station"]
            rows.append([names[key], money(g["capex_cny"]), money(g["npc_cny"]),
                         money(t["capex_cny"]), money(t["cumulative_outlay_cny"]), money(t["npc_cny"])])
        table(f"tab_budget_{year}.tex",
              ["方案", r"\shortstack{发电储能\\初始预算}", r"\shortstack{发电储能\\25年现值}",
               r"\shortstack{整站\\初始预算}", r"\shortstack{整站25年\\累计支出}",
               r"\shortstack{整站\\25年现值}"], rows, "Xrrrrr",
              "单位：人民币万元，补充概算中档。累计支出不折现、不扣期末残值，包含建设预备费；"
              "现值按8\\%折现并扣除更新资产残值。两档价格使用同一配置，不重新选型。")

    # 先把原有五方案的73.8等金额解释闭合，再展开新边界。
    rows = []
    for key in ORDER:
        c = audit(schemes[key], "2035")["cost"]
        rows.append([names[key]] + [f"{c[x] / 1e4:.2f}" for x in
                     ("capex_pv", "capex_bat", "capex_h2", "capex_tes", "om")]
                    + [f"{(c['rep_bat'] + c['rep_h2']) / 1e4:.2f}", f"{c['npc'] / 1e4:.2f}"])
    table("tab_core_cost_breakdown.tex",
          ["方案", "光伏", "电池", "氢路", "储热", "运维", r"\shortstack{更换\\净现值}", "合计"],
          rows, "Xrrrrrrr", "单位：人民币万元，2035价格档。前四项为初始投资；后三项采用25年现值。"
          "这是原选型与图中的核心设备边界，不含本节新增工程费用；显示数值可能有舍入尾差。")

    assumptions = [
        ("建筑及室内基本安装", "building_cny_per_m2", "元/m²"),
        ("冷暖热泵主机及水力配套", "hp_cny", "元/套"),
        ("冷热末端及专用管路", "hvac_terminals_cny", "元/套"),
        ("生活热水箱及换热", "dhw_tank_cny", "元/套"),
        ("站外配电至建筑接口", "external_distribution_cny", "元/套"),
        ("直流适配与保护增量", "dc_extra_cny", "元/套"),
        ("EMS与计量", "ems_cny", "元/套"),
        ("能源设备运输与进场", "energy_transport_cny", "元/站"),
        ("站内场坪及小型道路", "siteworks_cny", "元/站"),
        ("生活水及污水配套", "domestic_water_cny", "元/站"),
    ]
    rows = [[label, unit] + [f"{v:,.0f}" for v in B[key]] for label, key, unit in assumptions]
    for label, key in [("跨设备集成费率", "integration_frac"), ("设计管理费率", "design_frac"),
                       ("基本预备费率", "contingency_frac"), ("建筑年维护率", "building_om"),
                       ("新增专用机电年维护率", "mep_om")]:
        rows.append([label, r"\%"] + [f"{v * 100:g}" for v in B[key]])
    for label, key in [("冷热设备更新周期", "hvac_life_y"), ("配电更新周期", "electrical_life_y"),
                       ("EMS更新周期", "ems_life_y"), ("生活水设备更新周期", "water_life_y"),
                       ("氢电堆日历更新周期", "power_unit_calendar_y"),
                       ("氢路配套更新周期", "h2_aux_calendar_y")]:
        rows.append([label, "年"] + [f"{v:g}" for v in B[key]])
    rows.append(["氢路配套一次更新比例", r"\%"] + [f"{v * 100:g}" for v in B["h2_aux_replace_frac"]])
    table("tab_budget_assumptions.tex", ["补充参数", "单位", "低档", "中档", "高档"], rows,
          "Xlrrr", "新增取值均为概算设定，公开工程指标与采购限价只校核量级，并非本站报价。"
          "同一档新增工程费用不随2026/2035设备价格档自动下降。建筑200~m²；热泵按20~kW等级预留。")

    categories = [
        ("光伏、电池及氢核心设备", lambda r: r["direct"]["energy_devices"]),
        ("储热设备及配套", lambda r: r["direct"]["storage_heat"]),
        ("跨设备适配与联合调试", lambda r: r["direct"]["power_integration"] + r["direct"]["heat_integration"]),
        ("站外配电、直流适配及EMS", lambda r: sum(r["direct"][x] for x in ("external_distribution", "dc_extra", "ems"))),
        ("能源运输进场", lambda r: r["direct"]["energy_transport"]),
        ("建筑及基本安装", lambda r: r["direct"]["building"]),
        ("冷热主机、末端与热水箱", lambda r: sum(r["direct"][x] for x in ("hp", "terminals", "dhw_tank"))),
        ("场坪及生活水配套", lambda r: r["direct"]["siteworks"] + r["direct"]["domestic_water"]),
        ("设计审查及项目管理", lambda r: next(x["amount_cny"] for x in r["station"]["cashflows"] if x["kind"] == "设计与项目管理暂列费")),
        ("基本预备费", lambda r: next(x["amount_cny"] for x in r["station"]["cashflows"] if x["kind"] == "基本预备费")),
        ("整站初始预算合计", lambda r: r["station"]["capex_cny"]),
        ("25年运维现值", lambda r: r["station"]["om_pv_cny"]),
        ("25年设备更新现值", lambda r: r["station"]["replacement_pv_cny"]),
        ("减：期末残值现值", lambda r: r["station"]["salvage_pv_cny"]),
        ("整站25年净现值", lambda r: r["station"]["npc_cny"]),
    ]
    rows = [[label] + [f"{fn(data[k]['2035']['中']) / 1e4:.2f}" for k in ORDER] for label, fn in categories]
    table("tab_budget_breakdown.tex", ["费用项"] + [names[k] for k in ORDER], rows, "Xrrrrr",
          "单位：人民币万元，2035价格、中档补充概算。设计管理费=直接费×5\\%；"
          "预备费=(直接费+设计管理费)×10\\%。预备费仅在建设年列入预算，不重复计提运维。")

    rows = []
    for year in ("2026", "2035"):
        for scenario in B["scenarios"]:
            r = data["final"][year][scenario]
            rows.append([year, scenario, money(r["generation"]["npc_cny"]),
                         money(r["station"]["capex_cny"]), money(r["station"]["cumulative_outlay_cny"]),
                         money(r["station"]["npc_cny"])])
    table("tab_budget_range.tex", ["设备价格档", "概算档", "发电储能现值", "整站初始预算", "整站累计支出", "整站现值"],
          rows, "llXrrr", "单位：人民币万元。低中高档为费用和更新寿命同时变化的预算情景，"
          "不表示置信区间，也不是重新优化后的最优解。")

    # 可手算的分项账单：每种配置分别给出两档初始设备价。
    blocks = []
    for key in ORDER:
        a, b = audit(schemes[key], "2026"), audit(schemes[key], "2035")
        blocks += [rf"\subsection{{{names[key]}：核心设备初始账单}}", r"\small",
                   r"\noindent\begin{tabularx}{\linewidth}{Xrrrr}", r"\toprule",
                   r"项目与数量 & 2026单价 & 2026小计 & 2035单价 & 2035小计 \\", r"\midrule"]
        for x, y in zip(a["items"], b["items"]):
            unit = x["unit"].replace("kg-H₂", r"kg-H$_2$").replace("kWh_th", r"kWh$_{th}$")
            label = x["item"].replace("（容量×0.1）", "")
            blocks.append(f"{label}（{x['quantity']:g}~{unit}） & {x['unit_price_cny']:,.0f} & "
                          f"{x['amount_cny']/1e4:.3f} & {y['unit_price_cny']:,.0f} & {y['amount_cny']/1e4:.3f}" + r" \\")
        blocks += [r"\midrule", f"初始投入合计 & — & {a['cost']['capex']/1e4:.3f} & — & {b['cost']['capex']/1e4:.3f}" + r" \\",
                   r"\bottomrule", r"\end{tabularx}", r"\normalsize", r"\par\smallskip"]
    (OUT / "budget_equipment_bills.tex").write_text("\n".join(blocks), encoding="utf-8")

    macros = ["% 由 python -m analysis.project_budget 自动生成，不手改"]
    for tag, key in (("Final", "final"), ("Econ", "econ"), ("Pure", "pure")):
        for label, year in (("", "2035"), ("Now", "2026")):
            r = data[key][year]["中"]
            for metric, value in (("GenCapex", r["generation"]["capex_cny"]),
                                  ("GenNPC", r["generation"]["npc_cny"]),
                                  ("TotalCapex", r["station"]["capex_cny"]),
                                  ("TotalGross", r["station"]["cumulative_outlay_cny"]),
                                  ("TotalNPC", r["station"]["npc_cny"])):
                macros.append(rf"\newcommand{{\Budget{tag}{metric}{label}}}{{{money(value)}}}")
    ratio = 1 - data["final"]["2035"]["中"]["station"]["npc_cny"] / data["pure"]["2035"]["中"]["station"]["npc_cny"]
    macros.append(rf"\newcommand{{\BudgetTotalSaving}}{{{ratio * 100:.0f}}}")
    (OUT / "budget_numbers.tex").write_text("\n".join(macros) + "\n", encoding="utf-8")

    lines = ["# 两套成本口径与补充概算", "", "全部金额为人民币万元；中档新增概算。", "",
             "|方案|价格档|发电储能初始|发电储能25年现值|整站初始|整站25年累计支出|整站25年现值|",
             "|---|---|---:|---:|---:|---:|---:|"]
    for year in ("2035", "2026"):
        for key in ORDER:
            r = data[key][year]["中"]
            vals = [r["generation"]["capex_cny"], r["generation"]["npc_cny"],
                    r["station"]["capex_cny"], r["station"]["cumulative_outlay_cny"], r["station"]["npc_cny"]]
            lines.append(f"|{names[key]}|{year}|" + "|".join(money(x) for x in vals) + "|")
    lines += ["", "新增参数为低中高概算，不是采购报价；完整范围、来源与假设见报告及补充概算参数说明。",
              "累计支出不折现、不扣残值，含预备费；25年现值按8%折现并抵扣更新资产残值。",
              "发电储能是总账的供电侧子账，热集成版不能脱离热系统单独按该金额建设。",
              "本次保留原配置与73.8等旧核心设备结果，新增预算没有重新进行容量选型。"]
    (ROOT / "docs" / "成本核算" / "两套成本口径_自动生成.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    for key in ORDER:
        r = data[key]["2035"]["中"]
        print(names[key], "发电储能NPC", money(r["generation"]["npc_cny"]),
              "整站初始", money(r["station"]["capex_cny"]),
              "整站累计", money(r["station"]["cumulative_outlay_cny"]),
              "整站NPC", money(r["station"]["npc_cny"]))
    return data


if __name__ == "__main__":
    main()
