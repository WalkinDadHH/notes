"""rSOC 冬季热备策略对比：整个冬季保温（原方案） vs 按需热备（电池电量低于阈值才保温）。

每种策略在主推路线（params.MAIN_ROUTE）下按 analysis.refine 同样的规则重新定型，比较配置、成本、年用氢与热备耗电。
另比较把 rSOC 保温箱装进站房、让热备散热抵扣供暖的设计。

python -m analysis.standby   → results/standby_compare.csv
"""
import itertools, time
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.economics import npc
from model.system import with_blackout
from model.params import CRITERIA, PRICES, H2_TECH
from analysis.design import STRESS_STARTS
import analysis.refine as R

WF = 2.0                                  # 冷态升温耗热 = 2 × 热备功率 | 设计设定 | 🔒
CASES = [
    ("全冬保温 · 保温箱在室外（10-31 方案）", dict(standby_room_frac=0.0)),
    ("全冬保温 · 保温箱在站房内（散热 80% 入室，定型）", dict(standby_room_frac=0.8)),
    ("全冬保温 · 保温箱在站房内（散热 50% 入室）", dict(standby_room_frac=0.5)),
    ("按需热备 · 电量<50% · 升温 8 h · 室外", dict(standby_soc=0.5, warm_h=8, warm_factor=WF, standby_room_frac=0.0)),
    ("按需热备 · 电量<70% · 升温 8 h · 室外", dict(standby_soc=0.7, warm_h=8, warm_factor=WF, standby_room_frac=0.0)),
    ("按需热备 · 电量<70% · 升温 8 h · 站房内 80%", dict(standby_soc=0.7, warm_h=8, warm_factor=WF, standby_room_frac=0.8)),
]


def search(inp, q_heat, yrs, sb):
    c = np.array(list(itertools.product(*[R.GRID[k] for k in ("pv", "bat", "ely", "fc", "tank", "tes")])), float)
    sim = R.run(inp, c, standby=sb)
    df = pd.DataFrame({k: sim[k] for k in sim if isinstance(sim[k], np.ndarray)})
    for k, v in npc(sim, tech=R.TECH, pv_tech=R.PVT).items():
        df[k] = v
    for y in PRICES:
        df[f"npc_{y}"] = npc(sim, tech=R.TECH, pv_tech=R.PVT, year=y)["npc"]
    ok = df[df.unmet_total < 1e-6].sort_values("npc").head(R.TOP_K).copy()
    cc = ok[R.SIZE].values
    passed = np.ones(len(ok), bool)
    for st in STRESS_STARTS:
        passed &= R.run(with_blackout(inp, st, 72), cc, standby=sb)["crit_unmet_total"] < 1e-6
    ok = ok[passed].copy(); cc = ok[R.SIZE].values
    for st in STRESS_STARTS:
        h = R.run(with_blackout(inp, st, R.MAX_H), cc, track_from=st, standby=sb)["first_crit_h"]
        ok[f"h_{st[:7]}"] = np.where((h < 0) | (h > R.MAX_H), R.MAX_H, h)
    ok["endurance_h"] = ok[[f"h_{st[:7]}" for st in STRESS_STARTS]].min(axis=1)
    ok["heat_share"] = (ok.tes_out + ok.heat_rec) / q_heat
    best, _ = R.select(ok)
    return best


if __name__ == "__main__":
    t0 = time.time()
    w = load_weather(); L = build_load(w)
    yrs = len(w) / 8766
    q_heat = (L.q_space + L.q_dhw).sum() / yrs
    inp = R.route_inputs(w, L)
    rows = []
    for name, sb in CASES:
        b = search(inp, q_heat, yrs, sb)
        sb_ = sb or {}
        rows.append(dict(case=name, standby_soc=sb_.get("standby_soc"), warm_h=sb_.get("warm_h"),
                         room_frac=sb_.get("standby_room_frac", 0.0),
                         pv_kwp=b.pv_kwp, bat_kwh=b.bat_kwh, fc_kw=b.fc_kw, tank_kg=b.tank_kg, tes_kwh=b.tes_kwh,
                         npc_2035=b.npc_2035, npc_2026=b.npc_2026, endurance_h=b.endurance_h,
                         heat_share=b.heat_share, h2_used_kg=b.h2_used, standby_kwh=b.standby_e,
                         fc_hours=b.fc_hours, curtail=b.curtail, demand=b.demand))
        r = rows[-1]
        print(f"{name}：光伏 {r['pv_kwp']:g} · 电池 {r['bat_kwh']:.0f} · 储氢 {r['tank_kg']:.0f} kg · 储热 {r['tes_kwh']:.0f}"
              f" → {r['npc_2035']/1e4:.1f} 万 · 续航 {r['endurance_h']:.0f} h · 年用氢 {r['h2_used_kg']:.1f} kg"
              f" · 热备耗电 {r['standby_kwh']:.0f} kWh  ({time.time()-t0:.0f}s)", flush=True)
    pd.DataFrame(rows).to_csv(R.ROOT / "results" / "standby_compare.csv", index=False)
