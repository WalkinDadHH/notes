"""极端情景库：在 72 小时零光照准则之外，看更苛刻的天气下各方案能撑多久。

情景（params.EXTREME），都放在三个最不利窗口起点，取最短：
  零光照       光伏归零（设计准则的情景）
  沙尘暴       光伏只剩 dust_pv_factor
  寒潮叠加阴雪 气温压到 cold_t_air 以下（供暖负荷与热泵 COP 随之变化），光伏只剩 cold_pv_factor
「能撑多久」= 情景一直持续，关键负荷首次中断前的小时数（上限 MAX_H）。
续航曲线：残余光照比例 0–50% 时的续航。

升级测算：定型配置要撑满沙尘暴 / 寒潮情景，最少加多少储氢与发电功率，全寿命成本多多少。

python -m analysis.extremes            → results/extremes.csv, results/endurance_curve.csv, results/extremes_upgrade.csv
python -m analysis.extremes --upgrade  只做升级测算（约 1 分钟）
"""
import argparse
import itertools
from dataclasses import replace
from pathlib import Path
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate
from model.params import PV_TECH, EXTREME
from model.economics import npc
from analysis.design import STRESS_STARTS
from analysis.endurance import MAX_H
import analysis.schemes as SC

ROOT = Path(__file__).resolve().parent.parent


def schemes():
    s = SC.load()
    return [("纯光储", s["pure"]), ("成熟光储氢", s["mature"]), ("C 经济版", s["econ"]), ("定型", s["final"])]


def inputs(w, pvt, start=None, hours=0, pv_factor=1.0, t_cap=None, dc=False):
    """按情景改写 start 起 hours 小时的气温与光伏，返回仿真输入。"""
    w2 = w
    if t_cap is not None:
        w2 = w.copy()
        i0 = w.index.get_indexer([pd.Timestamp(start)], method="nearest")[0]
        col = w2.columns.get_loc("t_air")
        w2.iloc[i0:i0 + hours, col] = np.minimum(w2.iloc[i0:i0 + hours, col], t_cap)
    inp = make_inputs(w2, build_load(w2), pv_power(w2, 1.0, p=PV_TECH[pvt]), dc_bus=dc)
    if start is not None:
        pv = inp.pv_per_kwp.copy()
        i0 = inp.index.get_indexer([pd.Timestamp(start)], method="nearest")[0]
        pv[i0:i0 + hours] *= pv_factor
        inp = replace(inp, pv_per_kwp=pv)
    return inp


def hold(inp, r, start):
    tech = None if pd.isna(r.tech) or r.tech in ("-", "") else r.tech
    h = simulate(inp, r.pv_kwp, r.bat_kwh, r.ely_kw, r.fc_kw, r.tank_kg, tes_kwh=r.tes_kwh, tech=tech,
                 track_from=start)["first_crit_h"][0]
    return MAX_H if h < 0 or h > MAX_H else int(h)


E = EXTREME
CASES = [("零光照", dict(pv_factor=0.0), 72),
         ("沙尘暴", dict(pv_factor=E["dust_pv_factor"]), E["dust_hours"]),
         ("寒潮叠加阴雪", dict(pv_factor=E["cold_pv_factor"], t_cap=E["cold_t_air"]), E["cold_hours"])]
UP_GRID = dict(tank=np.arange(20, 81, 5), fc=[8, 10, 12, 14, 16], bat=[75, 100, 125])


def upgrade(w):
    """在定型配置上加大储氢 / 发电功率 / 电池，找撑满每个加测情景的最低成本配置。"""
    f = pd.read_csv(ROOT / "results" / "final_config.csv").iloc[0]
    dc = SC.dc_of(f)
    c = np.array([(f.pv_kwp, b, fc, t, f.tes_kwh) for t, fc, b in itertools.product(
        UP_GRID["tank"], UP_GRID["fc"], UP_GRID["bat"])], float)
    run = lambda inp, **kw: simulate(inp, c[:, 0], c[:, 1], f.ely_kw, c[:, 2], c[:, 3], tes_kwh=c[:, 4], tech=f.tech, **kw)
    sim = run(inputs(w, f.pv_tech, dc=dc))
    cost = npc(sim, tech=f.tech, pv_tech=f.pv_tech)["npc"]
    rows = []
    for name, kw, need in CASES[1:]:
        hold_h = np.full(len(c), MAX_H)
        for st in STRESS_STARTS:
            h = run(inputs(w, f.pv_tech, st, MAX_H, dc=dc, **kw), track_from=st)["first_crit_h"]
            hold_h = np.minimum(hold_h, np.where((h < 0) | (h > MAX_H), MAX_H, h))
        ok = (hold_h >= need) & (sim["unmet_total"] < 1e-6)
        if ok.any():
            i = np.flatnonzero(ok)[np.argmin(cost[ok])]
            rows.append(dict(scenario=name, found=True, bat_kwh=c[i, 1], fc_kw=c[i, 2], tank_kg=c[i, 3],
                             endurance_h=int(hold_h[i]), npc=cost[i], extra_npc=cost[i] - f.npc))
            print(f"{name}：电池 {c[i,1]:.0f} kWh · 发电 {c[i,2]:.0f} kW · 储氢 {c[i,3]:.0f} kg → 撑 {hold_h[i]} h，"
                  f"成本 +{(cost[i]-f.npc)/1e4:.1f} 万", flush=True)
        else:
            rows.append(dict(scenario=name, found=False))
            print(f"{name}：网格内没有能撑满 {need} h 的配置", flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "extremes_upgrade.csv", index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--upgrade", action="store_true", help="只做升级测算")
    w = load_weather()
    if ap.parse_args().upgrade:
        upgrade(w); raise SystemExit
    sch = schemes()

    rows = []
    for name, kw, need in CASES:
        for sname, r in sch:
            hrs = [hold(inputs(w, r.pv_tech, st, MAX_H, dc=SC.dc_of(r), **kw), r, st) for st in STRESS_STARTS]
            rows.append(dict(scenario=name, scheme=sname, required_h=need, endurance_h=min(hrs),
                             passed=min(hrs) >= need, **{f"h_{st[:7]}": h for st, h in zip(STRESS_STARTS, hrs)}))
            print(f"{name:8s} {sname:14s} 需 {need:3d} h  能撑 {min(hrs):3d} h  {hrs}", flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "extremes.csv", index=False)

    rows = []
    for f in E["curve_pv_factors"]:
        for sname, r in sch:
            hrs = [hold(inputs(w, r.pv_tech, st, MAX_H, pv_factor=f, dc=SC.dc_of(r)), r, st) for st in STRESS_STARTS]
            rows.append(dict(pv_factor=f, scheme=sname, endurance_h=min(hrs)))
            print(f"残余光照 {f:4.0%}  {sname:14s} 能撑 {min(hrs):3d} h", flush=True)
    pd.DataFrame(rows).to_csv(ROOT / "results" / "endurance_curve.csv", index=False)
    upgrade(w)
    print("→ results/extremes.csv, results/endurance_curve.csv, results/extremes_upgrade.csv")
