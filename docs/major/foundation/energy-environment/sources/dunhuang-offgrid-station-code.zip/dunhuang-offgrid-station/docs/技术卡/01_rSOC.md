# 01 可逆固体氧化物电池（rSOC）

同一电堆兼做电解制氢和氢发电，是本站氢热耦合的核心转换设备。

## 原理

固体氧化物电池在 700 °C 以上工作。电解模式（SOEC）将水蒸气在氢电极上还原为氢气，氧离子通过致密电解质传导到氧电极析出氧气；发电模式（SOFC）反向运行，氢气在氢电极上氧化并释放电子。两种模式共用同一电堆，切换时改变气体和电流方向。高温运行使电化学反应动力学改善，电解可利用外部蒸汽热替代部分电功，从而降低单位制氢电耗。

> 示意图 1-1：rSOC 电堆剖面与双模式切换。画一个简化的单电池截面（氢电极 / 电解质 / 氧电极三层），左半标注"电解模式"（H2O 箭头进、H2 箭头出、外部供电），右半标注"发电模式"（H2 箭头进、H2O 箭头出、对外供电）；顶部标注“700 °C 以上”；底部标注"同一电堆，切换运行"。

![rSOC 两种模式共用同一电堆（示意）](图/T1_rSOC.png)

*图 1：rSOC 两种模式共用同一电堆（示意）。*

## 技术成熟度 TRL

**TRL 5--6**（2025 年水平，组内按文献与示范状态估计）。

rSOC 概念已在实验室和中试规模得到验证。GrInHy 项目（2016--2019）在德国 Salzgitter 钢厂部署了 150 kW 级 rSOC 原型，在电解、发电和热备三种模式下累计运行约 10,000 h，电解效率最高达到 84% LHV。后续 GrInHy2.0 项目（2019--2022）将电解规模提升至 720 kW（200 Nm3/h），电效率达 84.6% LHV，产氢近 100 t 用于钢厂退火（GrInHy2.0 仅确认了电解模式运行）。但 rSOC 在可逆模式下的长期耐久性和商业化尚未完成，距大规模部署仍有距离。

## 2030 年预期

DOE Record 20001 给出的 2030 年目标：系统往返效率 60%、系统价格 1,800 $/kW（2020 年现状 3,100 $/kW）、电堆寿命 40,000 h（2020 年现状 10,000 h）；终极目标 1,300 $/kW。Clean Hydrogen Partnership SRIA 给出 SOEC 2030 目标：单位制氢能耗 37 kWh_e + 8 kWh_th/kg（现状 40 + 10）。

## 代表性示范项目

| 项目 | 地点 | 规模 | 年份 | 关键数字 |
|------|------|------|------|----------|
| GrInHy | 德国 Salzgitter 钢厂 | 电解 150 kW、发电 30 kW | 2016--2019 | 三模式运行约 10,000 h，电解效率最高 84% LHV |
| GrInHy2.0 | 德国 Salzgitter | 电解 720 kW（200 Nm3/h） | 2019--2022 | 电效率 84.6% LHV，产氢近 100 t（仅电解模式） |

## 在本站方案 C 里的作用

rSOC 是氢路的核心转换设备：白天光伏盈余时以 SOEC 模式电解制氢，夜间或连阴天以 SOFC 模式用氢发电。电解功率为发电功率的 2 倍（设计设定）。冬季（11--2 月）rSOC 保持热备，热备功率取额定功率的 9%（Hollmann 等对 112 kW 船用 SOFC 模块的研究给出五种热备方案，功率范围为额定的 4.6--13.7%，取中），热量优先取自储热仓。rSOC 保温箱装在站房设备间内，热备散热约 80% 进入室内、抵扣建筑供暖（设计设定）；与保温箱放在室外相比，同样的可靠性约束下少装 10 kWp 光伏，全寿命成本由 85.8 万元降至 81.8 万元。

**关键参数表**

| 参数 | 取值 | 来源 | 状态 |
|------|------|------|------|
| 发电功率 | 8 kW | 逐时模型定型 | 🔒 |
| 电解功率 | 16 kW | = 2 x 发电功率（设计设定） | 🔒 |
| SOEC 制氢电耗 | 39 kWh_e/kg | Clean Hydrogen JU 课题指标 | ✅ |
| SOEC 蒸汽热需求 | 9 kWh_th/kg | 同上 | ✅ |
| SOFC 发电效率 | 58% LHV | Bloom 2024 纯氢 SOFC 约 60%，设定值 | ✅ |
| 可回收余热 | 约 30% LHV | Bloom 2024 高温 CHP 总效率 90% - 电效率 60% | ✅ |
| 冬季热备功率 | 额定的 9% | Hollmann 等 2026: 112 kW SOFC 模块五种热备方案 4.6--13.7%，取中 | ✅ |
| 热备月份 | 11--2 月 | 设计设定 | 🔒 |
| 保温箱位置与散热入室比例 | 站房设备间内，约 80% | 设计设定 | 🔒 |
| 氢路电—电往返效率 | 50% | 按部件参数计算 | — |
| 计入蒸汽热的往返效率 | 40% | 同上 | — |
| 2026 档系统单价 | 22,000 元/kW | DOE 2020 现状 3,100 $/kW | ✅ |
| 2035 档系统单价 | 9,400 元/kW | DOE 终极目标 1,300 $/kW | ✅ |
| 2026 档电堆寿命 | 20,000 h | DOE 现状 10,000 h 与 2030 目标 40,000 h 取中 | ✅ |
| 2035 档电堆寿命 | 40,000 h | DOE 2030 目标 | ✅ |

**耦合关系**：电解蒸汽热优先从砂石储热仓取；发电余热供金属氢化物放氢和回存储热仓；冬季热备热量取自储热仓，保温箱散热再进入站房抵扣供暖。rSOC 是"热枢纽"的关键节点——它既消耗储热仓的热（电解蒸汽、热备），也向储热仓供热（发电余热）。

**主要风险与兜底**：电堆寿命不达预期是首要风险——若实际寿命低于 20,000 h，更换成本上升；DOE 2030 目标 40,000 h 尚未商业验证。兜底方案：退回 PEM 电解 + PEM 燃料电池的成熟路线（TRL 8--9），代价是往返效率从 50% 降至 31%（即 C 经济版）。

## 参考文献

- Hauch A, Kungas R, Blennow P, et al. Recent advances in solid oxide cell technology for electrolysis. Science, 2020, 370(6513): eaba6118. DOI 10.1126/science.aba6118
- CORDIS 项目 700300 GrInHy. Green Industrial Hydrogen via reversible high-temperature electrolysis. 2016--2019. https://cordis.europa.eu/project/id/700300
- Sunfire. GrInHy2.0: 720 kW SOEC, 84.6% LHV. CORDIS 826350. https://sunfire.de/en/news/worlds-largest-high-temperature-electrolyzer-achieves-record-efficiency/
- Peterson D. Reversible Fuel Cell Targets. DOE Record 20001, 2020.
- Mogensen M, et al. Reversible solid-oxide cells for clean and sustainable energy. Clean Energy, 2019, 3(3): 175--201.
- Clean Hydrogen Partnership. SRIA 2021--2027; SOEL KPI.
- Bloom Energy. Hydrogen SOFC 60% electrical efficiency announcement, 2024.
- Hollmann J, Salas Ventura S, Pennanen J, et al. Improving low-load efficiency of marine SOFC powertrains by means of efficient module hot standby operation. Journal of The Electrochemical Society, 2026, 173(12): 124503. DOI 10.1149/1945-7111/ae7479
