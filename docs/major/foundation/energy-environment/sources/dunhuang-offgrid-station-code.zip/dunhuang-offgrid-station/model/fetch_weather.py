"""拉取 NASA POWER 敦煌代表点逐时气象数据并缓存到 data/raw/。

只需运行一次；之后所有计算读本地缓存，离线可用。
    python -m model.fetch_weather            # 默认 2014-2024
    python -m model.fetch_weather 2020 2024  # 指定起止年
"""
import sys, time, io
from pathlib import Path
import requests
import pandas as pd

LAT, LON = 40.14, 94.66          # 敦煌代表点（与开题一致）
PARAMS = [
    "ALLSKY_SFC_SW_DWN",   # GHI 水平面总辐照 Wh/m²
    "ALLSKY_SFC_SW_DNI",   # DNI 法向直射
    "ALLSKY_SFC_SW_DIFF",  # DHI 水平面散射
    "T2M",                 # 2 m 气温 ℃
    "WS10M",               # 10 m 风速 m/s
    "RH2M",                # 2 m 相对湿度 %
]
RAW = Path(__file__).resolve().parent.parent / "data" / "raw"
URL = "https://power.larc.nasa.gov/api/temporal/hourly/point"


def fetch_year(year: int) -> pd.DataFrame:
    out = RAW / f"power_{year}.csv"
    if out.exists():
        return pd.read_csv(out)
    q = dict(parameters=",".join(PARAMS), community="RE", longitude=LON,
             latitude=LAT, start=f"{year}0101", end=f"{year}1231",
             format="CSV", **{"time-standard": "LST"})
    for attempt in range(4):
        try:
            r = requests.get(URL, params=q, timeout=120)
            r.raise_for_status()
            break
        except Exception as e:
            print(f"  {year} 第 {attempt+1} 次失败: {e}")
            time.sleep(5 * (attempt + 1))
    else:
        raise RuntimeError(f"{year} 拉取失败")
    text = r.text
    body = text.split("-END HEADER-", 1)[1].lstrip()
    df = pd.read_csv(io.StringIO(body))
    df.to_csv(out, index=False)
    return df


if __name__ == "__main__":
    y0, y1 = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) == 3 else (2014, 2024)
    RAW.mkdir(parents=True, exist_ok=True)
    for y in range(y0, y1 + 1):
        df = fetch_year(y)
        bad = (df[PARAMS] == -999).sum().sum()
        print(f"{y}: {len(df):5d} 行  GHI年和={df.ALLSKY_SFC_SW_DWN.clip(lower=0).sum()/1000:7.1f} kWh/m²  缺测={bad}")
