"""光储氢逐时能量调度仿真。

对多组配置同时仿真：时间维循环，配置维 numpy 向量化。
11 年 96,432 小时 × 上万组配置，约半分钟。

────────── 每小时调度顺序 ──────────
0. 损耗：电池自放电、储热仓散热；rSOC 冬季热备（热量先从储热仓取，不够再用电）
1. 若光伏不够：储热仓先放热供暖，减少热泵耗电
2. 净功率 = 光伏 − 电需求
盈余：① 充电池 ② 电解制氢（PEM 废热进储热仓；SOEC 反过来要蒸汽热：先取储热仓，不够用盈余电加热，
         再不够就按比例少制氢）③ 弃光电加热储热仓 ④ 剩余弃光
亏缺：① 电池放电 ② 燃料电池/rSOC 发电，余热先供氢化物放氢，再供暖，富余进储热仓
      联立：P = d − min(Q_heat, k'·P)/COP，k' = (热效率 − 放氢吸热)/电效率
      ③ 仍不足 → 先削减可调负荷，最后才动关键负荷（监测设备 + 生存供暖）
电池优先、氢兜底；仿真两遍取循环稳态，只统计第二遍。

预测调度（试验性，forecast_h > 0）：完美预报未来 forecast_h 小时的光伏与负荷；
预报这段时间光伏不够用电时，亏缺先由 rSOC 发电，电池留作调峰和兜底。
"""
from dataclasses import dataclass, replace
import numpy as np
import pandas as pd
from .params import BATTERY, H2, DESIGN, TES, CRITICAL, H2_TECH, DC_BUS


@dataclass
class Inputs:
    pv_per_kwp: np.ndarray
    e_base: np.ndarray
    q_heat: np.ndarray       # 供暖 + 热水
    q_cool: np.ndarray
    q_survival: np.ndarray   # 生存模式供暖
    cop_h: np.ndarray
    cop_c: np.ndarray
    month: np.ndarray
    index: pd.DatetimeIndex
    elec_factor: float = 1.0  # 站内用电折算系数（直流母线 < 1）


def make_inputs(w, load, pv_df_1kwp, dc_bus=False) -> Inputs:
    """dc_bus=True：站内直流配电，全部用电（含热泵、关键负荷）按 params.DC_BUS 折减。"""
    f = 1.0 - DC_BUS["load_saving"] if dc_bus else 1.0
    return Inputs(pv_df_1kwp["pv_kw"].values.copy(), load.e_base.values * f,
                  (load.q_space + load.q_dhw).values, load.q_cool.values,
                  load.q_survival.values, load.cop_h.values / f, load.cop_c.values / f,
                  w.index.month.values, w.index, f)


def with_blackout(inp: Inputs, start, hours=72) -> Inputs:
    """压力测试：把 start 起 hours 小时的光伏置零。"""
    pv = inp.pv_per_kwp.copy()
    i0 = inp.index.get_indexer([pd.Timestamp(start)], method="nearest")[0]
    pv[i0:i0 + hours] = 0.0
    return replace(inp, pv_per_kwp=pv)


def tech_params(tech: str | None):
    h = dict(H2)
    extra = dict(reversible=False, desorb_kwh_per_kg=0.0, ely_heat_kwh_per_kg=0.0,
                 standby_frac=0.0, standby_months=(),
                 standby_soc=None, warm_h=0, warm_factor=1.0, standby_room_frac=0.0)
    h.update(extra)
    if tech:
        h.update({k: v for k, v in H2_TECH[tech].items() if k in h})
    return h


def simulate(inp: Inputs, pv_kwp, bat_kwh, ely_kw=0.0, fc_kw=0.0, tank_kg=0.0,
             tes_kwh=0.0, tes_heater_kw=None, tech=None, heat_recovery=True,
             record=False, passes=2, track_from=None, forecast_h=0, standby=None):
    """尺寸参数可为标量或等长数组。tech 取 params.H2_TECH 的键。
    rSOC 路线下 fc_kw 是额定发电功率，电解功率自动取 2 × fc_kw（忽略 ely_kw）。
    forecast_h = 0 为规则调度；> 0 为看未来 forecast_h 小时（完美预报）的预测调度。
    standby：覆盖热备参数的 dict（standby_soc / warm_h / warm_factor）。standby_soc 为 None 时整个冬季保温（原方案）；
    取 0–1 时为按需热备：冬季只在电池电量低于该比例或 rSOC 刚运行过时保温，冷态启动需先升温 warm_h 小时，
    升温期间耗热为热备功率的 warm_factor 倍，升温完成前 rSOC 不能发电。
    standby_room_frac：rSOC 保温箱装在站房内时，热备散热进入室内、抵扣供暖的比例（0 = 装在室外，原方案）。"""
    b, h = BATTERY, tech_params(tech)
    if standby:
        h.update(standby)
    arrs = np.broadcast_arrays(*[np.atleast_1d(np.asarray(x, float)) for x in (
        pv_kwp, bat_kwh, ely_kw, fc_kw, tank_kg, tes_kwh,
        tes_kwh * 0 if tes_heater_kw is None else tes_heater_kw)])
    pv_kwp, bat_kwh, ely_kw, fc_kw, tank_kg, tes_kwh, tes_heater_kw = [a.copy() for a in arrs]
    if tes_heater_kw.max() == 0:
        tes_heater_kw = tes_kwh / 24.0                      # 默认一天充满
    if h["reversible"]:
        ely_kw = 2.0 * fc_kw
    n_cfg = pv_kwp.size

    soh = DESIGN["bat_eol_soh"] if DESIGN["end_of_life"] else 1.0
    cap = bat_kwh * soh
    e_min, e_max = cap * b["soc_min"], cap * b["soc_max"]
    p_bat = bat_kwh * b["c_rate"]
    self_dis = b["self_dis_per_month"] / 730.0
    tes_loss = TES["loss_per_day"] / 24.0
    kpk_ely = h["lhv"] / h["ely_eff"] + h["comp_kwh_per_kg"]     # kWh_e/kg
    kpk_fc = h["lhv"] * h["fc_eff"]                               # kWh_e/kg
    k_heat = (h["fc_heat_eff"] / h["fc_eff"] - h["desorb_kwh_per_kg"] / kpk_fc) if heat_recovery else 0.0
    k_heat = max(k_heat, 0.0)
    k_fc_gross = h["fc_heat_eff"] / h["fc_eff"] if heat_recovery else 0.0
    q_steam = h["ely_heat_kwh_per_kg"]                            # SOEC 吸热 kWh_th/kg
    ely_heat_per_kwh = 0.0 if q_steam > 0 else (1 - h["lhv"] / kpk_ely) * TES["ely_heat_capture"]
    ely_min = ely_kw * h["ely_min_load"]
    sb_kw = h["standby_frac"] * fc_kw
    sb_month = np.isin(inp.month, h["standby_months"]) if h["standby_months"] else np.zeros(len(inp.month), bool)
    on_demand = h["standby_soc"] is not None
    crit_base = CRITICAL["crit_kw"] * inp.elec_factor

    T = len(inp.e_base)
    if forecast_h:                                          # 未来 forecast_h 小时的光伏（每 kWp）与用电估计
        cum = lambda x: np.concatenate([[0.0], np.cumsum(x)])
        i, j = np.arange(T), np.minimum(np.arange(T) + forecast_h, T)
        pv_c = cum(inp.pv_per_kwp)
        d_c = cum(inp.e_base + inp.q_heat / inp.cop_h + inp.q_cool / inp.cop_c)
        pv_ahead, d_ahead = pv_c[j] - pv_c[i], d_c[j] - d_c[i]

    def need(d, q, cop):                                     # 热电联立：发电 P 使 P + min(q, k'P)/COP = d
        return np.where(k_heat * d / (1 + k_heat / cop) <= q, d / (1 + k_heat / cop), np.maximum(d - q / cop, 0.0))

    E = 0.5 * (e_min + e_max); H = 0.5 * tank_kg; S = 0.5 * tes_kwh
    keys = ("demand", "unmet", "crit_unmet", "curtail", "pv", "bat_in", "bat_out", "ely_in",
            "h2_made", "h2_used", "fc_out", "heat_rec", "tes_in", "tes_out", "standby_e", "steam_e",
            "ely_hours", "fc_hours", "unmet_hours", "crit_unmet_hours")
    for p in range(passes):
        last = p == passes - 1
        acc = {k: np.zeros(n_cfg) for k in keys}
        h_min = H.copy()
        hot = np.zeros(n_cfg)                               # 按需热备：已连续保温的小时数
        pf_prev = np.zeros(n_cfg)
        first_crit = np.full(n_cfg, -1)                     # track_from 之后关键负荷首次中断的小时序号
        t_track = None if track_from is None else int(inp.index.get_indexer([pd.Timestamp(track_from)], method="nearest")[0])
        rec = {k: np.zeros(T) for k in ("pv", "demand", "soc", "h2_kg", "tes_kwh", "bat_p", "ely_p",
                                        "fc_p", "heat_rec", "tes_out", "tes_heater", "unmet", "crit_unmet",
                                        "curtail", "bat_kwh_state")} \
            if (record and last) else None
        for t in range(T):
            pv = inp.pv_per_kwp[t] * pv_kwp
            qh, cop, qc, copc = inp.q_heat[t], inp.cop_h[t], inp.q_cool[t], inp.cop_c[t]
            E = E * (1 - self_dis); S = S * (1 - tes_loss)

            # 0. rSOC 热备
            sb_e = np.zeros(n_cfg); room_tes = 0.0
            fc_cap = fc_kw
            if sb_month[t]:
                sb_now = sb_kw
                if on_demand:                                 # 电量偏低或刚发过电才保温；冷态先升温
                    want = (E < h["standby_soc"] * cap) | (pf_prev > 1e-9)
                    hot = np.where(want, hot + 1, 0.0)
                    sb_now = np.where(want, sb_kw * np.where(hot <= h["warm_h"], h["warm_factor"], 1.0), 0.0)
                    fc_cap = np.where(hot > h["warm_h"], fc_kw, 0.0)
                s_sb = np.minimum(sb_now, S); S = S - s_sb
                sb_e = sb_now - s_sb                          # 电加热补足
                room = np.minimum(qh, sb_now * h["standby_room_frac"])     # 保温箱在室内：散热抵扣供暖
                qh = qh - room
                room_tes = room * s_sb / np.maximum(sb_now, 1e-12)        # 其中来自储热仓的部分（计入免热泵供热）

            # 1. 储热仓放热（只在光伏不够时）
            D0 = inp.e_base[t] + sb_e + qh / cop + qc / copc
            tes_h = np.where(pv < D0, np.minimum(np.minimum(qh, S), TES["discharge_kw"]), 0.0)
            S = S - tes_h
            qh_rem = qh - tes_h
            D = inp.e_base[t] + sb_e + qh_rem / cop + qc / copc
            net = pv - D

            # 2a. 盈余
            sur = np.maximum(net, 0.0)
            ch = np.minimum(np.minimum(sur, p_bat), np.maximum(e_max - E, 0) / b["eta_ch"])
            E = E + ch * b["eta_ch"]
            rem = sur - ch
            pe = np.minimum(np.minimum(rem, ely_kw), np.maximum(tank_kg - H, 0) * kpk_ely)
            pe = np.where(pe >= np.maximum(ely_min, 1e-9), pe, 0.0)
            ely_q = 0.0
            if q_steam > 0:                                   # SOEC 蒸汽热：储热仓 → 盈余电加热 → 按比例少制氢
                rem1 = rem - pe
                q_need = pe / kpk_ely * q_steam
                s_take = np.minimum(q_need, S)
                e_heat = np.minimum((q_need - s_take) / TES["heater_eff"], rem1)
                got = s_take + e_heat * TES["heater_eff"]
                frac = np.where(q_need > 1e-12, got / np.maximum(q_need, 1e-12), 1.0)
                pe = np.where(pe * frac >= np.maximum(ely_min, 1e-9), pe * frac, 0.0)
                on = pe > 0                                   # 缩减后的需热 = frac·need = got，正好用完
                S = S - np.where(on, s_take, 0.0)
                ely_q = np.where(on, e_heat, 0.0)
            made = pe / kpk_ely
            H = H + made
            S = np.minimum(S + pe * ely_heat_per_kwh, tes_kwh)
            rem = rem - pe - ely_q
            heat_in = np.minimum(np.minimum(rem, tes_heater_kw),
                                 np.maximum(tes_kwh - S, 0) / TES["heater_eff"])
            S = S + heat_in * TES["heater_eff"]
            curt = rem - heat_in
            heat_in_all = heat_in + ely_q                     # 电加热总功率（储热仓 + SOEC 蒸汽）

            # 2b. 亏缺（预测调度时：预报光伏不够 → rSOC 先发，电池后放）
            d = np.maximum(-net, 0.0)
            pf0 = hu0 = 0.0
            if forecast_h:
                dark = pv_ahead[t] * pv_kwp < d_ahead[t]
                pf0 = np.where(dark & (d > 1e-9), np.minimum(np.minimum(need(d, qh_rem, cop), fc_cap), H * kpk_fc), 0.0)
                hu0 = np.minimum(qh_rem, k_heat * pf0)
                d = np.maximum(d - pf0 - hu0 / cop, 0.0)
            dis = np.minimum(np.minimum(d, p_bat), np.maximum(E - e_min, 0) * b["eta_dis"])
            E = E - dis / b["eta_dis"]
            d2 = d - dis
            q_left = qh_rem - hu0
            pf1 = np.minimum(np.minimum(need(d2, q_left, cop), fc_cap - pf0), H * kpk_fc - pf0)
            pf1 = np.where(d2 > 1e-9, pf1, 0.0)
            hu1 = np.minimum(q_left, k_heat * pf1)
            pf, heat_used = pf0 + pf1, hu0 + hu1
            S = np.minimum(S + np.maximum(k_heat * pf - heat_used, 0), tes_kwh)   # 富余余热入仓
            H = H - pf / kpk_fc
            pf_prev = pf
            unmet = np.maximum(d2 - pf1 - hu1 / cop, 0.0)

            D_eff = D - heat_used / cop
            crit = crit_base + inp.q_survival[t] / cop
            crit_unmet = np.maximum(unmet - np.maximum(D_eff - crit, 0.0), 0.0)

            if last:
                acc["demand"] += D_eff; acc["unmet"] += unmet; acc["crit_unmet"] += crit_unmet
                acc["curtail"] += curt; acc["pv"] += pv
                acc["bat_in"] += ch; acc["bat_out"] += dis
                acc["ely_in"] += pe; acc["h2_made"] += made; acc["h2_used"] += pf / kpk_fc
                acc["fc_out"] += pf; acc["heat_rec"] += heat_used
                acc["tes_in"] += heat_in * TES["heater_eff"]; acc["tes_out"] += tes_h + room_tes
                acc["steam_e"] += ely_q
                acc["standby_e"] += sb_e
                acc["ely_hours"] += pe > 0; acc["fc_hours"] += pf > 0
                acc["unmet_hours"] += unmet > 1e-6; acc["crit_unmet_hours"] += crit_unmet > 1e-6
                np.minimum(h_min, H, out=h_min)
                if t_track is not None and t >= t_track:
                    newly = (first_crit < 0) & (crit_unmet > 1e-6)
                    first_crit[newly] = t - t_track
                if rec is not None:
                    for k, v in (("pv", pv), ("demand", D_eff), ("soc", E / np.maximum(cap, 1e-9)),
                                 ("h2_kg", H), ("tes_kwh", S), ("bat_p", dis - ch), ("ely_p", pe),
                                 ("fc_p", pf), ("heat_rec", heat_used), ("tes_out", tes_h + room_tes),
                                 ("unmet", unmet), ("crit_unmet", crit_unmet), ("curtail", curt),
                                 ("tes_heater", heat_in_all), ("bat_kwh_state", E)):
                        rec[k][t] = v[0]

    years = T / 8766.0
    out = {k: v / years for k, v in acc.items()}
    for k in ("unmet", "crit_unmet", "unmet_hours", "crit_unmet_hours"):
        out[k + "_total"] = acc[k]
    out["lpsp"] = acc["unmet"] / np.maximum(acc["demand"], 1e-9)
    out["h2_min_kg"] = h_min
    if track_from is not None:
        out["first_crit_h"] = first_crit
    out["bat_cycles"] = out["bat_out"] / np.maximum(cap * (b["soc_max"] - b["soc_min"]), 1e-9)
    out["water_gross_l"] = out["h2_made"] * h["water_l_per_kg"] / h["purify_recovery"]
    out["water_net_l"] = out["water_gross_l"] - out["h2_used"] * h["water_l_per_kg"] * h["fc_water_recovery"]
    out.update(pv_kwp=pv_kwp, bat_kwh=bat_kwh, ely_kw=ely_kw, fc_kw=fc_kw, tank_kg=tank_kg,
               tes_kwh=tes_kwh, tes_heater_kw=tes_heater_kw)
    out["tech"] = tech or "PEM+高压罐"
    if rec is not None:
        out["series"] = pd.DataFrame(rec, index=inp.index)
    return out
