"""读取本地缓存的 NASA POWER 逐时数据，统一成带时间索引的 DataFrame。

时间基准（已用 11 年数据验证）：
  POWER 的 LST = UTC+6；HR=h 表示 h:00–h+1:00 这一小时的平均值。
  敦煌实际作息用北京时间 UTC+8 → 负荷时刻表要在 LST 基础上 +2 h。
"""
from pathlib import Path
import pandas as pd

RAW = Path(__file__).resolve().parent.parent / "data" / "raw"
UTC_OFFSET_H = 6          # POWER LST
BEIJING_SHIFT_H = 2       # 北京时间 = LST + 2


def load_weather(y0: int = 2014, y1: int = 2024) -> pd.DataFrame:
    frames = []
    for y in range(y0, y1 + 1):
        f = RAW / f"power_{y}.csv"
        if not f.exists():
            raise FileNotFoundError(f"{f} 不存在，先运行 python -m model.fetch_weather")
        frames.append(pd.read_csv(f))
    df = pd.concat(frames, ignore_index=True)
    idx = pd.to_datetime(dict(year=df.YEAR, month=df.MO, day=df.DY, hour=df.HR))
    out = pd.DataFrame({
        "ghi": df.ALLSKY_SFC_SW_DWN.clip(lower=0).values,   # W/m²（小时均值 = Wh/m²）
        "dni": df.ALLSKY_SFC_SW_DNI.clip(lower=0).values,
        "dhi": df.ALLSKY_SFC_SW_DIFF.clip(lower=0).values,
        "t_air": df.T2M.values,                             # ℃
        "wind": df.WS10M.values,                            # m/s
        "rh": df.RH2M.values,                               # %
    }, index=pd.DatetimeIndex(idx, name="time_lst"))
    out["hour_bj"] = (out.index.hour + BEIJING_SHIFT_H) % 24
    return out
