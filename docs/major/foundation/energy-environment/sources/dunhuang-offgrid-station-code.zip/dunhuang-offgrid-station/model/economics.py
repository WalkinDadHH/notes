"""全寿命净现值成本（NPC）与平准化度电成本（LCOE）。

口径：
  - 建站年一次性投资（第 0 年），单价取 params.PRICES 的某一档（默认 PRICE_YEAR）；年运维 = 投资 × 运维率，按年金折现
  - 更换：电池按 min(日历寿命, 循环寿命/年循环)；电解槽/燃料电池/rSOC 按电堆小时寿命
  - 评价期末按剩余寿命比例计残值
  - 热泵、建筑、配电等各方案共有部分不计入（只比差异）
"""
import numpy as np
from .params import H2_TECH, prices


def _pv(amount, year, r):
    return amount / (1 + r) ** np.minimum(year, 200.0)


def _replacement_npc(cost, life_y, years, r):
    cost = np.asarray(cost, float)
    life_y = np.clip(np.asarray(life_y, float), 0.5, 1e6)
    cost, life_y = np.broadcast_arrays(cost, life_y)
    total = np.zeros(cost.shape)
    for k in range(1, int(years / life_y.min()) + 2):
        yk = k * life_y
        total += np.where(yk < years, _pv(cost, yk, r), 0.0)
    last = np.floor((years - 1e-9) / life_y) * life_y
    remain = 1 - (years - last) / life_y
    total -= np.where(life_y < 1e5, _pv(cost * remain, years, r), 0.0)
    return total


def npc(sim: dict, tech=None, pv_tech=None, e=None, year=None):
    """year 取 "2026" / "2035"，缺省为 params.PRICE_YEAR；e 可再覆盖个别参数（灵敏度用）。"""
    tech = tech or sim.get("tech") or "PEM+高压罐"
    e = {**prices(year, tech, pv_tech), **(e or {})}
    r, Y = e["discount"], e["years"]
    ann = (1 - (1 + r) ** -Y) / r
    rev = H2_TECH[tech].get("reversible", False)

    pv, bat = sim["pv_kwp"], sim["bat_kwh"]
    ely, fc, tank, tes = sim["ely_kw"], sim["fc_kw"], sim["tank_kg"], sim["tes_kwh"]
    has_h2 = tank > 0

    c_pv = pv * (e["pv_cny_per_kwp"] + e["pv_extra_cny_per_kwp"])
    c_bat = bat * e["bat_cny_per_kwh"] + bat * 0.1 * e["bat_pcs_cny_per_kw"]
    if rev:
        c_ely = np.zeros_like(fc)
        c_fc = fc * e["rsoc_cny_per_kw"]
    else:
        c_ely = ely * e["ely_cny_per_kw"]
        c_fc = fc * e["fc_cny_per_kw"]
    c_tank = tank * e["tank_cny_per_kg"]
    c_fix = np.where(has_h2, e["h2_fixed_cny"], 0.0)
    capex_h2 = np.where(has_h2, c_ely + c_fc + c_tank + c_fix, 0.0)
    c_tes = np.where(tes > 0, tes * e["tes_cny_per_kwh"] + sim["tes_heater_kw"] * e["tes_heater_cny_per_kw"]
                     + e["tes_fixed_cny"], 0.0)
    capex = c_pv + c_bat + capex_h2 + c_tes

    om = (c_pv * e["pv_om"] + c_bat * e["bat_om"] + capex_h2 * e["h2_om"] + c_tes * e["tes_om"]) * ann

    cyc = np.maximum(sim["bat_cycles"], 1e-6)
    bat_life = np.minimum(e["bat_life_y"], e["bat_life_cycles"] / cyc)
    rep_bat = _replacement_npc(c_bat, bat_life, Y, r)
    if rev:
        hrs = sim["ely_hours"] + sim["fc_hours"]
        life = np.where(hrs > 0, e["rsoc_stack_h"] / np.maximum(hrs, 1e-6), 1e9)
        rep_h2 = np.where(life < Y, _replacement_npc(c_fc * e["rsoc_stack_frac"], life, Y, r), 0.0)
    else:
        ely_life = np.where(sim["ely_hours"] > 0, e["ely_stack_h"] / np.maximum(sim["ely_hours"], 1e-6), 1e9)
        fc_life = np.where(sim["fc_hours"] > 0, e["fc_stack_h"] / np.maximum(sim["fc_hours"], 1e-6), 1e9)
        rep_h2 = (np.where(ely_life < Y, _replacement_npc(c_ely * e["ely_stack_frac"], ely_life, Y, r), 0.0)
                  + np.where(fc_life < Y, _replacement_npc(c_fc * e["fc_stack_frac"], fc_life, Y, r), 0.0))
    rep_h2 = np.where(has_h2, rep_h2, 0.0)

    total = capex + om + rep_bat + rep_h2
    served = np.maximum(sim["demand"] - sim["unmet"], 1e-9)
    return dict(npc=total, capex=capex, capex_pv=c_pv, capex_bat=c_bat, capex_h2=capex_h2,
                capex_tes=c_tes, om=om, rep_bat=rep_bat, rep_h2=rep_h2,
                lcoe=total / (served * ann), bat_life=bat_life)
