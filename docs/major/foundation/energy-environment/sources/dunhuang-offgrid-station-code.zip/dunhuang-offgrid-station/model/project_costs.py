"""固定配置的建设及供能预算。与选型用的核心设备 npc() 分开保留。"""
from model.params import H2_TECH, PROJECT_BUDGET, SITE, prices


def extended_cost(row, audit, year="2035", scenario="中"):
    """返回供电侧子账与整站账。累计支出不折现、不抵扣残值，均含预算预备费。"""
    p = PROJECT_BUDGET
    idx = p["scenarios"].index(scenario)
    get = lambda key: float(p[key][idx])
    tech = row.tech if row.tech in H2_TECH else "PEM+高压罐"
    e = prices(year, tech, row.pv_tech)
    years, rate = int(e["years"]), e["discount"]
    base = audit["cost"]
    dc = str(row.get("dc_bus", False)).lower() in ("true", "1", "1.0")
    power_capex = base["capex_pv"] + base["capex_bat"] + base["capex_h2"]
    heat_capex = base["capex_tes"]
    direct = dict(
        energy_devices=power_capex,
        storage_heat=heat_capex,
        power_integration=power_capex * get("integration_frac"),
        heat_integration=heat_capex * get("integration_frac"),
        external_distribution=get("external_distribution_cny"),
        dc_extra=get("dc_extra_cny") if dc else 0.,
        ems=get("ems_cny"),
        energy_transport=get("energy_transport_cny"),
        building=SITE["floor_m2"] * get("building_cny_per_m2"),
        hp=get("hp_cny"),
        terminals=get("hvac_terminals_cny"),
        dhw_tank=get("dhw_tank_cny"),
        siteworks=get("siteworks_cny"),
        domestic_water=get("domestic_water_cny"),
    )
    gen_keys = {"energy_devices", "power_integration", "external_distribution", "dc_extra",
                "ems", "energy_transport"}
    ledgers = {scope: [] for scope in ("generation", "station")}

    def add(scope, t, kind, amount):
        if abs(amount) > 1e-9:
            ledgers[scope].append(dict(year=float(t), kind=kind, amount_cny=float(amount),
                                      pv_cny=float(amount / (1 + rate) ** t)))

    for scope in ledgers:
        keys = gen_keys if scope == "generation" else set(direct)
        subtotal = sum(direct[k] for k in keys)
        design = subtotal * get("design_frac")
        reserve = (subtotal + design) * get("contingency_frac")
        add(scope, 0, "直接建设费", subtotal)
        add(scope, 0, "设计与项目管理暂列费", design)
        add(scope, 0, "基本预备费", reserve)

    # 原能源设备运维已含；电费由光伏系统自供，不另按电网电价收费。
    gen_om = sum(base[f"capex_{key}"] * e[om] for key, om in
                 (("pv", "pv_om"), ("bat", "bat_om"), ("h2", "h2_om")))
    electric = direct["external_distribution"] + direct["dc_extra"]
    gen_om += (electric + direct["ems"]) * get("mep_om")
    thermal = direct["hp"] + direct["terminals"] + direct["dhw_tank"]
    total_om = (gen_om + base["capex_tes"] * e["tes_om"]
                + direct["building"] * get("building_om")
                + (thermal + direct["domestic_water"]) * get("mep_om"))
    for t in range(1, years + 1):
        add("generation", t, "运维", gen_om)
        add("station", t, "运维", total_om)

    def replacement(scope, label, amount, life):
        """仅后续更新资产计剩余寿命残值，与原模型的更换口径一致。"""
        if amount <= 0:
            return
        life = max(float(life), 0.5)
        times = [k * life for k in range(1, int(years / life) + 1) if k * life < years]
        for t in times:
            add(scope, t, label + "更新", amount)
        if times:
            residual = amount * max(0., 1 - (years - times[-1]) / life)
            add(scope, years, label + "期末残值", -residual)

    stack_replacements = []
    for scope in ledgers:
        replacement(scope, "电池及变流器", base["capex_bat"], base["bat_life"])
        replacement(scope, "站外配电及直流适配", electric, get("electrical_life_y"))
        replacement(scope, "EMS计量", direct["ems"], get("ems_life_y"))
        if row.tank_kg > 0:
            if H2_TECH[tech].get("reversible", False):
                hours = row.ely_hours + row.fc_hours
                stack_parts = [("rSOC电堆", row.fc_kw * e["rsoc_cny_per_kw"]
                                * e["rsoc_stack_frac"], e["rsoc_stack_h"], hours)]
            else:
                stack_parts = [
                    ("PEM电解电堆", row.ely_kw * e["ely_cny_per_kw"] * e["ely_stack_frac"],
                     e["ely_stack_h"], row.ely_hours),
                    ("PEM发电电堆", row.fc_kw * e["fc_cny_per_kw"] * e["fc_stack_frac"],
                     e["fc_stack_h"], row.fc_hours),
                ]
            for name, cost, limit, hours in stack_parts:
                hour_life = limit / hours if hours else 1e9
                life = min(hour_life, get("power_unit_calendar_y"))
                replacement(scope, name, cost, life)
                if scope == "station":
                    stack_replacements.append(dict(component=name, life_y=float(life),
                                                   hour_life_y=float(hour_life)))
            replacement(scope, "氢路固定配套", e["h2_fixed_cny"] * get("h2_aux_replace_frac"),
                        get("h2_aux_calendar_y"))
    replacement("station", "冷热主机末端与热水箱", thermal, get("hvac_life_y"))
    replacement("station", "生活水与污水配套", direct["domestic_water"], get("water_life_y"))
    # 储热壳体、储氢容器和建筑按评价期内不重建，初始资产残值保守取零。
    out = dict(price_year=year, scenario=scenario, currency="CNY", years=years,
               discount_rate=rate, direct=direct, core_npc_cny=base["npc"],
               core_capex_cny=base["capex"], stack_replacements=stack_replacements)
    for scope, flows in ledgers.items():
        capex = sum(x["amount_cny"] for x in flows if x["year"] == 0)
        gross = sum(max(0., x["amount_cny"]) for x in flows)
        om = sum(x["pv_cny"] for x in flows if x["kind"] == "运维")
        repl = sum(x["pv_cny"] for x in flows if "更新" in x["kind"])
        salvage = -sum(x["pv_cny"] for x in flows if "残值" in x["kind"])
        npc_value = sum(x["pv_cny"] for x in flows)
        if abs(npc_value - (capex + om + repl - salvage)) > 1e-6:
            raise ValueError("项目现金流不闭合")
        out[scope] = dict(capex_cny=capex, annual_om_cny=gen_om if scope == "generation" else total_om,
                          cumulative_outlay_cny=gross, npc_cny=npc_value, om_pv_cny=om,
                          replacement_pv_cny=repl, salvage_pv_cny=salvage, cashflows=flows)
    return out
