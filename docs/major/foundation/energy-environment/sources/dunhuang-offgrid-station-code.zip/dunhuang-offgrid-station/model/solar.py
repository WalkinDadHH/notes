"""太阳几何 + 倾斜面辐照（Hay-Davies）+ 组件温度（Faiman）+ 光伏出力。

不依赖 pvlib，只用 numpy，便于在任何电脑上复现。
所有辐照量为小时均值 W/m²；以小时中点计算太阳位置。
"""
import numpy as np
import pandas as pd

LAT = 40.14
LON = 94.66
TZ_MERIDIAN = 90.0     # UTC+6 标准经线


def solar_position(index: pd.DatetimeIndex, lat=LAT, lon=LON):
    """返回 (天顶角 rad, 方位角 rad 从正北顺时针, 大气层外法向辐照 W/m²)。"""
    doy = index.dayofyear.values
    hour = index.hour.values + 0.5                         # 时段中点
    b = 2 * np.pi * (doy - 1) / 365.0
    # Spencer (1971)
    decl = (0.006918 - 0.399912*np.cos(b) + 0.070257*np.sin(b)
            - 0.006758*np.cos(2*b) + 0.000907*np.sin(2*b)
            - 0.002697*np.cos(3*b) + 0.00148*np.sin(3*b))
    eot_min = 229.18*(0.000075 + 0.001868*np.cos(b) - 0.032077*np.sin(b)
                      - 0.014615*np.cos(2*b) - 0.040849*np.sin(2*b))
    e0 = 1.000110 + 0.034221*np.cos(b) + 0.001280*np.sin(b) \
        + 0.000719*np.cos(2*b) + 0.000077*np.sin(2*b)
    solar_time = hour + (4*(lon - TZ_MERIDIAN) + eot_min) / 60.0
    ha = np.radians(15.0 * (solar_time - 12.0))
    phi = np.radians(lat)
    cosz = np.sin(phi)*np.sin(decl) + np.cos(phi)*np.cos(decl)*np.cos(ha)
    zen = np.arccos(np.clip(cosz, -1, 1))
    sinz = np.maximum(np.sin(zen), 1e-6)
    cos_az = (np.sin(decl) - np.sin(phi)*cosz) / (np.cos(phi)*sinz)
    az = np.arccos(np.clip(cos_az, -1, 1))
    az = np.where(ha > 0, 2*np.pi - az, az)                # 下午在西侧
    dni_extra = 1361.0 * e0
    return zen, az, dni_extra


def poa_irradiance(w: pd.DataFrame, tilt_deg=40.0, azimuth_deg=180.0, albedo=0.25):
    """Hay-Davies 各向异性天空模型。返回倾斜面总辐照 W/m²。"""
    zen, az, dni_extra = solar_position(w.index)
    beta = np.radians(tilt_deg)
    gam = np.radians(azimuth_deg)
    cos_aoi = np.cos(zen)*np.cos(beta) + np.sin(zen)*np.sin(beta)*np.cos(az - gam)
    cos_aoi = np.clip(cos_aoi, 0, 1)
    cosz = np.cos(zen)
    up = cosz > 0.0175                                    # 太阳高度角 > 1°

    ghi, dni, dhi = w.ghi.values, w.dni.values, w.dhi.values
    # NASA DNI 在低高度角时偶有不一致，用 GHI 闭合约束一下：DNI·cosZ ≤ GHI
    dni = np.where(up, np.minimum(dni, np.maximum(ghi - dhi, 0) / np.maximum(cosz, 0.0175)), 0)
    beam = dni * cos_aoi
    ai = np.where(up, dni / dni_extra, 0)                  # 各向异性指数
    rb = np.where(up, cos_aoi / np.maximum(cosz, 0.0175), 0)
    sky = dhi * (ai * rb + (1 - ai) * (1 + np.cos(beta)) / 2)
    ground = ghi * albedo * (1 - np.cos(beta)) / 2
    poa = np.where(up, beam + sky + ground, 0)
    return pd.Series(np.maximum(poa, 0), index=w.index, name="poa")


def pv_power(w: pd.DataFrame, kwp: float, tilt_deg=None, p=None, eol=None):
    """每小时交流侧出力 kW。p 为参数字典（见 params.PV）。
    eol=True 时按寿命末期（第 25 年）衰减后的出力计算。"""
    from .params import PV, DESIGN
    p = {**PV, **(p or {})}
    tilt_deg = p["tilt"] if tilt_deg is None else tilt_deg
    eol = DESIGN["end_of_life"] if eol is None else eol
    derate = (1 - p["degr_per_y"]) ** (DESIGN["pv_eol_year"] - 1) if eol else 1.0
    poa = poa_irradiance(w, tilt_deg=tilt_deg, albedo=p["albedo"])
    t_cell = w.t_air.values + poa.values / (p["u0"] + p["u1"] * w.wind.values)
    dc = kwp * poa.values / 1000.0 * (1 + p["gamma"] * (t_cell - 25.0))
    ac = dc * (1 - p["soiling"]) * (1 - p["dc_loss"]) * p["inv_eff"] * p["availability"] * derate * (1 + p["bifacial_gain"])
    return pd.DataFrame({"poa": poa.values, "t_cell": t_cell,
                         "pv_kw": np.maximum(ac, 0)}, index=w.index)
