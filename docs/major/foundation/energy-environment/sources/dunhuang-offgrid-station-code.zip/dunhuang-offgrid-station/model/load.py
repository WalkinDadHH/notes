"""逐时负荷模型：电负荷（非暖通）+ 供暖/热水热负荷 + 制冷热负荷 + 热泵 COP。

输出全部以 kW（小时均值）计；热负荷是“热”，需要除以 COP 才是电。
作息用北京时间（hour_bj），太阳与气温用 LST，二者相差 2 h。
"""
import numpy as np
import pandas as pd
from .params import SITE, BUILDING, ELEC, HEATPUMP, CRITICAL

# 生活用电日内分布（北京时间 0–23 时，归一化前权重）
_LIVING_PROFILE = np.array([
    0.3, 0.2, 0.2, 0.2, 0.2, 0.3,  # 0–5
    0.8, 1.6, 1.4, 0.7, 0.6, 0.9,  # 6–11
    1.8, 1.2, 0.7, 0.6, 0.7, 1.2,  # 12–17
    2.2, 2.4, 2.0, 1.6, 1.0, 0.5,  # 18–23
])
_LIVING_PROFILE = _LIVING_PROFILE / _LIVING_PROFILE.sum()

_DHW_PROFILE = np.array([
    0, 0, 0, 0, 0, 0.2,  1.5, 2.0, 0.8, 0.2, 0.2, 0.4,
    0.6, 0.3, 0.2, 0.2, 0.3, 0.6,  1.2, 1.8, 2.4, 2.0, 1.0, 0.2,
])
_DHW_PROFILE = _DHW_PROFILE / _DHW_PROFILE.sum()

# 室内人数比例（北京时间）：白天约一半人在野外作业
_OCC = np.array([1]*7 + [0.8, 0.5, 0.5, 0.5, 0.5, 0.8, 0.6, 0.5, 0.5, 0.5, 0.7] + [1]*6)


def _ema(x: np.ndarray, tau_h: float) -> np.ndarray:
    """一阶指数平滑，模拟建筑热惯性。"""
    a = 1.0 / tau_h
    y = np.empty_like(x)
    y[0] = x[0]
    for i in range(1, len(x)):
        y[i] = y[i-1] + a * (x[i] - y[i-1])
    return y


def heatpump_cop(t_src, mode="heat"):
    hp = HEATPUMP
    if mode == "heat":
        th = hp["t_sink_h"] + 273.15
        tc = np.asarray(t_src) + 273.15
        cop = hp["eta_carnot_h"] * th / np.maximum(th - tc, 5.0)
    else:  # 制冷：等价逆卡诺循环取两侧空气进出口平均温度（李晓凤、马一太 2013 的完善度口径）
        tc = BUILDING["t_cool"] - hp["dT_supply_c"] / 2 + 273.15
        th = np.asarray(t_src) + hp["dT_out_air_c"] / 2 + 273.15
        cop = hp["eta_carnot_c"] * tc / np.maximum(th - tc, 5.0)
    return np.clip(cop, hp["cop_min"], hp["cop_max"])


def build_load(w: pd.DataFrame) -> pd.DataFrame:
    """返回逐时负荷表。列：
    e_base   非暖通电负荷 kW
    q_space  供暖热负荷 kW_th
    q_dhw    生活热水热负荷 kW_th
    q_cool   制冷冷负荷 kW_th
    cop_h, cop_c
    e_hvac   热泵耗电 kW（不计燃料电池余热时）
    e_total  总电负荷 kW（不计余热）
    """
    b, e, s = BUILDING, ELEC, SITE
    hb = w["hour_bj"].values
    n = len(w)

    # —— 电负荷（非暖通）——
    lab = np.where((hb >= 9) & (hb < 18), e["lab_day_kw"], 0.0)
    living = s["people"] * e["living_kwh_pp"] * _LIVING_PROFILE[hb]
    e_base = e["monitor_base_kw"] + e["water_treat_kw"] + lab + living

    # —— 内部得热 ——
    people_in = s["people"] * _OCC[hb]
    q_int = (people_in * b["person_w"] / 1000.0
             + 0.8 * (e["monitor_base_kw"] + lab)      # 设备电耗约 80% 散在室内
             + 0.6 * living)
    q_sol = b["solar_aperture_m2"] * w["ghi"].values / 1000.0

    # —— 供暖 / 制冷 ——
    t_eff = _ema(w["t_air"].values, b["tau_h"])
    t_set_h = np.where((hb >= 6) & (hb < 23), b["t_heat_day"], b["t_heat_night"])
    H = b["H_W_per_K"] / 1000.0
    q_space = np.maximum(H * (t_set_h - t_eff) - q_int - q_sol, 0.0)
    q_cool_raw = np.maximum(H * (t_eff - b["t_cool"]) + q_int + q_sol, 0.0)
    # 室外凉爽时用通风带走热量（敦煌昼夜温差 15 K 以上，夜间通风效果好）
    t_air = w["t_air"].values
    free = np.where(t_air < b["t_free_max"],
                    b["vent_free_kw_per_K"] * np.maximum(b["t_cool"] - t_air, 0), 0.0)
    q_cool = np.maximum(q_cool_raw - free, 0.0)
    q_space = np.where(t_eff > 22.0, 0.0, q_space)
    # 生存模式：只保 12 ℃ 底线所需的供暖（计入关键负荷）
    q_survival = np.maximum(H * (CRITICAL["t_survival"] - t_eff) - q_int - q_sol, 0.0)
    q_survival = np.minimum(q_survival, q_space)

    # —— 生活热水 ——
    dhw_kwh_day = s["people"] * e["dhw_l_pp"] * 4.186 * e["dhw_dT"] / 3600.0
    q_dhw = dhw_kwh_day * _DHW_PROFILE[hb]

    t = w["t_air"].values
    cop_h = heatpump_cop(t, "heat")
    cop_c = heatpump_cop(t, "cool")
    e_hvac = (q_space + q_dhw) / cop_h + q_cool / cop_c

    return pd.DataFrame(dict(
        e_base=e_base, q_space=q_space, q_dhw=q_dhw, q_cool=q_cool, q_survival=q_survival,
        cop_h=cop_h, cop_c=cop_c, e_hvac=e_hvac, e_total=e_base + e_hvac,
    ), index=w.index)
