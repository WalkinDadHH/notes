"""把 results/web/*.json 内联进网页，生成离线单文件 web/index.html。

python -m analysis.export_web   # 先导出数据
python web/build.py             # 再构建网页

生成的 index.html 不引用任何外部资源，Windows 上双击即可打开。
"""
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "web" / "src" / "index.html"
OUT = ROOT / "web" / "index.html"
DATA = ROOT / "results" / "web"


def main():
    data = {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in sorted(DATA.glob("*.json"))}
    need = {"schemes", "replay", "week", "month", "lookup", "monthly"}
    missing = need - data.keys()
    if missing:
        raise SystemExit(f"缺少 {sorted(missing)}，先运行 python -m analysis.export_web")
    import sys
    sys.path.insert(0, str(ROOT))
    from model.params import CRITERIA
    fin = pd.read_csv(ROOT / "results" / "final_config.csv").iloc[0]
    data["extra"] = dict(water_l_day=round(float(fin.water_net_l) / 365.25, 1),
                         endurance_floor=CRITERIA["select_endurance_h"])
    html = SRC.read_text(encoding="utf-8")
    assert html.count("/*__DATA__*/null") == 1
    blob = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = html.replace("/*__DATA__*/null", blob)
    assert "http://" not in html.replace("http://www.w3.org/2000/svg", "") and "https://" not in html, "页面引用了外部资源"
    OUT.write_text(html, encoding="utf-8")
    print(f"→ {OUT.relative_to(ROOT)}  {OUT.stat().st_size / 1024:.0f} KB")


if __name__ == "__main__":
    main()
