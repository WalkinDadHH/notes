"""守恒校验：母线功率平衡、氢质量平衡、电池能量平衡。

python -m tests.test_balance      全部通过才算引擎可信
"""
import numpy as np
from model.weather import load_weather
from model.load import build_load
from model.solar import pv_power
from model.system import make_inputs, simulate, with_blackout
from model.params import BATTERY, H2, DESIGN, PV_TECH, H2_TECH
from model.system import tech_params

TOL = 1e-6
CASES = [
    ("纯光储", dict(pv_kwp=60, bat_kwh=300), None, None),
    ("光储氢 PEM", dict(pv_kwp=60, bat_kwh=125, ely_kw=10, fc_kw=10, tank_kg=25), None, None),
    ("rSOC+氢化物+储热", dict(pv_kwp=50, bat_kwh=100, fc_kw=10, tank_kg=30, tes_kwh=200),
     "rSOC+金属氢化物", "双面+静电除尘"),
    ("rSOC+氢化物+储热 · 预测调度", dict(pv_kwp=55, bat_kwh=50, fc_kw=10, tank_kg=30, tes_kwh=150, forecast_h=24),
     "rSOC+金属氢化物", "双面+静电除尘"),
]


def check(name, s, kw, tech):
    h = tech_params(tech)
    errs = []
    # ① 母线：光伏 + 放电 + 燃料电池 + 缺电 = 需求 + 充电 + 电解 + 电加热储热 + 弃光
    bus = (s.pv + s.bat_p + s.fc_p + s.unmet) - (s.demand + s.ely_p + s.tes_heater + s.curtail)
    errs.append(("母线功率平衡", np.abs(bus).max()))
    # ② 氢：ΔH = 制氢 − 用氢
    kpk_ely = h["lhv"] / h["ely_eff"] + h["comp_kwh_per_kg"]
    kpk_fc = h["lhv"] * h["fc_eff"]
    dh = np.diff(s.h2_kg.values) - (s.ely_p.values[1:] / kpk_ely - s.fc_p.values[1:] / kpk_fc)
    errs.append(("氢质量平衡", np.abs(dh).max()))
    # ③ 电池：ΔE = 充·η − 放/η − 自放电
    b = BATTERY
    E = s.bat_kwh_state.values
    ch = np.maximum(-s.bat_p.values, 0); dis = np.maximum(s.bat_p.values, 0)
    pred = E[:-1] * (1 - b["self_dis_per_month"] / 730) + ch[1:] * b["eta_ch"] - dis[1:] / b["eta_dis"]
    errs.append(("电池能量平衡", np.abs(E[1:] - pred).max()))
    # ④ 状态边界
    cap = kw["bat_kwh"] * (DESIGN["bat_eol_soh"] if DESIGN["end_of_life"] else 1)
    e_min = cap * b["soc_min"]
    # 调度约束：放电后不得低于下限（自放电造成的漂移是物理现象，单独报告）
    after_dis = E[1:][dis[1:] > 1e-9]
    errs.append(("放电越下限", max(0.0, (e_min - after_dis.min()) if after_dis.size else 0.0)))
    errs.append(("充电越上限", max(0.0, s.soc.max() - b["soc_max"])))
    print(f"    （自放电导致的最低 SOC 漂移 {max(0, b['soc_min'] - s.soc.min())*100:.3f} 个百分点，物理现象，非调度错误）")
    errs.append(("储氢越界", max(0, -s.h2_kg.min(), s.h2_kg.max() - kw.get("tank_kg", 0)) if kw.get("tank_kg") else 0))
    errs.append(("储热越界", max(0, -s.tes_kwh.min(), s.tes_kwh.max() - kw.get("tes_kwh", 0)) if kw.get("tes_kwh") else 0))
    ok = True
    for what, e in errs:
        flag = "✓" if e < TOL else "✗"
        ok &= e < TOL
        print(f"  {flag} {what:10s} 最大误差 {e:.2e}")
    return ok


if __name__ == "__main__":
    w = load_weather(); L = build_load(w)
    all_ok = True
    for name, kw, tech, pvt in CASES:
        inp = make_inputs(w, L, pv_power(w, 1.0, p=PV_TECH.get(pvt, {})))
        for label, i in (("11 年", inp), ("72h 压力", with_blackout(inp, "2017-12-12 00:00", 72))):
            print(f"{name} · {label}")
            s = simulate(i, tech=tech, record=True, **kw)["series"]
            all_ok &= check(name, s, kw, tech)
    print("\n全部通过 ✓" if all_ok else "\n存在失败 ✗")
    raise SystemExit(0 if all_ok else 1)
