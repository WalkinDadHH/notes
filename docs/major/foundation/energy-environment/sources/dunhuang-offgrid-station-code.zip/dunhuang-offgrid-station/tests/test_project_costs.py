"""扩展概算的口径、更新与回归检查：python -m tests.test_project_costs。"""
import unittest

from analysis.cost_audit import audit, ORDER
from analysis.schemes import load
from model.project_costs import extended_cost


class ProjectBudgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = load()

    def test_original_ten_costs_remain_reproducible(self):
        for key in ORDER:
            for year in ("2026", "2035"):
                row = self.rows[key]
                cost = audit(row, year)
                self.assertAlmostEqual(cost["cost"]["npc"], row[f"npc_{year}"], places=6)

    def test_cashflow_scopes_and_budget_order(self):
        for key in ORDER:
            for year in ("2026", "2035"):
                row = self.rows[key]
                old = audit(row, year)
                values = [extended_cost(row, old, year, s) for s in ("低", "中", "高")]
                self.assertLess(values[0]["station"]["npc_cny"], values[1]["station"]["npc_cny"])
                self.assertLess(values[1]["station"]["npc_cny"], values[2]["station"]["npc_cny"])
                for result in values:
                    self.assertGreater(result["station"]["capex_cny"], result["generation"]["capex_cny"])
                    self.assertGreater(result["station"]["npc_cny"], result["generation"]["npc_cny"])
                    for scope in ("generation", "station"):
                        ledger = result[scope]
                        self.assertGreater(ledger["cumulative_outlay_cny"], ledger["npc_cny"])
                        flows = ledger["cashflows"]
                        # 工程预备费只出现在建设年；累计支出不抵扣残值。
                        reserve = [x for x in flows if x["kind"] == "基本预备费"]
                        self.assertEqual(len(reserve), 1)
                        self.assertEqual(reserve[0]["year"], 0)
                        self.assertAlmostEqual(ledger["cumulative_outlay_cny"],
                                               sum(x["amount_cny"] for x in flows if x["amount_cny"] > 0))
                        self.assertAlmostEqual(ledger["npc_cny"],
                                               sum(x["amount_cny"] / 1.08 ** x["year"] for x in flows))

    def test_final_mid_capex_hand_calculation(self):
        row = self.rows["final"]
        r = extended_cost(row, audit(row, "2035"), "2035", "中")
        # 手算：供电核心 = 光伏 + 电池 + 氢路设备投资；集成费 8%；外配电 3 万、直流 2 万、EMS 2 万、运输 2 万（中档）；
        # 设计费 5%、预备费 10% 依次乘上。总账再加储热、热集成 8%、建筑 60 万、冷热 7.3 万、场坪 2 万、生活水 3 万。
        core = row.capex_pv + row.capex_bat + row.capex_h2
        gen = core * 1.08 + 30000 + 20000 + 20000 + 20000
        self.assertAlmostEqual(r["generation"]["capex_cny"], gen * 1.05 * 1.10)
        station = gen + row.capex_tes * 1.08 + 600000 + 73000 + 20000 + 30000
        self.assertAlmostEqual(r["station"]["capex_cny"], station * 1.05 * 1.10)
        updates = [x for x in r["station"]["cashflows"] if x["kind"] == "rSOC电堆更新"]
        self.assertEqual([x["year"] for x in updates], [15.0])
        self.assertGreater(updates[0]["amount_cny"], 0)

    def test_dc_cost_is_incremental_only(self):
        row = self.rows["econ"]
        old = audit(row, "2035")
        dc = extended_cost(row, old)
        ac_row = row.copy()
        ac_row["dc_bus"] = False
        ac = extended_cost(ac_row, old)
        self.assertAlmostEqual(dc["generation"]["capex_cny"] - ac["generation"]["capex_cny"],
                               20000 * 1.05 * 1.10)


if __name__ == "__main__":
    unittest.main()
