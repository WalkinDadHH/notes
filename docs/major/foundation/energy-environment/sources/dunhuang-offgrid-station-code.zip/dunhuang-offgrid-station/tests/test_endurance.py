"""续航追踪校验：simulate(track_from=…) 向量化记录的首次断电时刻，与逐时序列逐个查找（analysis.endurance）一致。

python -m tests.test_endurance
"""
import numpy as np
import pandas as pd
from model.weather import load_weather
from model.load import build_load
from analysis.endurance import endurance, STARTS
from analysis.refine import TECH, SIZE, endurance_all, route_inputs

CFGS = [(45, 125, 10, 8, 25, 0), (40, 150, 5, 8, 30, 0), (50, 100, 15, 10, 30, 100), (35, 75, 5, 6, 20, 0)]

if __name__ == "__main__":
    w = load_weather(); L = build_load(w)
    inp = route_inputs(w, L)
    cc = np.array(CFGS, float)
    all_ok = True
    for st in STARTS:
        vec = endurance_all(inp, cc, st)
        for cfg, v in zip(CFGS, vec):
            r = pd.Series(dict(zip(SIZE, cfg)))
            ref = endurance(inp, r, st, TECH)
            ok = int(v) == ref
            all_ok &= ok
            print(f"  {'✓' if ok else '✗'} {st[:10]}  {cfg}  向量化 {int(v):3d} h  逐时 {ref:3d} h")
    print("\n全部通过 ✓" if all_ok else "\n存在失败 ✗")
    raise SystemExit(0 if all_ok else 1)
