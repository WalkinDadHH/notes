# 敦煌离网生态监测站 · 光储氢供能系统

浙江大学《能源与环境》课程项目。2035 年在敦煌周边新建一座生态监测站，十人常驻、建筑 200 m²，**不接电网、不外购燃料**，全部用能来自场地上的太阳。

本目录是项目的计算底座：用 2014–2024 年 **11 年逐时真实气象数据**（NASA POWER，96,432 小时）仿真光伏、电池、氢、储热仓的每一小时，从成熟方案出发逐项加入改进，求出满足设计准则、能效更高的配置。

**主推方案 C 热集成版**：双面光伏（倾角 60°、黎明静电除尘）+ 直流母线 + rSOC 热集成 + 金属氢化物 + 砂石储热仓；**对照 C 经济版**：同样的光伏与直流母线 + PEM + 35 MPa。价格分 2026 现价 / 2035 预测两档，按 2035 选型。最新数字与结论以设计说明书为准，参数出处见 `docs/参数核实.md`。

## 设计准则

1. **11 年逐时真实天气下零缺电**
2. **72 小时零光照压力测试**：把历史上最差的三段低日照窗口各替换成 72 小时完全无光，监测设备与生存供暖（室温 ≥ 12 ℃）都不能中断

## 系统构成

```
            ┌─────────── 盈余 ───────────┐
光伏 ──→ 母线 ──→ 电池（日调节）            ↓
  │         │                    电解槽 ──→ 储氢 ──→ 燃料电池 / rSOC ──→ 母线
  │         │                       │ 废热                 │ 余热
  │         └──→ 弃光电加热 ──→ 砂石储热仓 ←────────────────┘
  │                                 │ 冬夜放热
  └────────────────────────────→ 供暖 / 热水 ←── 热泵
```

氢技术路线（`model/params.py` 中 `H2_TECH`；主推路线见 `MAIN_ROUTE`，对照见 `COMPARE_ROUTE`）：

| 路线 | 特点 | TRL |
|---|---|---|
| PEM + 35 MPa 高压罐 | 成熟；C 经济版 | 8–9 |
| PEM + 金属氢化物 | 低压安全、免压缩机，余热供放氢 | 6–7 |
| rSOC + 金属氢化物 | 一台设备双向运行；SOEC 电解耗电少、蒸汽热由储热仓供；SOFC 高温余热回仓；C 热集成版 | 5–6 |
| rSOC + 高压罐 | 对照：转换高效 + 储存便宜 | 5–6 |

## 快速开始

```bash
pip install -r requirements.txt
python -m analysis.events      # 11 年低日照事件统计
python -m analysis.sizing      # 纯光储 vs 光储氢 容量扫描（约 1 分钟）
python -m analysis.improve     # 倾角扫描 + 改进阶梯（两档价格、能效指标、各方案续航，约 35 分钟）
python -m analysis.refine      # 主推路线细网格定型（约 3 分钟）→ results/final_config.csv
python -m analysis.refine --compare  # C 经济版细网格 → results/final_compare.csv
python -m analysis.humidity    # 静电除尘的湿度可用性 → results/dust_humidity.csv
python -m analysis.sensitivity # 经济参数 ±30% 灵敏度（约 8 分钟）
python -m analysis.extremes    # 沙尘暴 / 寒潮情景、续航曲线、升级测算（约 10 分钟）
python -m analysis.forecast    # 完美预报调度 vs 规则调度（约 5 分钟）
python -m analysis.figures     # 图 → results/figures/journal/（报告用）与 swiss/（PPT 用）
python -m analysis.schematic   # 系统构成示意图（自动检查线与文字无交叠）
python -m analysis.report_numbers  # 设计说明书的数字宏与表格 → docs/结题报告/generated/
python -m analysis.cost_audit     # 原五方案、两档价格的设备账单与现金流复算
python -m analysis.project_budget # 两套建设供能预算、三档概算与报告表格（不重新选型）
python -m analysis.export_web  # 网页数据 → results/web/*.json
python web/build.py            # 离线单文件网页 → web/index.html（00 三维模型 · 01 能量流 · 02 断光测试 · 03 方案对比 · 04 试一试）
python -m tests.test_balance   # 守恒校验，改调度逻辑后必须全部通过
python -m tests.test_endurance # 向量化续航追踪与逐时查找一致
python -m tests.test_project_costs # 扩展预算边界、现金流、日历更新与原成本回归
```

气象数据已缓存在 `data/raw/`，**不需要联网**。要更新数据才运行 `python -m model.fetch_weather`。

## 目录

| 路径 | 内容 |
|---|---|
| `model/params.py` | **全部假设参数**，每个都标了来源和状态（✅ 已核实 / ⚠️ 待核实 / 🔒 设定） |
| `model/weather.py` | 读取气象数据；时间基准说明 |
| `model/solar.py` | 太阳位置、倾斜面辐照（Hay-Davies）、组件温度、光伏出力 |
| `model/load.py` | 逐时电负荷、供暖/制冷/热水热负荷、热泵 COP |
| `model/system.py` | **逐时调度仿真**（核心） |
| `model/economics.py` | 全寿命成本 NPC、度电成本 LCOE |
| `analysis/` | 各项分析脚本 |
| `results/` | 分析输出（CSV）、图、网页数据 |
| `docs/结题报告/` | 设计说明书 LaTeX 源文件（`latexmk -xelatex main.tex`）；PDF 见上级目录 `03_设计说明书` |
| `web/` | 交互演示网页：`src/index.html` 模板 + `build.py` → 离线单文件 `index.html` |
| `docs/` | 模型说明、参数核实、成本核算、技术卡 |

## 成本口径

成本现在分为原核心能源设备比较账、发电储能子账和整站建设及供能总账。原「核心设备现值」口径保留为比较账；新增总预算与累计支出见 `docs/成本核算/两套成本口径_自动生成.md`，参数与证据边界见 `docs/成本核算/补充概算参数说明.md`。新增概算参数统一放在 `model/params.py::PROJECT_BUDGET`；完整报告在方法、结果5.3及成本附录中解释，全部金额为人民币。

## 数据来源

`data/raw/` 为 NASA POWER 2014–2024 年逐时气象数据，由 `model/fetch_weather.py` 下载。`results/` 为本项目代码的运行输出。
